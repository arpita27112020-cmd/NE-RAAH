# NE-RAAH — SIH 2026 · PS 26002

This is the upgraded existing NE-RAAH single-file React application. The original application UI, role dashboards, workflows, risk engine, demo data, multilingual dictionaries and navigation are retained; the schematic SVG map layer has been replaced with React Leaflet.

## Run locally

Requires Node.js 18+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For a production build:

```bash
npm run build
npm run preview
```

## Map implementation

- **Basemap:** OpenStreetMap tiles rendered with Leaflet / React Leaflet.
- **Road geometry and metrics:** OSRM public routing endpoint (`router.project-osrm.org`) using driving routes and GeoJSON geometry. Network access is required. Routing errors are shown in the map; no fabricated road line is drawn as a fallback.
- **City locations:** latitude/longitude reference coordinates for Guwahati, Shillong, Silchar, Aizawl, Agartala, Imphal, Kohima, Itanagar, Gangtok and Dispur.
- **Vehicle positions:** demo positions interpolated along the fetched road geometry only when the selected route matches that vehicle's route. They are explicitly labelled simulated, not live GPS.
- **Incidents and SOS:** demo records. Markers are only shown when a named location can be associated with a known city; they are labelled approximate rather than GPS-accurate.
- **IoT:** simulated sensor readings and approximate map anchors.
- **Risk scoring:** the original NE-RAAH risk engine and route scores remain simulated prototype data. OSRM supplies geometry/distance/duration only; it does not validate risk or road safety.
- **Current location:** browser geolocation is requested only after the user presses the location control. It requires HTTPS or localhost and permission.

## External service limitations

OpenStreetMap tile and OSRM public endpoints are community services, not production SLAs. Their availability, rate limits and terms may change. For production, use a hosted tile provider and a routing backend with suitable capacity, caching and monitoring. No weather, government incident feed, live GPS, or IoT hardware feed is connected in this demo.

## Preserved prototype capabilities

The existing role-based login/demo mode, dashboards, route intelligence, route risk explanations, vehicles, shipments, alerts, SOS workflows, Ground Truth Network, AI Logistics Copilot, notifications, profile/settings, language switching and guided demo remain in the original `NE-RAAH.jsx`.

## Important prototype scope notes

The source includes the original simulated route-risk model and route-option descriptions. The newly fetched OSRM geometry is a real road route between the selected city endpoints; it is not proof that the route is safe, currently open, or operationally accessible. The original risk score remains a separate demo assessment. OSRM alternatives are displayed only when the service actually returns them. Demo vehicle positions are only drawn when their route matches the selected endpoints and a road geometry has loaded.

The source JSX was syntax-transpiled successfully during packaging. A full browser build could not be completed in this environment because dependency installation did not finish; run `npm install` and `npm run build` locally before presenting or deploying.

## Dashboard interaction improvements (this update)

- Field Officer navigation now includes the Vehicles and Shipments sections, matching the actions available to the Authority role.
- Vehicle cards expose direct **Track vehicle** and **View map impact** actions. Selecting a vehicle focuses the map on its own corridor, enables the vehicle layer and requests the corresponding OSRM road geometry. Vehicle positions remain clearly simulated demo positions, not live GPS.
- Shipment cards expose **View on map**, **Reroute** and **Contact** actions. Map view focuses the shipment's linked vehicle when one exists. Rerouting is only offered for the configured flagship corridor where a lower-risk route option exists; the app does not claim an unconfigured alternate is available. Contact opens a clearly labelled local demo message composer; it does not send a real SMS/call.
- Weather/climate alerts open the map with the Weather layer enabled. The layer shows demo impact markers at Aizawl, Silchar, Kohima and Guwahati, with explicit simulated-data labels.
- The Driver dashboard includes a direct **View weather & climate hazard impact on map** action.
- Ground Truth Network now lets the reporter take a photo (where the device/browser supports camera capture) or select an image from the device's photo library/files. The selected image is previewed, can be removed, and is attached to the submitted demo report instead of being auto-filled. Image files are limited to 8 MB.
