export default {
  content: ["./index.html", "./NE-RAAH.jsx", "./src/**/*.{js,jsx}"],
  theme: { extend: {} },
  plugins: [],
};
