import React, { useState, useEffect, useRef, useMemo, useContext, createContext } from "react";
import {
  MapPin, Navigation, Truck, Package, AlertTriangle, Bell, User, Settings as SettingsIcon,
  LogOut, Mic, Phone, CloudRain, Mountain, Droplets, CheckCircle2, Clock, Search, Wifi, WifiOff,
  ChevronRight, ChevronLeft, Home, Route as RouteIcon, Shield, MessageSquare, Camera, X, Menu,
  LayoutGrid, Layers, ZoomIn, ZoomOut, Radio, Siren, FileText, Globe, ChevronDown, Check,
  ArrowRight, RefreshCw, PlayCircle, PauseCircle, SkipForward, Info, Sparkles, Volume2,
  BadgeCheck, CircleAlert, MapPinned, Loader2, MoreHorizontal, Edit3, Camera as CameraIcon,
  TriangleAlert, CircleDot, Send
} from "lucide-react";

/* ============================================================
   FONTS
============================================================ */
const FontStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
    .nr-font { font-family: 'IBM Plex Sans', ui-sans-serif, system-ui, sans-serif; }
    .nr-mono { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
    @keyframes nrPulse { 0% { opacity: .9; transform: scale(1); } 50% { opacity: .35; transform: scale(1.9); } 100% { opacity: 0; transform: scale(2.6); } }
    @keyframes nrBlink { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }
    .nr-pulse-ring::before {
      content: ''; position: absolute; inset: 0; border-radius: 9999px;
      background: currentColor; animation: nrPulse 1.8s ease-out infinite;
    }
    .nr-blink { animation: nrBlink 1.4s ease-in-out infinite; }
    @keyframes nrMapPulse { 0% { transform: scale(1); opacity: 0.75; } 100% { transform: scale(3.2); opacity: 0; } }
    .nr-map-pulse { animation: nrMapPulse 1.1s ease-out infinite; transform-box: fill-box; transform-origin: center; }
    @keyframes nrGlowPulse { 0%, 100% { opacity: 0.15; } 50% { opacity: 0.5; } }
    .nr-map-glow { animation: nrGlowPulse 1s ease-in-out infinite; }
    .nr-scroll::-webkit-scrollbar { width: 6px; height: 6px; }
    .nr-scroll::-webkit-scrollbar-thumb { background: #cbd5c9; border-radius: 999px; }
  `}</style>
);

/* ============================================================
   DATA
============================================================ */
const CITIES = {
  guwahati: { name: "Guwahati", x: 360, y: 260 },
  shillong: { name: "Shillong", x: 405, y: 300 },
  silchar: { name: "Silchar", x: 445, y: 380 },
  aizawl: { name: "Aizawl", x: 470, y: 470 },
  agartala: { name: "Agartala", x: 375, y: 450 },
  imphal: { name: "Imphal", x: 545, y: 400 },
  kohima: { name: "Kohima", x: 520, y: 335 },
  itanagar: { name: "Itanagar", x: 470, y: 165 },
  gangtok: { name: "Gangtok", x: 175, y: 165 },
  dispur: { name: "Dispur", x: 372, y: 265 },
};

/* State-level context for the map — additive visual layer, does not affect routing/logic */
const STATE_REGIONS = [
  { name: "Sikkim", cx: 175, cy: 165, rx: 58, ry: 52, color: "#4338ca", labelDx: 0, labelDy: -60 },
  { name: "Arunachal Pradesh", cx: 465, cy: 145, rx: 150, ry: 62, color: "#7c3aed", labelDx: 0, labelDy: -66 },
  { name: "Assam", cx: 378, cy: 258, rx: 140, ry: 52, color: "#d97706", labelDx: -95, labelDy: 4 },
  { name: "Nagaland", cx: 528, cy: 315, rx: 55, ry: 55, color: "#c2410c", labelDx: 40, labelDy: -48 },
  { name: "Manipur", cx: 548, cy: 400, rx: 52, ry: 55, color: "#0369a1", labelDx: 48, labelDy: 4 },
  { name: "Meghalaya", cx: 408, cy: 312, rx: 68, ry: 42, color: "#16a34a", labelDx: -8, labelDy: 46 },
  { name: "Tripura", cx: 375, cy: 450, rx: 42, ry: 42, color: "#0d9488", labelDx: -55, labelDy: 8 },
  { name: "Mizoram", cx: 470, cy: 478, rx: 48, ry: 55, color: "#be185d", labelDx: 8, labelDy: 60 },
];
const MINOR_TOWNS = [
  { name: "Nalbari", x: 330, y: 245 }, { name: "Tezpur", x: 400, y: 220 }, { name: "Nagaon", x: 410, y: 250 },
  { name: "Jowai", x: 430, y: 305 }, { name: "Nongpoh", x: 385, y: 285 },
  { name: "Karimganj", x: 465, y: 400 }, { name: "Hailakandi", x: 455, y: 395 },
  { name: "Lunglei", x: 455, y: 500 }, { name: "Champhai", x: 495, y: 460 },
  { name: "Churachandpur", x: 530, y: 425 }, { name: "Ukhrul", x: 565, y: 385 },
  { name: "Dimapur", x: 505, y: 320 }, { name: "Mokokchung", x: 535, y: 295 },
  { name: "Along", x: 445, y: 175 }, { name: "Ziro", x: 480, y: 190 },
  { name: "Udaipur", x: 385, y: 470 }, { name: "Dharmanagar", x: 395, y: 425 },
  { name: "Namchi", x: 168, y: 190 },
];
const ROUTE_STATE = {
  "R-GHY-SHL": "Meghalaya", "R-GHY-IMP": "Manipur", "R-GHY-KOH": "Nagaland", "R-GHY-AGT": "Tripura",
  "R-GHY-ITA": "Arunachal Pradesh", "R-GHY-GTK": "Sikkim", "R-SHL-SIL": "Assam", "R-SIL-AIZ": "Mizoram", "R-GHY-AIZ": "Mizoram",
};
/* Simulated IoT sensor network — additive live-data layer for the map */
const IOT_SENSORS = [
  { id: "IOT-01", name: "Barak River Bridge Sensor", routeId: "R-SIL-AIZ", rainfall: "12.4 mm", waterLevel: "2.8 m", soil: "Normal", status: "high" },
  { id: "IOT-02", name: "Kohima Pass Sensor", routeId: "R-GHY-KOH", rainfall: "3.1 mm", waterLevel: "—", soil: "Elevated", status: "moderate" },
  { id: "IOT-03", name: "Silchar Corridor Sensor", routeId: "R-SHL-SIL", rainfall: "1.0 mm", waterLevel: "0.9 m", soil: "Normal", status: "safe" },
];

const RISK_TIERS = {
  safe: { label: "Safe / Low Risk", short: "SAFE TO GO", text: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-300", dot: "bg-emerald-500", solid: "bg-emerald-600", ring: "ring-emerald-200", hex: "#059669" },
  moderate: { label: "Moderate Risk", short: "CAUTION", text: "text-amber-700", bg: "bg-amber-50", border: "border-amber-300", dot: "bg-amber-500", solid: "bg-amber-500", ring: "ring-amber-200", hex: "#d97706" },
  high: { label: "High Risk", short: "HIGH RISK", text: "text-red-700", bg: "bg-red-50", border: "border-red-300", dot: "bg-red-500", solid: "bg-red-600", ring: "ring-red-200", hex: "#dc2626" },
  blocked: { label: "Blocked", short: "BLOCKED", text: "text-red-50", bg: "bg-red-900", border: "border-red-950", dot: "bg-red-900", solid: "bg-red-900", ring: "ring-red-300", hex: "#7f1d1d" },
};
function riskTier(score) {
  if (score <= 35) return "safe";
  if (score <= 65) return "moderate";
  if (score <= 90) return "high";
  return "blocked";
}
const WORD_TIER = { LOW: "safe", MODERATE: "moderate", HIGH: "high", "—": "moderate" };

const MAP_ROUTES_BASE = [
  { id: "R-GHY-SHL", from: "guwahati", to: "shillong", risk: 14, label: "NH-40" },
  { id: "R-GHY-AIZ", from: "guwahati", to: "aizawl", risk: 27, label: "Route B · via Silchar" },
  { id: "R-GHY-IMP", from: "guwahati", to: "imphal", risk: 58, label: "NH-37" },
  { id: "R-GHY-KOH", from: "guwahati", to: "kohima", risk: 81, label: "NH-29" },
  { id: "R-GHY-AGT", from: "guwahati", to: "agartala", risk: 34, label: "NH-08" },
  { id: "R-GHY-ITA", from: "guwahati", to: "itanagar", risk: 22, label: "NH-15" },
  { id: "R-GHY-GTK", from: "guwahati", to: "gangtok", risk: 91, label: "NH-10" },
  { id: "R-SHL-SIL", from: "shillong", to: "silchar", risk: 45, label: "NH-06" },
  { id: "R-SIL-AIZ", from: "silchar", to: "aizawl", risk: 63, label: "Route C · via Shillong Bypass" },
];

const ROUTE_OPTIONS = [
  { id: "A", name: "Route A", via: "via Kohima Pass", distance: "612 km", eta: "14h 20m", risk: 81, status: "AVOID", weather: "Heavy Rain", landslide: "High", flood: "Moderate", road: "Poor", traffic: "Heavy", incidents: 2 },
  { id: "B", name: "Route B", via: "via Silchar", distance: "588 km", eta: "12h 45m", risk: 27, status: "RECOMMENDED", weather: "Low Risk", landslide: "Low", flood: "Low", road: "Good", traffic: "Moderate", incidents: 0 },
  { id: "C", name: "Route C", via: "via Shillong Bypass", distance: "602 km", eta: "13h 30m", risk: 53, status: "ALTERNATE", weather: "Moderate", landslide: "Moderate", flood: "Low", road: "Fair", traffic: "Moderate", incidents: 1 },
];

const VEHICLES_INIT = [
  { id: "NER-MED-024", driver: "R. Lalrinliana", cargo: "Medical Supplies", origin: "Guwahati", destination: "Aizawl", routeId: "R-GHY-AIZ", pos: 0.32, speed: 42, eta: "12:45 PM", risk: 27, status: "ON TIME" },
  { id: "NER-LOG-071", driver: "K. Borah", cargo: "Construction Materials", origin: "Guwahati", destination: "Shillong", routeId: "R-GHY-SHL", pos: 0.6, speed: 38, eta: "3:10 PM", risk: 14, status: "ON TIME" },
  { id: "NER-FD-108", driver: "M. Sangma", cargo: "Food", origin: "Guwahati", destination: "Imphal", routeId: "R-GHY-IMP", pos: 0.4, speed: 0, eta: "6:40 PM", risk: 58, status: "DELAYED" },
  { id: "NER-EQP-019", driver: "T. Ngullie", cargo: "Emergency Equipment", origin: "Guwahati", destination: "Kohima", routeId: "R-GHY-KOH", pos: 0.75, speed: 30, eta: "5:15 PM", risk: 81, status: "AT RISK" },
  { id: "NER-AGR-153", driver: "P. Debbarma", cargo: "Agricultural Produce", origin: "Guwahati", destination: "Agartala", routeId: "R-GHY-AGT", pos: 0.5, speed: 45, eta: "2:20 PM", risk: 34, status: "ON TIME" },
];

const SHIPMENTS_INIT = [
  { id: "MED-204", cargo: "Medical Supplies", vehicle: "NER-MED-024", priority: "CRITICAL", eta: "4h 25m", risk: "HIGH", status: "AT RISK", route: "Guwahati → Aizawl", criticality: 94, criticalityReason: "Contains critical medical supplies and is currently travelling through a high-risk corridor with a verified landslide report nearby." },
  { id: "FD-115", cargo: "Food", vehicle: "NER-FD-108", priority: "STANDARD", eta: "6h 10m", risk: "MODERATE", status: "DELAYED", route: "Guwahati → Imphal", criticality: 45, criticalityReason: "Standard food cargo running behind schedule on a moderate-risk corridor; no emergency requirement." },
  { id: "AGR-330", cargo: "Agricultural Produce", vehicle: "NER-AGR-153", priority: "STANDARD", eta: "2h 05m", risk: "LOW", status: "ON TIME", route: "Guwahati → Agartala", criticality: 28, criticalityReason: "Non-perishable produce on a low-risk corridor, on schedule." },
  { id: "CON-045", cargo: "Construction Materials", vehicle: "NER-LOG-071", priority: "STANDARD", eta: "1h 40m", risk: "LOW", status: "ON TIME", route: "Guwahati → Shillong", criticality: 22, criticalityReason: "Non-urgent construction material with no delivery-time sensitivity." },
  { id: "EQP-012", cargo: "Emergency Equipment", vehicle: "NER-EQP-019", priority: "CRITICAL", eta: "3h 55m", risk: "HIGH", status: "CRITICAL", route: "Guwahati → Kohima", criticality: 88, criticalityReason: "Emergency equipment moving through a high-risk mountain corridor with limited alternate access." },
  { id: "MED-198", cargo: "Medical Supplies", vehicle: "—", priority: "STANDARD", eta: "—", risk: "—", status: "DELIVERED", route: "Guwahati → Silchar", criticality: 20, criticalityReason: "Delivery already completed; no further routing risk." },
];

const INCIDENTS_INIT = [
  { id: "INC-3391", type: "Road Damage", location: "Kohima Pass, KM 88 (NH-29)", severity: "HIGH", reportedBy: "Field Officer · T. Ngullie", time: "38 min ago", status: "MONITORING", desc: "Pothole cluster slowing heavy vehicles; single-lane movement advised.", routeId: "R-GHY-KOH", verification: "VERIFIED", sync: "SYNCED" },
  { id: "INC-3388", type: "Flood", location: "Approach road, Silchar bridge crossing", severity: "MODERATE", reportedBy: "Field Officer · S. Devi", time: "1h 12m ago", status: "ACTIVE", desc: "Water level rising near the approach road after continuous rainfall.", routeId: "R-SIL-AIZ", verification: "HIGH CONFIDENCE", sync: "SYNCED" },
];

const ALERTS_INIT = [
  { id: "AL-1001", level: "warning", title: "Heavy Rainfall Expected", detail: "Aizawl corridor, next 6 hours", time: "12 min ago", link: { type: "weather" } },
  { id: "AL-1000", level: "warning", title: "Road Damage Reported", detail: "Kohima Pass, KM 88 — single-lane movement", time: "38 min ago", link: { type: "incident", id: "INC-3391" } },
  { id: "AL-0999", level: "info", title: "Shipment Delayed", detail: "FD-115 running 48 minutes behind schedule", time: "1h ago", link: { type: "shipment", id: "FD-115" } },
  { id: "AL-0998", level: "warning", title: "Flood Risk Rising", detail: "Silchar bridge approach road", time: "1h 12m ago", link: { type: "incident", id: "INC-3388" } },
  { id: "AL-0997", level: "info", title: "Vehicle Delayed", detail: "NER-FD-108 stopped near Imphal corridor", time: "2h ago", link: { type: "vehicle", id: "NER-FD-108" } },
];

const SOS_INIT = [
  { id: "SOS-1042", type: "Medical Emergency", vehicle: "NER-AGR-153", location: "Near Agartala corridor", status: "ACKNOWLEDGED", time: "3h ago", risk: 34, weather: "Clear", timeline: ["Activated", "Acknowledged"] },
  { id: "SOS-1044", type: "Vehicle Breakdown", vehicle: "NER-ITA-032", location: "Near Itanagar, NH-15", status: "DISPATCHED", time: "2h 40m ago", risk: 22, weather: "Clear", timeline: ["Activated", "Acknowledged", "Response Assigned", "Dispatched"] },
  { id: "SOS-1045", type: "Road Blockage", vehicle: "NER-GTK-009", location: "Near Gangtok, NH-10", status: "RESPONSE ASSIGNED", time: "1h 55m ago", risk: 91, weather: "Snow", timeline: ["Activated", "Acknowledged", "Response Assigned"] },
  { id: "SOS-1046", type: "Accident", vehicle: "NER-KOH-014", location: "Kohima Pass, KM 88", status: "DISPATCHED", time: "1h 10m ago", risk: 81, weather: "Overcast", timeline: ["Activated", "Acknowledged", "Response Assigned", "Dispatched"] },
  { id: "SOS-1047", type: "Flood", vehicle: "NER-SIL-002", location: "Near Silchar bridge", status: "ACTIVE", time: "40 min ago", risk: 63, weather: "Heavy Rain", timeline: ["Activated"] },
];

const NOTIFS_INIT = [
  { id: "N-01", title: "Route risk updated", detail: "Guwahati → Aizawl corridor risk changed", time: "10 min ago", read: false, link: { type: "routes" } },
  { id: "N-02", title: "Shipment delayed", detail: "FD-115 running behind schedule", time: "1h ago", read: false, link: { type: "shipment", id: "FD-115" } },
  { id: "N-03", title: "Field report submitted", detail: "Road damage report near Kohima Pass", time: "38 min ago", read: true, link: { type: "incident", id: "INC-3391" } },
  { id: "N-04", title: "Weekly accessibility summary", detail: "128 corridors accessible across NER", time: "Yesterday", read: true, link: { type: "dashboard" } },
];

const CITY_LIST = ["Guwahati", "Shillong", "Aizawl", "Imphal", "Kohima", "Agartala", "Itanagar", "Gangtok", "Silchar", "Dispur"];
const COMMODITIES = ["Medical Supplies", "Food", "Agricultural Produce", "Construction Materials", "Emergency Equipment"];
const INCIDENT_TYPES = ["Landslide", "Flood", "Road Damage", "Bridge Damage", "Traffic", "Accident", "Road Blockage", "Other"];
const SOS_TYPES = ["Medical Emergency", "Accident", "Landslide", "Flood", "Vehicle Breakdown", "Road Blockage", "Other"];

const DEMO_USERS = {
  driver: { id: "driver@neraah.demo", name: "Ramdinliana Pachuau", role: "Driver", org: "NER State Logistics Corp.", district: "Aizawl", phone: "+91 98620 11234", email: "driver@neraah.demo", language: "en", emergencyContact: "+91 98620 55678", vehicleId: "NER-MED-024", photo: null, employeeId: "NER-EMP-4821", accountStatus: "Active", lastLogin: "Today, 07:12 AM" },
  officer: { id: "officer@neraah.demo", name: "Sonam Devi", role: "Field Officer", org: "District Disaster Management Authority", district: "Cachar", phone: "+91 94350 22987", email: "officer@neraah.demo", language: "en", emergencyContact: "+91 94350 11223", vehicleId: "—", photo: null, employeeId: "NER-EMP-2937", accountStatus: "Active", lastLogin: "Today, 08:04 AM" },
  authority: { id: "authority@neraah.demo", name: "Er. Bipul Kalita", role: "Authority", org: "NER Logistics Command Center", district: "Kamrup (Metro)", phone: "+91 98540 77321", email: "authority@neraah.demo", language: "en", emergencyContact: "+91 98540 00111", vehicleId: "—", photo: null, employeeId: "NER-EMP-1006", accountStatus: "Active", lastLogin: "Today, 06:48 AM" },
};

/* ============================================================
   NER SITUATION ROOM · ACCESSIBILITY INDEX · GROUND TRUTH ·
   RESILIENCE MODE · CRITICALITY — supporting data
============================================================ */
const REGIONS = [
  { key: "assam", name: "Assam", score: 82, cityKey: "guwahati" },
  { key: "meghalaya", name: "Meghalaya", score: 71, cityKey: "shillong" },
  { key: "tripura", name: "Tripura", score: 75, cityKey: "agartala" },
  { key: "mizoram", name: "Mizoram", score: 64, cityKey: "aizawl" },
  { key: "nagaland", name: "Nagaland", score: 69, cityKey: "kohima" },
  { key: "sikkim", name: "Sikkim", score: 61, cityKey: "gangtok" },
  { key: "manipur", name: "Manipur", score: 58, cityKey: "imphal" },
  { key: "arunachal", name: "Arunachal Pradesh", score: 43, cityKey: "itanagar" },
];
function accessTier(score) {
  if (score >= 80) return { label: "GOOD", tier: "safe" };
  if (score >= 60) return { label: "MODERATE", tier: "moderate" };
  if (score >= 40) return { label: "AT RISK", tier: "high" };
  return { label: "SEVERE DISRUPTION", tier: "blocked" };
}

const ROUTE_TIMELINE_INIT = [
  { id: "T1", time: "08:10 AM", icon: "🟢", title: "Normal Conditions", location: "Guwahati → Aizawl corridor", severity: "LOW", source: "System baseline", impact: "Route B risk steady at 27/100." },
];

function criticalityTier(score) {
  if (score >= 80) return { label: "CRITICAL", icon: "🔴", tone: "darkred" };
  if (score >= 60) return { label: "HIGH", icon: "🟠", tone: "red" };
  if (score >= 40) return { label: "MEDIUM", icon: "🟡", tone: "amber" };
  return { label: "NORMAL", icon: "🟢", tone: "emerald" };
}

/* ============================================================
   TRANSLATIONS
============================================================ */
const LANGS = [
  { code: "en", label: "English" },
  { code: "hi", label: "हिन्दी" },
  { code: "as", label: "অসমীয়া" },
  { code: "bn", label: "বাংলা" },
  { code: "pa", label: "ਪੰਜਾਬੀ" },
];
const T = {
  en: {
    dashboard: "Dashboard", commandCenter: "Command Center", map: "Live Map", routes: "Route Intelligence",
    vehicles: "Vehicles", shipments: "Shipments", alerts: "Alerts", sosCenter: "SOS Center",
    copilot: "AI Logistics Copilot", reports: "Ground Truth Network", weather: "Weather & Risk",
    profile: "Profile", settings: "Settings", logout: "Logout", home: "Home",
    search: "Search vehicles, shipments, routes…", sos: "SOS", more: "More",
    login: "Login", continueAsDemo: "Continue as Demo", save: "Save", cancel: "Cancel", edit: "Edit",
    close: "Close", viewOnMap: "View on Map", viewDetails: "View Details", back: "Back", done: "Done",
    startDemo: "Start Demo Scenario", nextStep: "Next Step", finishDemo: "Finish Demo", viewAll: "View all",
    markAllRead: "Mark all as read", viewWhy: "Why this route?", selectRoute: "Select Route",
    startNavigation: "Start Navigation", playVoiceAlert: "Play Voice Alert", trackVehicle: "Track Vehicle",
    contactDriver: "Contact Driver", reroute: "Reroute", useForRouteRisk: "Use for Route Risk",
    newReport: "New Report", submitReport: "Submit Report", dispatchTeam: "Dispatch Team",
    acknowledge: "Acknowledge", assignResponse: "Assign Response", markDispatched: "Mark Dispatched",
    resolve: "Resolve", escalate: "Escalate", saveChanges: "Save Changes", editProfile: "Edit Profile",
    getRoute: "Get Route", showFullMap: "Show Full Map",
    commandCenterTitle: "NE-RAAH Command Center", commandCenterSub: "Region-wide accessibility and logistics overview",
    welcomeBack: "Welcome", todayFocus: "Here's what needs your attention today",
    quickActions: "Quick Actions", recentAlerts: "Recent Alerts", criticalShipmentsTitle: "Critical Shipments",
    vehiclesInTransit: "Vehicles In Transit", routeIntelTitle: "AI Route Intelligence",
    routeIntelSub: "Compare AI-assisted risk estimates across route alternatives before you commit a shipment.",
    aiRecommends: "NE-RAAH Recommends", whyTitle: "Why?", groundTruthTitle: "Ground Truth Network",
    groundTruthSub: "AI predictions + weather/GIS data + verified field observations, combined.",
    weatherRiskTitle: "Weather & Risk", weatherRiskSub: "Live climate and terrain risk factors feeding the route intelligence engine.",
    sosCenterTitle: "SOS Center", sosCenterSub: "Emergency activations across the network, with live response status.",
    notificationsTitle: "Notifications", fieldReportTitle: "New Field Report",
    myProfileTitle: "Profile", accountDetails: "Account Details", navigationStarted: "Navigation Started",
    vehiclesTitle: "Vehicle Monitoring", vehiclesSub: "Live positions for tracked vehicles across the network.",
    shipmentsTitle: "Logistics & Shipments", shipmentsSub: "Track essential supplies moving across the region.",
    alertsTitle: "Alert Center", alertsSub: "Every alert links to the map, vehicle, shipment or incident behind it.",
    weatherAheadTitle: "Weather Ahead",
    onTime: "ON TIME", delayed: "DELAYED", atRiskStatus: "AT RISK", stopped: "STOPPED", delivered: "DELIVERED",
    criticalStatus: "CRITICAL", activeStatus: "ACTIVE", acknowledgedStatus: "ACKNOWLEDGED",
    responseAssignedStatus: "RESPONSE ASSIGNED", dispatchedStatus: "DISPATCHED", resolvedStatus: "RESOLVED",
    monitoringStatus: "MONITORING", pendingSyncStatus: "PENDING SYNC", syncedStatus: "SYNCED",
    protectedStatus: "PROTECTED / ON TRACK", verifiedStatus: "VERIFIED", pendingStatus: "PENDING",
    highConfidenceStatus: "HIGH CONFIDENCE",
    safeLabel: "SAFE TO GO", moderateLabel: "CAUTION", highRiskLabel: "HIGH RISK", severeLabel: "BLOCKED",
    heavyRain: "Heavy Rain", clearConditions: "Clear conditions ahead", riskColon: "Risk",
    noActiveVehicles: "No active vehicles in this region.", noIncidents: "No incidents reported in this area.",
    allCaughtUp: "You're all caught up.", offlineBanner: "Offline Mode — showing the latest synchronized information.",
    noResultsFound: "No results found", noRouteSelected: "No route selected",
    noRouteSelectedSub: "Choose a source and destination above to see route options.",
    noFieldReports: "No field reports yet", noActiveEmergencies: "No active emergencies",
    noNotifications: "No notifications yet", noShipmentsView: "No shipments in this view",
    logoutConfirmTitle: "Are you sure you want to log out?", logoutConfirmBody: "You'll need to log in again to access NE-RAAH.",
    fullName: "Full Name", role: "Role", organization: "Organization", employeeId: "Employee ID",
    phone: "Phone", email: "Email", location: "Location / District", preferredLanguage: "Preferred Language",
    emergencyContact: "Emergency Contact", accountStatus: "Account Status", lastLogin: "Last Login",
    vehicleIdLabel: "Vehicle ID", changeLanguage: "Change Language", notificationSettings: "Notification Settings",
    offlineData: "Offline Data", security: "Security", profileUpdated: "Profile updated successfully.",
    source: "Source", destination: "Destination", distance: "Distance", eta: "ETA",
    weatherLabel: "Weather", roadLabel: "Road", trafficLabel: "Traffic", incidentsLabel: "Incidents", noneLabel: "None",
    emergencyActivated: "EMERGENCY ACTIVATED", pressHold: "Press and hold for 2 seconds",
  
    onlineLabel: "ONLINE", offlineLabel: "OFFLINE", sosActiveLabel: "SOS Active",
    accessibleCorridors: "Accessible Corridors", atRiskCorridors: "At-Risk Corridors", blockedRoads: "Blocked Roads",
    blockedCorridors: "Blocked Corridors", activeFieldReportsLabel: "Active Field Reports", weatherImpactedAreas: "Weather-Impacted Areas",
    activeVehiclesLabel: "Active Vehicles", fieldReportsLabel: "Field Reports", activeSOSLabel: "Active SOS", weatherAlertsLabel: "Weather Alerts",
    nerLogisticsHealth: "NER Logistics Health", viewOverview: "View Overview", viewVehiclesAction: "View Vehicles", viewSOSAction: "View SOS",
    immediateAttention: "Immediate attention required", overallScoreDesc: "Overall regional accessibility & disruption score",
    allLabel: "ALL", continueToward: "Continue toward", endNavigation: "End Navigation",
    voiceHeavyRain: "Heads up. Heavy rainfall is expected four kilometres ahead.", voiceRouteClear: "Route is clear. Continue as planned.",
    voiceLandslideWarning: "Warning. A landslide has been reported 3.2 kilometers ahead. A safer route is available.",
  },
  hi: {
    dashboard: "डैशबोर्ड", commandCenter: "कमांड सेंटर", map: "लाइव मैप", routes: "रूट इंटेलिजेंस",
    vehicles: "वाहन", shipments: "शिपमेंट", alerts: "अलर्ट", sosCenter: "SOS केंद्र",
    copilot: "AI लॉजिस्टिक्स कोपायलट", reports: "ग्राउंड ट्रुथ नेटवर्क", weather: "मौसम व जोखिम",
    profile: "प्रोफ़ाइल", settings: "सेटिंग्स", logout: "लॉगआउट", home: "होम",
    search: "वाहन, शिपमेंट, रूट खोजें…", sos: "SOS", more: "अधिक",
    login: "लॉगिन", continueAsDemo: "डेमो के रूप में जारी रखें", save: "सेव करें", cancel: "रद्द करें", edit: "संपादित करें",
    close: "बंद करें", viewOnMap: "मैप पर देखें", viewDetails: "विवरण देखें", back: "वापस", done: "पूर्ण",
    startDemo: "डेमो परिदृश्य शुरू करें", nextStep: "अगला चरण", finishDemo: "डेमो समाप्त करें", viewAll: "सभी देखें",
    markAllRead: "सभी को पढ़ा हुआ चिह्नित करें", viewWhy: "यह रूट क्यों?", selectRoute: "रूट चुनें",
    startNavigation: "नेविगेशन शुरू करें", playVoiceAlert: "वॉइस अलर्ट चलाएं", trackVehicle: "वाहन ट्रैक करें",
    contactDriver: "ड्राइवर से संपर्क करें", reroute: "रीरूट करें", useForRouteRisk: "रूट जोखिम हेतु उपयोग करें",
    newReport: "नई रिपोर्ट", submitReport: "रिपोर्ट सबमिट करें", dispatchTeam: "टीम भेजें",
    acknowledge: "स्वीकार करें", assignResponse: "प्रतिक्रिया सौंपें", markDispatched: "भेजा गया चिह्नित करें",
    resolve: "समाधान करें", escalate: "एस्केलेट करें", saveChanges: "बदलाव सेव करें", editProfile: "प्रोफ़ाइल संपादित करें",
    getRoute: "रूट प्राप्त करें", showFullMap: "पूरा मैप दिखाएं",
    commandCenterTitle: "NE-RAAH कमांड सेंटर", commandCenterSub: "क्षेत्रव्यापी पहुंच और लॉजिस्टिक्स अवलोकन",
    welcomeBack: "स्वागत है", todayFocus: "आज आपको इन बातों पर ध्यान देना है",
    quickActions: "त्वरित कार्य", recentAlerts: "हालिया अलर्ट", criticalShipmentsTitle: "क्रिटिकल शिपमेंट",
    vehiclesInTransit: "मार्ग में वाहन", routeIntelTitle: "AI रूट इंटेलिजेंस",
    routeIntelSub: "शिपमेंट भेजने से पहले रूट विकल्पों के AI-सहायता प्राप्त जोखिम अनुमान की तुलना करें।",
    aiRecommends: "NE-RAAH की सिफारिश", whyTitle: "क्यों?", groundTruthTitle: "ग्राउंड ट्रुथ नेटवर्क",
    groundTruthSub: "AI भविष्यवाणी + मौसम/GIS डेटा + सत्यापित फील्ड अवलोकन, एक साथ।",
    weatherRiskTitle: "मौसम व जोखिम", weatherRiskSub: "रूट इंटेलिजेंस इंजन को फीड करने वाले लाइव जलवायु और भू-भाग जोखिम कारक।",
    sosCenterTitle: "SOS केंद्र", sosCenterSub: "नेटवर्क में आपातकालीन सक्रियण, लाइव प्रतिक्रिया स्थिति के साथ।",
    notificationsTitle: "सूचनाएं", fieldReportTitle: "नई फील्ड रिपोर्ट",
    myProfileTitle: "प्रोफ़ाइल", accountDetails: "खाता विवरण", navigationStarted: "नेविगेशन शुरू हुआ",
    vehiclesTitle: "वाहन निगरानी", vehiclesSub: "नेटवर्क में ट्रैक किए गए वाहनों की लाइव स्थिति।",
    shipmentsTitle: "लॉजिस्टिक्स व शिपमेंट", shipmentsSub: "क्षेत्र में आवश्यक आपूर्ति की ट्रैकिंग।",
    alertsTitle: "अलर्ट सेंटर", alertsSub: "हर अलर्ट संबंधित मैप, वाहन, शिपमेंट या घटना से जुड़ा है।",
    weatherAheadTitle: "आगे का मौसम",
    onTime: "समय पर", delayed: "विलंबित", atRiskStatus: "जोखिम में", stopped: "रुका हुआ", delivered: "डिलीवर हुआ",
    criticalStatus: "क्रिटिकल", activeStatus: "सक्रिय", acknowledgedStatus: "स्वीकृत",
    responseAssignedStatus: "प्रतिक्रिया सौंपी गई", dispatchedStatus: "भेजा गया", resolvedStatus: "समाधान हुआ",
    monitoringStatus: "निगरानी में", pendingSyncStatus: "सिंक लंबित", syncedStatus: "सिंक हो गया",
    protectedStatus: "सुरक्षित / ट्रैक पर", verifiedStatus: "सत्यापित", pendingStatus: "लंबित",
    highConfidenceStatus: "उच्च विश्वास",
    safeLabel: "जाने के लिए सुरक्षित", moderateLabel: "सावधानी", highRiskLabel: "उच्च जोखिम", severeLabel: "अवरुद्ध",
    heavyRain: "भारी बारिश", clearConditions: "आगे मौसम साफ़ है", riskColon: "जोखिम",
    noActiveVehicles: "इस क्षेत्र में कोई सक्रिय वाहन नहीं है।", noIncidents: "इस क्षेत्र में कोई घटना दर्ज नहीं है।",
    allCaughtUp: "आप पूरी तरह अपडेट हैं।", offlineBanner: "ऑफ़लाइन मोड — नवीनतम सिंक की गई जानकारी दिखाई जा रही है।",
    noResultsFound: "कोई परिणाम नहीं मिला", noRouteSelected: "कोई रूट चयनित नहीं",
    noRouteSelectedSub: "रूट विकल्प देखने के लिए ऊपर स्रोत और गंतव्य चुनें।",
    noFieldReports: "अभी तक कोई फील्ड रिपोर्ट नहीं", noActiveEmergencies: "कोई सक्रिय आपातकाल नहीं",
    noNotifications: "अभी तक कोई सूचना नहीं", noShipmentsView: "इस दृश्य में कोई शिपमेंट नहीं",
    logoutConfirmTitle: "क्या आप वाकई लॉगआउट करना चाहते हैं?", logoutConfirmBody: "NE-RAAH में दोबारा प्रवेश हेतु आपको फिर से लॉगिन करना होगा।",
    fullName: "पूरा नाम", role: "भूमिका", organization: "संगठन", employeeId: "कर्मचारी ID",
    phone: "फ़ोन", email: "ईमेल", location: "स्थान / जिला", preferredLanguage: "पसंदीदा भाषा",
    emergencyContact: "आपातकालीन संपर्क", accountStatus: "खाता स्थिति", lastLogin: "अंतिम लॉगिन",
    vehicleIdLabel: "वाहन ID", changeLanguage: "भाषा बदलें", notificationSettings: "सूचना सेटिंग्स",
    offlineData: "ऑफ़लाइन डेटा", security: "सुरक्षा", profileUpdated: "प्रोफ़ाइल सफलतापूर्वक अपडेट हुई।",
    source: "स्रोत", destination: "गंतव्य", distance: "दूरी", eta: "अनुमानित समय",
    weatherLabel: "मौसम", roadLabel: "सड़क", trafficLabel: "ट्रैफ़िक", incidentsLabel: "घटनाएं", noneLabel: "कोई नहीं",
    emergencyActivated: "आपातकाल सक्रिय", pressHold: "2 सेकंड तक दबाए रखें",
  
    onlineLabel: "ऑनलाइन", offlineLabel: "ऑफ़लाइन", sosActiveLabel: "SOS सक्रिय",
    accessibleCorridors: "सुलभ कॉरिडोर", atRiskCorridors: "जोखिम में कॉरिडोर", blockedRoads: "अवरुद्ध सड़कें",
    blockedCorridors: "अवरुद्ध कॉरिडोर", activeFieldReportsLabel: "सक्रिय फील्ड रिपोर्ट", weatherImpactedAreas: "मौसम प्रभावित क्षेत्र",
    activeVehiclesLabel: "सक्रिय वाहन", fieldReportsLabel: "फील्ड रिपोर्ट", activeSOSLabel: "सक्रिय SOS", weatherAlertsLabel: "मौसम अलर्ट",
    nerLogisticsHealth: "NER लॉजिस्टिक्स स्वास्थ्य", viewOverview: "अवलोकन देखें", viewVehiclesAction: "वाहन देखें", viewSOSAction: "SOS देखें",
    immediateAttention: "तुरंत ध्यान देने की आवश्यकता", overallScoreDesc: "समग्र क्षेत्रीय पहुंच व व्यवधान स्कोर",
    allLabel: "सभी", continueToward: "की ओर बढ़ते रहें", endNavigation: "नेविगेशन समाप्त करें",
    voiceHeavyRain: "ध्यान दें। लगभग चार किलोमीटर आगे भारी बारिश की संभावना है।", voiceRouteClear: "रूट साफ़ है। योजना अनुसार आगे बढ़ें।",
    voiceLandslideWarning: "चेतावनी। 3.2 किलोमीटर आगे भूस्खलन की सूचना मिली है। एक सुरक्षित रूट उपलब्ध है।",
  },
  bn: {
    dashboard: "ড্যাশবোর্ড", commandCenter: "কমান্ড সেন্টার", map: "লাইভ ম্যাপ", routes: "রুট ইন্টেলিজেন্স",
    vehicles: "যানবাহন", shipments: "চালান", alerts: "সতর্কতা", sosCenter: "SOS কেন্দ্র",
    copilot: "AI লজিস্টিকস কোপাইলট", reports: "গ্রাউন্ড ট্রুথ নেটওয়ার্ক", weather: "আবহাওয়া ও ঝুঁকি",
    profile: "প্রোফাইল", settings: "সেটিংস", logout: "লগআউট", home: "হোম",
    search: "যানবাহন, চালান, রুট খুঁজুন…", sos: "SOS", more: "আরও",
    login: "লগইন", continueAsDemo: "ডেমো হিসেবে চালিয়ে যান", save: "সংরক্ষণ করুন", cancel: "বাতিল", edit: "সম্পাদনা",
    close: "বন্ধ করুন", viewOnMap: "মানচিত্রে দেখুন", viewDetails: "বিস্তারিত দেখুন", back: "ফিরে যান", done: "সম্পন্ন",
    startDemo: "ডেমো দৃশ্য শুরু করুন", nextStep: "পরবর্তী ধাপ", finishDemo: "ডেমো শেষ করুন", viewAll: "সব দেখুন",
    markAllRead: "সব পঠিত হিসেবে চিহ্নিত করুন", viewWhy: "এই রুট কেন?", selectRoute: "রুট নির্বাচন করুন",
    startNavigation: "নেভিগেশন শুরু করুন", playVoiceAlert: "ভয়েস অ্যালার্ট চালান", trackVehicle: "যান ট্র্যাক করুন",
    contactDriver: "চালকের সাথে যোগাযোগ করুন", reroute: "রুট পরিবর্তন করুন", useForRouteRisk: "রুট ঝুঁকির জন্য ব্যবহার করুন",
    newReport: "নতুন রিপোর্ট", submitReport: "রিপোর্ট জমা দিন", dispatchTeam: "টিম পাঠান",
    acknowledge: "স্বীকার করুন", assignResponse: "প্রতিক্রিয়া নিয়োগ করুন", markDispatched: "প্রেরিত চিহ্নিত করুন",
    resolve: "সমাধান করুন", escalate: "এসকেলেট করুন", saveChanges: "পরিবর্তন সংরক্ষণ করুন", editProfile: "প্রোফাইল সম্পাদনা করুন",
    getRoute: "রুট নিন", showFullMap: "সম্পূর্ণ মানচিত্র দেখান",
    commandCenterTitle: "NE-RAAH কমান্ড সেন্টার", commandCenterSub: "অঞ্চলব্যাপী প্রবেশযোগ্যতা ও লজিস্টিকস পর্যালোচনা",
    welcomeBack: "স্বাগতম", todayFocus: "আজ আপনার যা নজরে রাখা দরকার",
    quickActions: "দ্রুত কার্যক্রম", recentAlerts: "সাম্প্রতিক সতর্কতা", criticalShipmentsTitle: "জরুরি চালান",
    vehiclesInTransit: "চলমান যানবাহন", routeIntelTitle: "AI রুট ইন্টেলিজেন্স",
    routeIntelSub: "চালান পাঠানোর আগে রুট বিকল্পগুলির AI-সহায়ক ঝুঁকি অনুমান তুলনা করুন।",
    aiRecommends: "NE-RAAH এর সুপারিশ", whyTitle: "কেন?", groundTruthTitle: "গ্রাউন্ড ট্রুথ নেটওয়ার্ক",
    groundTruthSub: "AI পূর্বাভাস + আবহাওয়া/GIS তথ্য + যাচাইকৃত ফিল্ড পর্যবেক্ষণ, একত্রে।",
    weatherRiskTitle: "আবহাওয়া ও ঝুঁকি", weatherRiskSub: "রুট ইন্টেলিজেন্স ইঞ্জিনে সরবরাহকারী লাইভ জলবায়ু ও ভূখণ্ড ঝুঁকির কারণ।",
    sosCenterTitle: "SOS কেন্দ্র", sosCenterSub: "নেটওয়ার্ক জুড়ে জরুরি সক্রিয়করণ, লাইভ প্রতিক্রিয়া অবস্থাসহ।",
    notificationsTitle: "বিজ্ঞপ্তি", fieldReportTitle: "নতুন ফিল্ড রিপোর্ট",
    myProfileTitle: "প্রোফাইল", accountDetails: "অ্যাকাউন্ট বিবরণ", navigationStarted: "নেভিগেশন শুরু হয়েছে",
    vehiclesTitle: "যানবাহন পর্যবেক্ষণ", vehiclesSub: "নেটওয়ার্ক জুড়ে ট্র্যাক করা যানবাহনের লাইভ অবস্থান।",
    shipmentsTitle: "লজিস্টিকস ও চালান", shipmentsSub: "অঞ্চল জুড়ে প্রয়োজনীয় সরবরাহ ট্র্যাক করুন।",
    alertsTitle: "সতর্কতা কেন্দ্র", alertsSub: "প্রতিটি সতর্কতা মানচিত্র, যান, চালান বা ঘটনার সাথে যুক্ত।",
    weatherAheadTitle: "সামনে আবহাওয়া",
    onTime: "সময়মতো", delayed: "বিলম্বিত", atRiskStatus: "ঝুঁকিতে", stopped: "থামানো", delivered: "সরবরাহ হয়েছে",
    criticalStatus: "জরুরি", activeStatus: "সক্রিয়", acknowledgedStatus: "স্বীকৃত",
    responseAssignedStatus: "প্রতিক্রিয়া নিয়োগ হয়েছে", dispatchedStatus: "প্রেরিত", resolvedStatus: "সমাধান হয়েছে",
    monitoringStatus: "পর্যবেক্ষণে", pendingSyncStatus: "সিঙ্ক মুলতুবি", syncedStatus: "সিঙ্ক হয়েছে",
    protectedStatus: "সুরক্ষিত / ট্র্যাকে", verifiedStatus: "যাচাইকৃত", pendingStatus: "মুলতুবি",
    highConfidenceStatus: "উচ্চ আস্থা",
    safeLabel: "যাওয়ার জন্য নিরাপদ", moderateLabel: "সতর্কতা", highRiskLabel: "উচ্চ ঝুঁকি", severeLabel: "অবরুদ্ধ",
    heavyRain: "ভারী বৃষ্টি", clearConditions: "সামনে আবহাওয়া পরিষ্কার", riskColon: "ঝুঁকি",
    noActiveVehicles: "এই অঞ্চলে কোনো সক্রিয় যান নেই।", noIncidents: "এই এলাকায় কোনো ঘটনা রিপোর্ট করা হয়নি।",
    allCaughtUp: "আপনি সম্পূর্ণ আপডেটেড।", offlineBanner: "অফলাইন মোড — সর্বশেষ সিঙ্ক করা তথ্য দেখানো হচ্ছে।",
    noResultsFound: "কোনো ফলাফল পাওয়া যায়নি", noRouteSelected: "কোনো রুট নির্বাচিত নয়",
    noRouteSelectedSub: "রুট বিকল্প দেখতে উপরে উৎস ও গন্তব্য নির্বাচন করুন।",
    noFieldReports: "এখনও কোনো ফিল্ড রিপোর্ট নেই", noActiveEmergencies: "কোনো সক্রিয় জরুরি অবস্থা নেই",
    noNotifications: "এখনও কোনো বিজ্ঞপ্তি নেই", noShipmentsView: "এই দৃশ্যে কোনো চালান নেই",
    logoutConfirmTitle: "আপনি কি নিশ্চিত লগআউট করতে চান?", logoutConfirmBody: "NE-RAAH ব্যবহার করতে আপনাকে আবার লগইন করতে হবে।",
    fullName: "পুরো নাম", role: "ভূমিকা", organization: "প্রতিষ্ঠান", employeeId: "কর্মচারী ID",
    phone: "ফোন", email: "ইমেইল", location: "অবস্থান / জেলা", preferredLanguage: "পছন্দের ভাষা",
    emergencyContact: "জরুরি যোগাযোগ", accountStatus: "অ্যাকাউন্ট অবস্থা", lastLogin: "সর্বশেষ লগইন",
    vehicleIdLabel: "যান ID", changeLanguage: "ভাষা পরিবর্তন করুন", notificationSettings: "বিজ্ঞপ্তি সেটিংস",
    offlineData: "অফলাইন তথ্য", security: "নিরাপত্তা", profileUpdated: "প্রোফাইল সফলভাবে আপডেট হয়েছে।",
    source: "উৎস", destination: "গন্তব্য", distance: "দূরত্ব", eta: "প্রত্যাশিত সময়",
    weatherLabel: "আবহাওয়া", roadLabel: "রাস্তা", trafficLabel: "ট্রাফিক", incidentsLabel: "ঘটনা", noneLabel: "কোনোটি নয়",
    emergencyActivated: "জরুরি অবস্থা সক্রিয়", pressHold: "২ সেকেন্ড ধরে চেপে রাখুন",
  
    onlineLabel: "অনলাইন", offlineLabel: "অফলাইন", sosActiveLabel: "SOS সক্রিয়",
    accessibleCorridors: "প্রবেশযোগ্য করিডোর", atRiskCorridors: "ঝুঁকিপূর্ণ করিডোর", blockedRoads: "অবরুদ্ধ রাস্তা",
    blockedCorridors: "অবরুদ্ধ করিডোর", activeFieldReportsLabel: "সক্রিয় ফিল্ড রিপোর্ট", weatherImpactedAreas: "আবহাওয়া প্রভাবিত এলাকা",
    activeVehiclesLabel: "সক্রিয় যানবাহন", fieldReportsLabel: "ফিল্ড রিপোর্ট", activeSOSLabel: "সক্রিয় SOS", weatherAlertsLabel: "আবহাওয়া সতর্কতা",
    nerLogisticsHealth: "NER লজিস্টিকস স্বাস্থ্য", viewOverview: "পর্যালোচনা দেখুন", viewVehiclesAction: "যানবাহন দেখুন", viewSOSAction: "SOS দেখুন",
    immediateAttention: "তাৎক্ষণিক মনোযোগ প্রয়োজন", overallScoreDesc: "সামগ্রিক আঞ্চলিক প্রবেশযোগ্যতা ও বিঘ্ন স্কোর",
    allLabel: "সব", continueToward: "এর দিকে এগিয়ে যান", endNavigation: "নেভিগেশন শেষ করুন",
    voiceHeavyRain: "সতর্কতা। প্রায় চার কিলোমিটার সামনে ভারী বৃষ্টির সম্ভাবনা।", voiceRouteClear: "রুট পরিষ্কার। পরিকল্পনা অনুযায়ী এগিয়ে যান।",
    voiceLandslideWarning: "সতর্কতা। ৩.২ কিলোমিটার সামনে ভূমিধসের খবর পাওয়া গেছে। একটি নিরাপদ রুট উপলব্ধ।",
  },
  pa: {
    dashboard: "ਡੈਸ਼ਬੋਰਡ", commandCenter: "ਕਮਾਂਡ ਸੈਂਟਰ", map: "ਲਾਈਵ ਨਕਸ਼ਾ", routes: "ਰੂਟ ਇੰਟੈਲੀਜੈਂਸ",
    vehicles: "ਵਾਹਨ", shipments: "ਸ਼ਿਪਮੈਂਟ", alerts: "ਚੇਤਾਵਨੀਆਂ", sosCenter: "SOS ਕੇਂਦਰ",
    copilot: "AI ਲੌਜਿਸਟਿਕਸ ਕੋਪਾਇਲਟ", reports: "ਗਰਾਊਂਡ ਟਰੁੱਥ ਨੈੱਟਵਰਕ", weather: "ਮੌਸਮ ਤੇ ਖ਼ਤਰਾ",
    profile: "ਪ੍ਰੋਫਾਈਲ", settings: "ਸੈਟਿੰਗਾਂ", logout: "ਲਾਗਆਉਟ", home: "ਹੋਮ",
    search: "ਵਾਹਨ, ਸ਼ਿਪਮੈਂਟ, ਰੂਟ ਖੋਜੋ…", sos: "SOS", more: "ਹੋਰ",
    login: "ਲਾਗਇਨ", continueAsDemo: "ਡੈਮੋ ਵਜੋਂ ਜਾਰੀ ਰੱਖੋ", save: "ਸੇਵ ਕਰੋ", cancel: "ਰੱਦ ਕਰੋ", edit: "ਸੋਧੋ",
    close: "ਬੰਦ ਕਰੋ", viewOnMap: "ਨਕਸ਼ੇ 'ਤੇ ਵੇਖੋ", viewDetails: "ਵੇਰਵੇ ਵੇਖੋ", back: "ਵਾਪਸ", done: "ਪੂਰਾ ਹੋਇਆ",
    startDemo: "ਡੈਮੋ ਸ਼ੁਰੂ ਕਰੋ", nextStep: "ਅਗਲਾ ਕਦਮ", finishDemo: "ਡੈਮੋ ਖ਼ਤਮ ਕਰੋ", viewAll: "ਸਭ ਵੇਖੋ",
    markAllRead: "ਸਭ ਪੜ੍ਹਿਆ ਹੋਇਆ ਨਿਸ਼ਾਨ ਲਗਾਓ", viewWhy: "ਇਹ ਰੂਟ ਕਿਉਂ?", selectRoute: "ਰੂਟ ਚੁਣੋ",
    startNavigation: "ਨੈਵੀਗੇਸ਼ਨ ਸ਼ੁਰੂ ਕਰੋ", playVoiceAlert: "ਵੌਇਸ ਅਲਰਟ ਚਲਾਓ", trackVehicle: "ਵਾਹਨ ਟਰੈਕ ਕਰੋ",
    contactDriver: "ਡਰਾਈਵਰ ਨਾਲ ਸੰਪਰਕ ਕਰੋ", reroute: "ਰੀਰੂਟ ਕਰੋ", useForRouteRisk: "ਰੂਟ ਖ਼ਤਰੇ ਲਈ ਵਰਤੋਂ",
    newReport: "ਨਵੀਂ ਰਿਪੋਰਟ", submitReport: "ਰਿਪੋਰਟ ਜਮ੍ਹਾਂ ਕਰੋ", dispatchTeam: "ਟੀਮ ਭੇਜੋ",
    acknowledge: "ਸਵੀਕਾਰ ਕਰੋ", assignResponse: "ਜਵਾਬ ਸੌਂਪੋ", markDispatched: "ਭੇਜਿਆ ਗਿਆ ਨਿਸ਼ਾਨ ਲਗਾਓ",
    resolve: "ਹੱਲ ਕਰੋ", escalate: "ਐਸਕੇਲੇਟ ਕਰੋ", saveChanges: "ਬਦਲਾਅ ਸੇਵ ਕਰੋ", editProfile: "ਪ੍ਰੋਫਾਈਲ ਸੋਧੋ",
    getRoute: "ਰੂਟ ਲਵੋ", showFullMap: "ਪੂਰਾ ਨਕਸ਼ਾ ਵੇਖੋ",
    commandCenterTitle: "NE-RAAH ਕਮਾਂਡ ਸੈਂਟਰ", commandCenterSub: "ਖੇਤਰ-ਵਿਆਪੀ ਪਹੁੰਚਯੋਗਤਾ ਅਤੇ ਲੌਜਿਸਟਿਕਸ ਸੰਖੇਪ",
    welcomeBack: "ਜੀ ਆਇਆਂ ਨੂੰ", todayFocus: "ਅੱਜ ਤੁਹਾਨੂੰ ਇਹਨਾਂ ਵੱਲ ਧਿਆਨ ਦੇਣ ਦੀ ਲੋੜ ਹੈ",
    quickActions: "ਤੁਰੰਤ ਕਾਰਵਾਈਆਂ", recentAlerts: "ਹਾਲੀਆ ਚੇਤਾਵਨੀਆਂ", criticalShipmentsTitle: "ਨਾਜ਼ੁਕ ਸ਼ਿਪਮੈਂਟ",
    vehiclesInTransit: "ਰਸਤੇ ਵਿੱਚ ਵਾਹਨ", routeIntelTitle: "AI ਰੂਟ ਇੰਟੈਲੀਜੈਂਸ",
    routeIntelSub: "ਸ਼ਿਪਮੈਂਟ ਭੇਜਣ ਤੋਂ ਪਹਿਲਾਂ ਰੂਟ ਵਿਕਲਪਾਂ ਦੇ AI-ਸਹਾਇਕ ਖ਼ਤਰੇ ਦੇ ਅਨੁਮਾਨ ਦੀ ਤੁਲਨਾ ਕਰੋ।",
    aiRecommends: "NE-RAAH ਦੀ ਸਿਫ਼ਾਰਸ਼", whyTitle: "ਕਿਉਂ?", groundTruthTitle: "ਗਰਾਊਂਡ ਟਰੁੱਥ ਨੈੱਟਵਰਕ",
    groundTruthSub: "AI ਭਵਿੱਖਬਾਣੀ + ਮੌਸਮ/GIS ਡਾਟਾ + ਪ੍ਰਮਾਣਿਤ ਫੀਲਡ ਨਿਰੀਖਣ, ਇਕੱਠੇ।",
    weatherRiskTitle: "ਮੌਸਮ ਤੇ ਖ਼ਤਰਾ", weatherRiskSub: "ਰੂਟ ਇੰਟੈਲੀਜੈਂਸ ਇੰਜਣ ਨੂੰ ਫੀਡ ਕਰਨ ਵਾਲੇ ਲਾਈਵ ਮੌਸਮ ਅਤੇ ਭੂਮੀ ਖ਼ਤਰੇ ਦੇ ਕਾਰਕ।",
    sosCenterTitle: "SOS ਕੇਂਦਰ", sosCenterSub: "ਨੈੱਟਵਰਕ ਵਿੱਚ ਐਮਰਜੈਂਸੀ ਸਰਗਰਮੀਆਂ, ਲਾਈਵ ਜਵਾਬ ਸਥਿਤੀ ਨਾਲ।",
    notificationsTitle: "ਸੂਚਨਾਵਾਂ", fieldReportTitle: "ਨਵੀਂ ਫੀਲਡ ਰਿਪੋਰਟ",
    myProfileTitle: "ਪ੍ਰੋਫਾਈਲ", accountDetails: "ਖਾਤਾ ਵੇਰਵੇ", navigationStarted: "ਨੈਵੀਗੇਸ਼ਨ ਸ਼ੁਰੂ ਹੋਇਆ",
    vehiclesTitle: "ਵਾਹਨ ਨਿਗਰਾਨੀ", vehiclesSub: "ਨੈੱਟਵਰਕ ਵਿੱਚ ਟਰੈਕ ਕੀਤੇ ਵਾਹਨਾਂ ਦੀ ਲਾਈਵ ਸਥਿਤੀ।",
    shipmentsTitle: "ਲੌਜਿਸਟਿਕਸ ਤੇ ਸ਼ਿਪਮੈਂਟ", shipmentsSub: "ਖੇਤਰ ਵਿੱਚ ਜ਼ਰੂਰੀ ਸਪਲਾਈ ਟਰੈਕ ਕਰੋ।",
    alertsTitle: "ਅਲਰਟ ਸੈਂਟਰ", alertsSub: "ਹਰ ਚੇਤਾਵਨੀ ਨਕਸ਼ੇ, ਵਾਹਨ, ਸ਼ਿਪਮੈਂਟ ਜਾਂ ਘਟਨਾ ਨਾਲ ਜੁੜੀ ਹੈ।",
    weatherAheadTitle: "ਅੱਗੇ ਦਾ ਮੌਸਮ",
    onTime: "ਸਮੇਂ 'ਤੇ", delayed: "ਦੇਰੀ ਨਾਲ", atRiskStatus: "ਖ਼ਤਰੇ ਵਿੱਚ", stopped: "ਰੁਕਿਆ", delivered: "ਡਿਲੀਵਰ ਹੋਇਆ",
    criticalStatus: "ਨਾਜ਼ੁਕ", activeStatus: "ਸਰਗਰਮ", acknowledgedStatus: "ਸਵੀਕਾਰ ਕੀਤਾ",
    responseAssignedStatus: "ਜਵਾਬ ਸੌਂਪਿਆ", dispatchedStatus: "ਭੇਜਿਆ ਗਿਆ", resolvedStatus: "ਹੱਲ ਹੋਇਆ",
    monitoringStatus: "ਨਿਗਰਾਨੀ ਅਧੀਨ", pendingSyncStatus: "ਸਿੰਕ ਬਾਕੀ", syncedStatus: "ਸਿੰਕ ਹੋਇਆ",
    protectedStatus: "ਸੁਰੱਖਿਅਤ / ਟਰੈਕ 'ਤੇ", verifiedStatus: "ਪ੍ਰਮਾਣਿਤ", pendingStatus: "ਬਾਕੀ",
    highConfidenceStatus: "ਉੱਚ ਭਰੋਸਾ",
    safeLabel: "ਜਾਣ ਲਈ ਸੁਰੱਖਿਅਤ", moderateLabel: "ਸਾਵਧਾਨੀ", highRiskLabel: "ਉੱਚ ਖ਼ਤਰਾ", severeLabel: "ਬੰਦ",
    heavyRain: "ਭਾਰੀ ਮੀਂਹ", clearConditions: "ਅੱਗੇ ਮੌਸਮ ਸਾਫ਼ ਹੈ", riskColon: "ਖ਼ਤਰਾ",
    noActiveVehicles: "ਇਸ ਖੇਤਰ ਵਿੱਚ ਕੋਈ ਸਰਗਰਮ ਵਾਹਨ ਨਹੀਂ ਹੈ।", noIncidents: "ਇਸ ਖੇਤਰ ਵਿੱਚ ਕੋਈ ਘਟਨਾ ਦਰਜ ਨਹੀਂ ਹੋਈ।",
    allCaughtUp: "ਤੁਸੀਂ ਪੂਰੀ ਤਰ੍ਹਾਂ ਅੱਪਡੇਟ ਹੋ।", offlineBanner: "ਆਫ਼ਲਾਈਨ ਮੋਡ — ਨਵੀਨਤਮ ਸਿੰਕ ਕੀਤੀ ਜਾਣਕਾਰੀ ਵਿਖਾਈ ਜਾ ਰਹੀ ਹੈ।",
    noResultsFound: "ਕੋਈ ਨਤੀਜਾ ਨਹੀਂ ਮਿਲਿਆ", noRouteSelected: "ਕੋਈ ਰੂਟ ਚੁਣਿਆ ਨਹੀਂ ਗਿਆ",
    noRouteSelectedSub: "ਰੂਟ ਵਿਕਲਪ ਵੇਖਣ ਲਈ ਉੱਪਰ ਸਰੋਤ ਅਤੇ ਮੰਜ਼ਿਲ ਚੁਣੋ।",
    noFieldReports: "ਹਾਲੇ ਤੱਕ ਕੋਈ ਫੀਲਡ ਰਿਪੋਰਟ ਨਹੀਂ", noActiveEmergencies: "ਕੋਈ ਸਰਗਰਮ ਐਮਰਜੈਂਸੀ ਨਹੀਂ",
    noNotifications: "ਹਾਲੇ ਤੱਕ ਕੋਈ ਸੂਚਨਾ ਨਹੀਂ", noShipmentsView: "ਇਸ ਦ੍ਰਿਸ਼ ਵਿੱਚ ਕੋਈ ਸ਼ਿਪਮੈਂਟ ਨਹੀਂ",
    logoutConfirmTitle: "ਕੀ ਤੁਸੀਂ ਯਕੀਨੀ ਤੌਰ 'ਤੇ ਲਾਗਆਉਟ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?", logoutConfirmBody: "NE-RAAH ਤੱਕ ਪਹੁੰਚ ਲਈ ਤੁਹਾਨੂੰ ਦੁਬਾਰਾ ਲਾਗਇਨ ਕਰਨਾ ਪਵੇਗਾ।",
    fullName: "ਪੂਰਾ ਨਾਮ", role: "ਭੂਮਿਕਾ", organization: "ਸੰਸਥਾ", employeeId: "ਕਰਮਚਾਰੀ ID",
    phone: "ਫ਼ੋਨ", email: "ਈਮੇਲ", location: "ਸਥਾਨ / ਜ਼ਿਲ੍ਹਾ", preferredLanguage: "ਪਸੰਦੀਦਾ ਭਾਸ਼ਾ",
    emergencyContact: "ਐਮਰਜੈਂਸੀ ਸੰਪਰਕ", accountStatus: "ਖਾਤਾ ਸਥਿਤੀ", lastLogin: "ਆਖਰੀ ਲਾਗਇਨ",
    vehicleIdLabel: "ਵਾਹਨ ID", changeLanguage: "ਭਾਸ਼ਾ ਬਦਲੋ", notificationSettings: "ਸੂਚਨਾ ਸੈਟਿੰਗਾਂ",
    offlineData: "ਆਫ਼ਲਾਈਨ ਡਾਟਾ", security: "ਸੁਰੱਖਿਆ", profileUpdated: "ਪ੍ਰੋਫਾਈਲ ਸਫਲਤਾਪੂਰਵਕ ਅੱਪਡੇਟ ਹੋਈ।",
    source: "ਸਰੋਤ", destination: "ਮੰਜ਼ਿਲ", distance: "ਦੂਰੀ", eta: "ਅਨੁਮਾਨਿਤ ਸਮਾਂ",
    weatherLabel: "ਮੌਸਮ", roadLabel: "ਸੜਕ", trafficLabel: "ਟਰੈਫ਼ਿਕ", incidentsLabel: "ਘਟਨਾਵਾਂ", noneLabel: "ਕੋਈ ਨਹੀਂ",
    emergencyActivated: "ਐਮਰਜੈਂਸੀ ਸਰਗਰਮ", pressHold: "2 ਸਕਿੰਟ ਲਈ ਦਬਾਈ ਰੱਖੋ",
  
    onlineLabel: "ਆਨਲਾਈਨ", offlineLabel: "ਆਫ਼ਲਾਈਨ", sosActiveLabel: "SOS ਸਰਗਰਮ",
    accessibleCorridors: "ਪਹੁੰਚਯੋਗ ਕੋਰੀਡੋਰ", atRiskCorridors: "ਖ਼ਤਰੇ ਵਿੱਚ ਕੋਰੀਡੋਰ", blockedRoads: "ਬੰਦ ਸੜਕਾਂ",
    blockedCorridors: "ਬੰਦ ਕੋਰੀਡੋਰ", activeFieldReportsLabel: "ਸਰਗਰਮ ਫੀਲਡ ਰਿਪੋਰਟ", weatherImpactedAreas: "ਮੌਸਮ ਪ੍ਰਭਾਵਿਤ ਖੇਤਰ",
    activeVehiclesLabel: "ਸਰਗਰਮ ਵਾਹਨ", fieldReportsLabel: "ਫੀਲਡ ਰਿਪੋਰਟ", activeSOSLabel: "ਸਰਗਰਮ SOS", weatherAlertsLabel: "ਮੌਸਮ ਚੇਤਾਵਨੀ",
    nerLogisticsHealth: "NER ਲੌਜਿਸਟਿਕਸ ਸਿਹਤ", viewOverview: "ਸੰਖੇਪ ਵੇਖੋ", viewVehiclesAction: "ਵਾਹਨ ਵੇਖੋ", viewSOSAction: "SOS ਵੇਖੋ",
    immediateAttention: "ਤੁਰੰਤ ਧਿਆਨ ਦੀ ਲੋੜ ਹੈ", overallScoreDesc: "ਸਮੁੱਚੀ ਖੇਤਰੀ ਪਹੁੰਚਯੋਗਤਾ ਅਤੇ ਵਿਘਨ ਸਕੋਰ",
    allLabel: "ਸਭ", continueToward: "ਵੱਲ ਵਧਦੇ ਰਹੋ", endNavigation: "ਨੈਵੀਗੇਸ਼ਨ ਖ਼ਤਮ ਕਰੋ",
    voiceHeavyRain: "ਧਿਆਨ ਦਿਓ। ਲਗਭਗ ਚਾਰ ਕਿਲੋਮੀਟਰ ਅੱਗੇ ਭਾਰੀ ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ ਹੈ।", voiceRouteClear: "ਰੂਟ ਸਾਫ਼ ਹੈ। ਯੋਜਨਾ ਅਨੁਸਾਰ ਅੱਗੇ ਵਧੋ।",
    voiceLandslideWarning: "ਚੇਤਾਵਨੀ। 3.2 ਕਿਲੋਮੀਟਰ ਅੱਗੇ ਜ਼ਮੀਨ ਖਿਸਕਣ ਦੀ ਸੂਚਨਾ ਮਿਲੀ ਹੈ। ਇੱਕ ਸੁਰੱਖਿਅਤ ਰੂਟ ਉਪਲਬਧ ਹੈ।",
  },
  as: {
    dashboard: "ডেশ্ববৰ্ড", commandCenter: "কমাণ্ড চেণ্টাৰ", map: "লাইভ মেপ", routes: "ৰুট বুদ্ধিমত্তা",
    vehicles: "বাহন", shipments: "চালান", alerts: "সতৰ্কবাণী", sosCenter: "SOS কেন্দ্ৰ",
    copilot: "AI লজিষ্টিক্স কোপাইলট", reports: "গ্ৰাউণ্ড ট্ৰুথ নেটৱৰ্ক", weather: "বতৰ আৰু বিপদ",
    profile: "প্ৰ'ফাইল", settings: "ছেটিংছ", logout: "লগআউট", home: "হোম",
    search: "বাহন, চালান, ৰুট বিচাৰক…", sos: "SOS", more: "অধিক",
    login: "লগইন", continueAsDemo: "ডেম' হিচাপে অব্যাহত ৰাখক", save: "ছেভ কৰক", cancel: "বাতিল কৰক", edit: "সম্পাদনা কৰক",
    close: "বন্ধ কৰক", viewOnMap: "মেপত চাওক", viewDetails: "বিৱৰণ চাওক", back: "উভতি যাওক", done: "সম্পন্ন",
    startDemo: "ডেম' পৰিদৃশ্য আৰম্ভ কৰক", nextStep: "পৰৱৰ্তী পদক্ষেপ", finishDemo: "ডেম' সমাপ্ত কৰক", viewAll: "সকলো চাওক",
    markAllRead: "সকলো পঢ়া হিচাপে চিহ্নিত কৰক", viewWhy: "এই ৰুট কিয়?", selectRoute: "ৰুট বাছক",
    startNavigation: "নেভিগেচন আৰম্ভ কৰক", playVoiceAlert: "ভইচ এলাৰ্ট বজাওক", trackVehicle: "বাহন ট্ৰেক কৰক",
    contactDriver: "চালকৰ সৈতে যোগাযোগ কৰক", reroute: "ৰি-ৰুট কৰক", useForRouteRisk: "ৰুট বিপদৰ বাবে ব্যৱহাৰ কৰক",
    newReport: "নতুন ৰিপৰ্ট", submitReport: "ৰিপৰ্ট দাখিল কৰক", dispatchTeam: "দল পঠিয়াওক",
    acknowledge: "স্বীকাৰ কৰক", assignResponse: "প্ৰতিক্ৰিয়া নিযুক্ত কৰক", markDispatched: "পঠোৱা হিচাপে চিহ্নিত কৰক",
    resolve: "সমাধান কৰক", escalate: "এস্কেলেট কৰক", saveChanges: "সলনিসমূহ ছেভ কৰক", editProfile: "প্ৰ'ফাইল সম্পাদনা কৰক",
    getRoute: "ৰুট লওক", showFullMap: "সম্পূৰ্ণ মেপ দেখুৱাওক",
    commandCenterTitle: "NE-RAAH কমাণ্ড চেণ্টাৰ", commandCenterSub: "অঞ্চলজোৰা প্ৰৱেশাধিকাৰ আৰু লজিষ্টিক্স অৱলোকন",
    welcomeBack: "স্বাগতম", todayFocus: "আজি আপুনি এইবোৰলৈ মনোযোগ দিয়া উচিত",
    quickActions: "দ্ৰুত কাৰ্য", recentAlerts: "শেহতীয়া সতৰ্কবাণী", criticalShipmentsTitle: "জৰুৰী চালান",
    vehiclesInTransit: "পথত থকা বাহন", routeIntelTitle: "AI ৰুট বুদ্ধিমত্তা",
    routeIntelSub: "চালান পঠোৱাৰ আগতে ৰুট বিকল্পসমূহৰ AI-সহায়ক বিপদ আকলন তুলনা কৰক।",
    aiRecommends: "NE-RAAH ৰ পৰামৰ্শ", whyTitle: "কিয়?", groundTruthTitle: "গ্ৰাউণ্ড ট্ৰুথ নেটৱৰ্ক",
    groundTruthSub: "AI পূৰ্বানুমান + বতৰ/GIS তথ্য + সত্যাপিত ফীল্ড পৰ্যবেক্ষণ, একেলগে।",
    weatherRiskTitle: "বতৰ আৰু বিপদ", weatherRiskSub: "ৰুট বুদ্ধিমত্তা ইঞ্জিনক খুৱাই থকা লাইভ জলবায়ু আৰু ভূখণ্ড বিপদ কাৰক।",
    sosCenterTitle: "SOS কেন্দ্ৰ", sosCenterSub: "নেটৱৰ্কজুৰি জৰুৰীকালীন সক্ৰিয়কৰণ, লাইভ প্ৰতিক্ৰিয়া অৱস্থাৰ সৈতে।",
    notificationsTitle: "জাননী", fieldReportTitle: "নতুন ফীল্ড ৰিপৰ্ট",
    myProfileTitle: "প্ৰ'ফাইল", accountDetails: "একাউণ্টৰ বিৱৰণ", navigationStarted: "নেভিগেচন আৰম্ভ হ'ল",
    vehiclesTitle: "বাহন নিৰীক্ষণ", vehiclesSub: "নেটৱৰ্কত ট্ৰেক কৰা বাহনৰ লাইভ অৱস্থান।",
    shipmentsTitle: "লজিষ্টিক্স আৰু চালান", shipmentsSub: "অঞ্চলত প্ৰয়োজনীয় যোগানৰ ট্ৰেকিং।",
    alertsTitle: "সতৰ্কবাণী কেন্দ্ৰ", alertsSub: "প্ৰতিটো সতৰ্কবাণী মেপ, বাহন, চালান বা ঘটনাৰ সৈতে জড়িত।",
    weatherAheadTitle: "আগৰ বতৰ",
    onTime: "সময়মতে", delayed: "পলম হোৱা", atRiskStatus: "বিপদত", stopped: "ৰৈ থকা", delivered: "পৰিবহণ হ'ল",
    criticalStatus: "জৰুৰী", activeStatus: "সক্ৰিয়", acknowledgedStatus: "স্বীকৃত",
    responseAssignedStatus: "প্ৰতিক্ৰিয়া নিযুক্ত হ'ল", dispatchedStatus: "পঠোৱা হ'ল", resolvedStatus: "সমাধান হ'ল",
    monitoringStatus: "নিৰীক্ষণত", pendingSyncStatus: "ছিংক বাকী", syncedStatus: "ছিংক হ'ল",
    protectedStatus: "সুৰক্ষিত / ট্ৰেকত", verifiedStatus: "সত্যাপিত", pendingStatus: "বাকী",
    highConfidenceStatus: "উচ্চ বিশ্বাস",
    safeLabel: "যাবলৈ সুৰক্ষিত", moderateLabel: "সতৰ্কতা", highRiskLabel: "উচ্চ বিপদ", severeLabel: "বন্ধ",
    heavyRain: "প্ৰবল বৰষুণ", clearConditions: "আগত বতৰ পৰিষ্কাৰ", riskColon: "বিপদ",
    noActiveVehicles: "এই অঞ্চলত কোনো সক্ৰিয় বাহন নাই।", noIncidents: "এই অঞ্চলত কোনো ঘটনা প্ৰতিবেদন কৰা হোৱা নাই।",
    allCaughtUp: "আপুনি সম্পূৰ্ণৰূপে আপডেট।", offlineBanner: "অফলাইন মোড — শেহতীয়াকৈ ছিংক কৰা তথ্য দেখুওৱা হৈছে।",
    noResultsFound: "কোনো ফলাফল পোৱা নগ'ল", noRouteSelected: "কোনো ৰুট বাছনি কৰা হোৱা নাই",
    noRouteSelectedSub: "ৰুট বিকল্প চাবলৈ ওপৰত উৎস আৰু গন্তব্য বাছক।",
    noFieldReports: "এতিয়ালৈকে কোনো ফীল্ড ৰিপৰ্ট নাই", noActiveEmergencies: "কোনো সক্ৰিয় জৰুৰীকালীন অৱস্থা নাই",
    noNotifications: "এতিয়ালৈকে কোনো জাননী নাই", noShipmentsView: "এই দৃশ্যত কোনো চালান নাই",
    logoutConfirmTitle: "আপুনি নিশ্চিতভাৱে লগআউট কৰিব বিচাৰেনে?", logoutConfirmBody: "NE-RAAH ব্যৱহাৰ কৰিবলৈ আপুনি পুনৰ লগইন কৰিব লাগিব।",
    fullName: "সম্পূৰ্ণ নাম", role: "ভূমিকা", organization: "প্ৰতিষ্ঠান", employeeId: "কৰ্মচাৰী ID",
    phone: "ফোন", email: "ইমেইল", location: "স্থান / জিলা", preferredLanguage: "পছন্দৰ ভাষা",
    emergencyContact: "জৰুৰীকালীন যোগাযোগ", accountStatus: "একাউণ্ট অৱস্থা", lastLogin: "শেষ লগইন",
    vehicleIdLabel: "বাহন ID", changeLanguage: "ভাষা সলনি কৰক", notificationSettings: "জাননী ছেটিংছ",
    offlineData: "অফলাইন তথ্য", security: "সুৰক্ষা", profileUpdated: "প্ৰ'ফাইল সফলতাৰে আপডেট হ'ল।",
    source: "উৎস", destination: "গন্তব্য", distance: "দূৰত্ব", eta: "আনুমানিক সময়",
    weatherLabel: "বতৰ", roadLabel: "পথ", trafficLabel: "ট্ৰেফিক", incidentsLabel: "ঘটনা", noneLabel: "একো নাই",
    emergencyActivated: "জৰুৰীকালীন সক্ৰিয়", pressHold: "২ ছেকেণ্ড হেঁচি ৰাখক",
  
    onlineLabel: "অনলাইন", offlineLabel: "অফলাইন", sosActiveLabel: "SOS সক্ৰিয়",
    accessibleCorridors: "প্ৰৱেশযোগ্য কৰিডৰ", atRiskCorridors: "বিপদাপন্ন কৰিডৰ", blockedRoads: "অৱৰুদ্ধ পথ",
    blockedCorridors: "অৱৰুদ্ধ কৰিডৰ", activeFieldReportsLabel: "সক্ৰিয় ফীল্ড ৰিপৰ্ট", weatherImpactedAreas: "বতৰ প্ৰভাৱিত অঞ্চল",
    activeVehiclesLabel: "সক্ৰিয় বাহন", fieldReportsLabel: "ফীল্ড ৰিপৰ্ট", activeSOSLabel: "সক্ৰিয় SOS", weatherAlertsLabel: "বতৰ সতৰ্কবাণী",
    nerLogisticsHealth: "NER লজিষ্টিক্স স্বাস্থ্য", viewOverview: "অৱলোকন চাওক", viewVehiclesAction: "বাহন চাওক", viewSOSAction: "SOS চাওক",
    immediateAttention: "তৎক্ষণাৎ মনোযোগৰ প্ৰয়োজন", overallScoreDesc: "সামগ্ৰিক আঞ্চলিক প্ৰৱেশাধিকাৰ আৰু ব্যাঘাত স্ক'ৰ",
    allLabel: "সকলো", continueToward: "ফালে আগবাঢ়ি থাকক", endNavigation: "নেভিগেচন সমাপ্ত কৰক",
    voiceHeavyRain: "সাৱধান। প্ৰায় চাৰি কিলোমিটাৰ আগত প্ৰবল বৰষুণৰ সম্ভাৱনা।", voiceRouteClear: "ৰুট পৰিষ্কাৰ। পৰিকল্পনা অনুসৰি আগবাঢ়ক।",
    voiceLandslideWarning: "সতৰ্কবাণী। 3.2 কিলোমিটাৰ আগত মাটি স্খলনৰ খবৰ পোৱা গৈছে। এটা সুৰক্ষিত ৰুট উপলব্ধ।",
  },
};
const LangContext = createContext({ lang: "en", t: (k) => (T.en[k] || k) });
function useT() { return useContext(LangContext); }

/* ============================================================
   SMALL UI ATOMS
============================================================ */
const cardCls = "bg-white border border-stone-200 rounded-xl shadow-sm";

function Logo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <path d="M20 3C12 3 7 9 7 16c0 10 13 21 13 21s13-11 13-21c0-7-5-13-13-13z" fill="#0f766e" />
      <path d="M13 22 L20 12 L27 22" stroke="white" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <circle cx="20" cy="16" r="2.6" fill="white" />
    </svg>
  );
}

function Badge({ children, tone = "slate" }) {
  const tones = {
    slate: "bg-slate-100 text-slate-700 border-slate-200",
    emerald: "bg-emerald-50 text-emerald-700 border-emerald-200",
    amber: "bg-amber-50 text-amber-700 border-amber-200",
    red: "bg-red-50 text-red-700 border-red-200",
    darkred: "bg-red-900 text-red-50 border-red-950",
    teal: "bg-teal-50 text-teal-700 border-teal-200",
  };
  return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium border ${tones[tone]}`}>{children}</span>;
}

function TierBadge({ tier }) {
  const { t } = useT();
  const tk = RISK_TIERS[tier] || RISK_TIERS.moderate;
  const shortKey = tier === "safe" ? "safeLabel" : tier === "moderate" ? "moderateLabel" : tier === "high" ? "highRiskLabel" : "severeLabel";
  return <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border ${tk.bg} ${tk.text} ${tk.border}`}><span className={`w-1.5 h-1.5 rounded-full ${tk.dot}`} />{t(shortKey)}</span>;
}

const STATUS_KEY = {
  "ON TIME": "onTime", DELAYED: "delayed", "AT RISK": "atRiskStatus", STOPPED: "stopped", DELIVERED: "delivered",
  CRITICAL: "criticalStatus", ACTIVE: "activeStatus", ACKNOWLEDGED: "acknowledgedStatus", "RESPONSE ASSIGNED": "responseAssignedStatus",
  DISPATCHED: "dispatchedStatus", RESOLVED: "resolvedStatus", MONITORING: "monitoringStatus", "PROTECTED / ON TRACK": "protectedStatus",
  VERIFIED: "verifiedStatus", PENDING: "pendingStatus", "HIGH CONFIDENCE": "highConfidenceStatus",
  "PENDING SYNC": "pendingSyncStatus", SYNCED: "syncedStatus",
};
function StatusBadge({ status }) {
  const { t } = useT();
  const map = {
    "ON TIME": "emerald", DELAYED: "amber", "AT RISK": "red", STOPPED: "slate", DELIVERED: "teal",
    CRITICAL: "darkred", ACTIVE: "red", ACKNOWLEDGED: "amber", "RESPONSE ASSIGNED": "amber",
    DISPATCHED: "teal", RESOLVED: "emerald", MONITORING: "amber", "PROTECTED / ON TRACK": "emerald",
  };
  const key = STATUS_KEY[status];
  return <Badge tone={map[status] || "slate"}>{key ? t(key) : status}</Badge>;
}

function PrimaryBtn({ children, onClick, className = "", disabled, icon: Icon }) {
  return (
    <button onClick={onClick} disabled={disabled}
      className={`inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-teal-700 text-white text-sm font-semibold hover:bg-teal-800 active:bg-teal-900 transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${className}`}>
      {Icon && <Icon size={16} />} {children}
    </button>
  );
}
function SecondaryBtn({ children, onClick, className = "", icon: Icon }) {
  return (
    <button onClick={onClick}
      className={`inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-white border border-stone-300 text-slate-700 text-sm font-semibold hover:bg-stone-50 transition-colors ${className}`}>
      {Icon && <Icon size={16} />} {children}
    </button>
  );
}
function GhostBtn({ children, onClick, className = "", icon: Icon }) {
  return (
    <button onClick={onClick} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-slate-600 hover:bg-stone-100 transition-colors ${className}`}>
      {Icon && <Icon size={15} />} {children}
    </button>
  );
}

function Modal({ open, onClose, children, wide }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900 opacity-50" onClick={onClose} />
      <div className={`relative bg-white rounded-2xl shadow-lg border border-stone-200 w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-full overflow-y-auto nr-scroll`}>
        {children}
      </div>
    </div>
  );
}

function ConfirmModal({ open, title, body, confirmLabel = "Confirm", onConfirm, onCancel, danger }) {
  const { t } = useT();
  return (
    <Modal open={open} onClose={onCancel}>
      <div className="p-6">
        <h3 className="text-lg font-semibold text-slate-900 nr-font">{title}</h3>
        <p className="text-sm text-slate-500 mt-2">{body}</p>
        <div className="flex gap-2 justify-end mt-6">
          <SecondaryBtn onClick={onCancel}>{t("cancel")}</SecondaryBtn>
          <button onClick={onConfirm} className={`px-4 py-2 rounded-lg text-sm font-semibold text-white ${danger ? "bg-red-600 hover:bg-red-700" : "bg-teal-700 hover:bg-teal-800"}`}>{confirmLabel}</button>
        </div>
      </div>
    </Modal>
  );
}

function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div className="fixed bottom-24 md:bottom-8 left-1/2 z-50" style={{ transform: "translateX(-50%)" }}>
      <div className="bg-slate-900 text-white text-sm px-4 py-2.5 rounded-lg shadow-lg flex items-center gap-2 nr-font">
        <CheckCircle2 size={16} className="text-emerald-400" /> {toast}
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon = Info, title, sub }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6 text-slate-500">
      <div className="w-12 h-12 rounded-full bg-stone-100 flex items-center justify-center mb-3"><Icon size={22} className="text-slate-400" /></div>
      <p className="font-medium text-slate-600">{title}</p>
      {sub && <p className="text-sm mt-1 max-w-xs">{sub}</p>}
    </div>
  );
}

function SectionHeader({ title, sub, right }) {
  return (
    <div className="flex items-start justify-between gap-3 mb-4 flex-wrap">
      <div>
        <h2 className="text-lg md:text-xl font-semibold text-slate-900 nr-font">{title}</h2>
        {sub && <p className="text-sm text-slate-500 mt-0.5">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

function UpdatedTag({ text = "Updated 2 min ago" }) {
  return <span className="inline-flex items-center gap-1 text-xs text-slate-400"><Clock size={11} /> {text}</span>;
}

/* Generic slide-over / bottom-sheet detail drawer, reused for routes, vehicles, shipments, incidents, SOS */
function DetailDrawer({ open, onClose, kicker, title, subtitle, tier, fields = [], actions = [], note }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 md:flex md:items-stretch md:justify-end">
      <div className="absolute inset-0 bg-slate-900 opacity-40" onClick={onClose} />
      <div className="relative bg-white w-full md:w-96 h-full ml-auto shadow-xl overflow-y-auto nr-scroll fixed bottom-0 md:static rounded-t-2xl md:rounded-none max-h-full">
        <div className="sticky top-0 bg-white border-b border-stone-200 px-5 py-4 flex items-start justify-between">
          <div>
            {kicker && <p className="text-xs font-semibold tracking-wide text-teal-700 uppercase nr-mono">{kicker}</p>}
            <h3 className="text-lg font-semibold text-slate-900 mt-0.5 nr-font">{title}</h3>
            {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-stone-100 text-slate-400"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          {tier && (
            <div className={`rounded-lg p-3 border ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].border}`}>
              <TierBadge tier={tier} />
            </div>
          )}
          <div className="grid grid-cols-2 gap-x-4 gap-y-3">
            {fields.map((f, i) => (
              <div key={i} className={f.full ? "col-span-2" : ""}>
                <p className="text-xs text-slate-400">{f.label}</p>
                <p className="text-sm font-medium text-slate-800 nr-mono mt-0.5">{f.value}</p>
              </div>
            ))}
          </div>
          {note && (
            <div className="bg-stone-50 border border-stone-200 rounded-lg p-3 text-xs text-slate-500 flex gap-2">
              <Sparkles size={14} className="text-teal-600 shrink-0 mt-0.5" /> {note}
            </div>
          )}
          {actions.length > 0 && (
            <div className="flex flex-col gap-2 pt-2">
              {actions.map((a, i) => (
                a.primary
                  ? <PrimaryBtn key={i} onClick={a.onClick}>{a.label}</PrimaryBtn>
                  : <SecondaryBtn key={i} onClick={a.onClick}>{a.label}</SecondaryBtn>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   SOS FLOATING BUTTON (press & hold)
============================================================ */
function SOSButton({ onActivate, compact }) {
  const [holding, setHolding] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef(null);
  const startRef = useRef(0);

  const start = () => {
    setHolding(true);
    startRef.current = Date.now();
    timerRef.current = setInterval(() => {
      const pct = Math.min(100, ((Date.now() - startRef.current) / 2000) * 100);
      setProgress(pct);
      if (pct >= 100) {
        clearInterval(timerRef.current);
        setHolding(false);
        setProgress(0);
        onActivate();
      }
    }, 30);
  };
  const cancel = () => {
    clearInterval(timerRef.current);
    setHolding(false);
    setProgress(0);
  };

  return (
    <button
      onMouseDown={start} onMouseUp={cancel} onMouseLeave={cancel}
      onTouchStart={start} onTouchEnd={cancel}
      className={`relative overflow-hidden select-none flex items-center justify-center gap-2 rounded-full bg-red-600 text-white font-bold shadow-lg border-2 border-red-700 active:scale-95 transition-transform ${compact ? "w-16 h-16 flex-col text-xs" : "px-5 py-3 text-sm"}`}
      title="Press and hold for 2 seconds"
    >
      <div className="absolute inset-0 bg-red-800" style={{ width: `${progress}%`, transition: "width 30ms linear" }} />
      <span className="relative flex items-center gap-1.5"><Siren size={compact ? 20 : 18} /> {compact ? "SOS" : "SOS · Hold 2s"}</span>
    </button>
  );
}

function SOSFloating({ onActivate, hasActiveSOS }) {
  return (
    <div className="hidden md:flex fixed bottom-6 right-6 z-30 flex-col items-end gap-2">
      {hasActiveSOS && (
        <div className="bg-red-600 text-white text-xs font-semibold px-2.5 py-1 rounded-md nr-blink">Active SOS in progress</div>
      )}
      <SOSButton onActivate={onActivate} compact />
    </div>
  );
}

/* SOS Activation modal: category -> confirmation */
function SOSActivateModal({ open, onClose, onSubmit, user, currentRisk, weather, online }) {
  const [step, setStep] = useState("category");
  const [category, setCategory] = useState(null);
  useEffect(() => { if (open) { setStep("category"); setCategory(null); } }, [open]);
  if (!open) return null;
  return (
    <Modal open={open} onClose={onClose}>
      {step === "category" && (
        <div className="p-6">
          <div className="flex items-center gap-2 text-red-600 mb-1"><Siren size={20} /><h3 className="text-lg font-bold nr-font">Emergency Activated</h3></div>
          <p className="text-sm text-slate-500 mb-4">Select the type of emergency so the nearest response team can prepare.</p>
          <div className="grid grid-cols-2 gap-2">
            {SOS_TYPES.map((c) => (
              <button key={c} onClick={() => setCategory(c)}
                className={`text-left px-3 py-2.5 rounded-lg border text-sm font-medium transition-colors ${category === c ? "bg-red-50 border-red-400 text-red-700" : "border-stone-200 hover:bg-stone-50 text-slate-700"}`}>
                {c}
              </button>
            ))}
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <SecondaryBtn onClick={onClose}>Cancel</SecondaryBtn>
            <button disabled={!category} onClick={() => setStep("confirm")}
              className="px-4 py-2 rounded-lg text-sm font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-40">
              Send Emergency Alert
            </button>
          </div>
        </div>
      )}
      {step === "confirm" && (
        <div className="p-6">
          <div className="flex items-center gap-2 text-red-600 mb-3"><Siren size={22} className="nr-blink" /><h3 className="text-lg font-bold nr-font">🚨 EMERGENCY ACTIVATED</h3></div>
          <p className="text-sm text-slate-600 mb-4">Your location and vehicle details have been shared with the NE-RAAH Command Center. Stay where it is safe.</p>
          <div className={`${cardCls} p-3 grid grid-cols-2 gap-3 text-sm`}>
            <div><p className="text-xs text-slate-400">Emergency Type</p><p className="font-medium">{category}</p></div>
            <div><p className="text-xs text-slate-400">GPS</p><p className="font-medium nr-mono">26.14° N, 91.73° E</p></div>
            <div><p className="text-xs text-slate-400">User</p><p className="font-medium">{user?.name}</p></div>
            <div><p className="text-xs text-slate-400">Vehicle</p><p className="font-medium nr-mono">{user?.vehicleId || "—"}</p></div>
            <div><p className="text-xs text-slate-400">Current Risk</p><p className="font-medium">{currentRisk}/100</p></div>
            <div><p className="text-xs text-slate-400">Weather</p><p className="font-medium">{weather}</p></div>
            <div><p className="text-xs text-slate-400">Network</p><p className="font-medium">{online ? "Online" : "Offline (queued)"}</p></div>
            <div><p className="text-xs text-slate-400">Time</p><p className="font-medium">Just now</p></div>
          </div>
          <PrimaryBtn className="w-full mt-5 bg-red-600 hover:bg-red-700" onClick={() => { onSubmit(category); }}>Done — Command Center Notified</PrimaryBtn>
        </div>
      )}
    </Modal>
  );
}

/* ============================================================
   TOP BAR
============================================================ */
function TopBar({ t, online, onToggleOnline, notifCount, onOpenNotifs, onOpenProfile, user, onSearch, onOpenMenu, lang, onLangChange, hasActiveSOS }) {
  const [langOpen, setLangOpen] = useState(false);
  return (
    <div className="sticky top-0 z-20 bg-white border-b border-stone-200 px-4 md:px-6 h-16 flex items-center gap-3">
      <button className="md:hidden p-2 -ml-2 text-slate-600" onClick={onOpenMenu}><Menu size={22} /></button>
      <div className="hidden md:flex items-center gap-2 min-w-max">
        <Logo size={26} />
        <span className="font-bold text-slate-900 nr-font tracking-tight">NE-RAAH</span>
      </div>
      {hasActiveSOS && (
        <span className="flex items-center gap-1 text-xs font-semibold text-red-600 bg-red-50 border border-red-200 px-2 py-1 rounded-full nr-blink">
          <Siren size={12} /> {t("sosActiveLabel")}
        </span>
      )}
      <div className="flex-1 max-w-md hidden sm:flex items-center gap-2 bg-stone-100 rounded-lg px-3 py-2 ml-2">
        <Search size={16} className="text-slate-400" />
        <input
          onKeyDown={(e) => { if (e.key === "Enter" && e.currentTarget.value.trim()) { onSearch(e.currentTarget.value.trim()); e.currentTarget.value = ""; } }}
          placeholder={t("search")} className="bg-transparent text-sm outline-none flex-1 text-slate-700 placeholder:text-slate-400" />
      </div>
      <div className="flex-1" />
      <button onClick={onToggleOnline} className={`hidden sm:flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-full border ${online ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-red-50 text-red-700 border-red-200"}`}>
        {online ? <Wifi size={14} /> : <WifiOff size={14} />} {online ? t("onlineLabel") : t("offlineLabel")}
      </button>
      <div className="relative">
        <button onClick={() => setLangOpen((v) => !v)} className="hidden sm:flex items-center gap-1 text-xs font-medium text-slate-600 px-2.5 py-1.5 rounded-full border border-stone-200 hover:bg-stone-50">
          <Globe size={14} /> {lang.toUpperCase()} <ChevronDown size={12} />
        </button>
        {langOpen && (
          <div className="absolute right-0 mt-2 bg-white border border-stone-200 rounded-lg shadow-lg w-36 py-1 z-30">
            {LANGS.map((l) => (
              <button key={l.code} onClick={() => { onLangChange(l.code); setLangOpen(false); }} className="w-full text-left px-3 py-1.5 text-sm hover:bg-stone-50 flex items-center justify-between">
                {l.label} {lang === l.code && <Check size={14} className="text-teal-700" />}
              </button>
            ))}
          </div>
        )}
      </div>
      <button onClick={onOpenNotifs} className="relative p-2 rounded-lg hover:bg-stone-100 text-slate-600">
        <Bell size={19} />
        {notifCount > 0 && <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />}
      </button>
      <button onClick={onOpenProfile} className="flex items-center gap-2 pl-1">
        <div className="w-8 h-8 rounded-full bg-teal-700 text-white flex items-center justify-center text-xs font-bold overflow-hidden">
          {user?.photo ? <img src={user.photo} alt="" className="w-full h-full object-cover" /> : user?.name?.split(" ").map((n) => n[0]).slice(0, 2).join("")}
        </div>
        <span className="hidden lg:block text-sm font-medium text-slate-700">{user?.name?.split(" ")[0]}</span>
      </button>
    </div>
  );
}

/* ============================================================
   SIDEBAR (desktop) + MOBILE NAV
============================================================ */
const NAV_CONFIG = {
  authority: [
    { id: "dashboard", labelKey: "dashboard", icon: LayoutGrid },
    { id: "map", labelKey: "map", icon: MapPinned },
    { id: "routes", labelKey: "routes", icon: RouteIcon },
    { id: "vehicles", labelKey: "vehicles", icon: Truck },
    { id: "shipments", labelKey: "shipments", icon: Package },
    { id: "alerts", labelKey: "alerts", icon: AlertTriangle },
    { id: "sos", labelKey: "sosCenter", icon: Siren },
    { id: "copilot", labelKey: "copilot", icon: MessageSquare },
    { id: "reports", labelKey: "reports", icon: FileText },
    { id: "weather", labelKey: "weather", icon: CloudRain },
  ],
  officer: [
    { id: "dashboard", labelKey: "dashboard", icon: LayoutGrid },
    { id: "map", labelKey: "map", icon: MapPinned },
    { id: "reports", labelKey: "reports", icon: FileText },
    { id: "alerts", labelKey: "alerts", icon: AlertTriangle },
    { id: "sos", labelKey: "sosCenter", icon: Siren },
    { id: "weather", labelKey: "weather", icon: CloudRain },
  ],
  driver: [
    { id: "dashboard", labelKey: "home", icon: Home },
    { id: "map", labelKey: "map", icon: MapPinned },
    { id: "routes", labelKey: "routes", icon: RouteIcon },
    { id: "alerts", labelKey: "alerts", icon: AlertTriangle },
  ],
};
const MOBILE_NAV_ITEMS = [["dashboard", "home", Home], ["map", "map", MapPinned], ["alerts", "alerts", AlertTriangle], ["sos", "sos", Siren], ["profile", "profile", User]];
const MORE_ITEMS = {
  authority: ["routes", "vehicles", "shipments", "copilot", "sos", "reports", "weather", "settings"],
  officer: ["sos", "reports", "weather", "settings"],
  driver: ["routes", "weather", "settings"],
};
const PAGE_META = {
  routes: { labelKey: "routes", icon: RouteIcon }, vehicles: { labelKey: "vehicles", icon: Truck }, shipments: { labelKey: "shipments", icon: Package },
  copilot: { labelKey: "copilot", icon: MessageSquare }, sos: { labelKey: "sosCenter", icon: Siren }, reports: { labelKey: "reports", icon: FileText },
  weather: { labelKey: "weather", icon: CloudRain }, settings: { labelKey: "settings", icon: SettingsIcon },
};

function Sidebar({ role, current, onNavigate, onLogout }) {
  const { t } = useT();
  const items = NAV_CONFIG[role];
  return (
    <div className="hidden md:flex flex-col w-60 shrink-0 bg-slate-900 text-slate-300 h-screen sticky top-0">
      <div className="flex items-center gap-2 px-5 h-16 border-b border-slate-800">
        <Logo size={26} />
        <div>
          <p className="text-white font-bold text-sm nr-font tracking-tight leading-none">NE-RAAH</p>
          <p className="text-xs text-slate-500 mt-0.5">Connected NER</p>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto nr-scroll py-3 px-3 space-y-0.5">
        {items.map((it) => (
          <button key={it.id} onClick={() => onNavigate(it.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${current === it.id ? "bg-teal-700 text-white" : "text-slate-300 hover:bg-slate-800"}`}>
            <it.icon size={17} /> {t(it.labelKey)}
          </button>
        ))}
      </div>
      <div className="p-3 border-t border-slate-800 space-y-0.5">
        <button onClick={() => onNavigate("profile")} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${current === "profile" ? "bg-teal-700 text-white" : "text-slate-300 hover:bg-slate-800"}`}><User size={17} /> {t("profile")}</button>
        <button onClick={() => onNavigate("settings")} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${current === "settings" ? "bg-teal-700 text-white" : "text-slate-300 hover:bg-slate-800"}`}><SettingsIcon size={17} /> {t("settings")}</button>
        <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:bg-slate-800"><LogOut size={17} /> {t("logout")}</button>
      </div>
    </div>
  );
}

function MobileNav({ role, current, onNavigate, onMore, onActivateSOS }) {
  const { t } = useT();
  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-stone-200 flex items-stretch h-16 px-1">
      {MOBILE_NAV_ITEMS.map(([id, labelKey, Icon]) => {
        if (id === "sos") {
          return (
            <div key={id} className="flex-1 flex flex-col items-center justify-center">
              <button
                onMouseDown={(e) => e.currentTarget._t = setTimeout(onActivateSOS, 2000)}
                onMouseUp={(e) => clearTimeout(e.currentTarget._t)}
                onMouseLeave={(e) => clearTimeout(e.currentTarget._t)}
                onTouchStart={(e) => e.currentTarget._t = setTimeout(onActivateSOS, 2000)}
                onTouchEnd={(e) => clearTimeout(e.currentTarget._t)}
                className="w-11 h-11 rounded-full bg-red-600 text-white flex items-center justify-center shadow-md active:scale-95 transition-transform">
                <Siren size={19} />
              </button>
              <span className="text-xs font-medium text-red-600 mt-0.5">{t(labelKey)}</span>
            </div>
          );
        }
        return (
          <button key={id} onClick={() => onNavigate(id)} className={`flex-1 flex flex-col items-center justify-center gap-0.5 text-xs font-medium ${current === id ? "text-teal-700" : "text-slate-400"}`}>
            <Icon size={19} /> {t(labelKey)}
          </button>
        );
      })}
      <button onClick={onMore} className="flex-1 flex flex-col items-center justify-center gap-0.5 text-xs font-medium text-slate-400">
        <MoreHorizontal size={19} /> {t("more")}
      </button>
    </div>
  );
}

function MoreSheet({ open, onClose, role, onNavigate, onLogout }) {
  const { t } = useT();
  if (!open) return null;
  const items = MORE_ITEMS[role];
  return (
    <div className="fixed inset-0 z-40 md:hidden">
      <div className="absolute inset-0 bg-slate-900 opacity-40" onClick={onClose} />
      <div className="absolute bottom-0 inset-x-0 bg-white rounded-t-2xl p-4 pb-8">
        <div className="w-10 h-1 bg-stone-300 rounded-full mx-auto mb-4" />
        <div className="grid grid-cols-3 gap-3">
          {items.map((id) => {
            const meta = PAGE_META[id];
            return (
              <button key={id} onClick={() => { onNavigate(id); onClose(); }} className="flex flex-col items-center gap-2 py-3 rounded-xl border border-stone-200 hover:bg-stone-50">
                <meta.icon size={20} className="text-teal-700" />
                <span className="text-xs font-medium text-slate-600 text-center">{t(meta.labelKey)}</span>
              </button>
            );
          })}
          <button onClick={() => { onLogout(); onClose(); }} className="flex flex-col items-center gap-2 py-3 rounded-xl border border-stone-200 hover:bg-stone-50">
            <LogOut size={20} className="text-red-600" />
            <span className="text-xs font-medium text-slate-600">{t("logout")}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   LIVE MAP
============================================================ */
function buildGraph(edges) {
  const adj = {}; const byPair = {};
  edges.forEach((e) => {
    (adj[e.from] = adj[e.from] || []).push({ to: e.to, risk: e.risk, id: e.id });
    (adj[e.to] = adj[e.to] || []).push({ to: e.from, risk: e.risk, id: e.id });
    byPair[`${e.from}|${e.to}`] = e; byPair[`${e.to}|${e.from}`] = e;
  });
  return { adj, byPair };
}
function findPath(adj, from, to, excludeId) {
  if (from === to) return [from];
  const visited = new Set([from]);
  const queue = [[from]];
  while (queue.length) {
    const path = queue.shift();
    const node = path[path.length - 1];
    for (const edge of adj[node] || []) {
      if (excludeId && edge.id === excludeId) continue;
      if (edge.to === to) return [...path, to];
      if (!visited.has(edge.to)) { visited.add(edge.to); queue.push([...path, edge.to]); }
    }
  }
  return null;
}
function pathMetrics(path, byPair) {
  let risk = 0, px = 0; const edgeIds = [];
  for (let i = 0; i < path.length - 1; i++) {
    const a = CITIES[path[i]], b = CITIES[path[i + 1]];
    const edge = byPair[`${path[i]}|${path[i + 1]}`];
    risk = Math.max(risk, edge ? edge.risk : 30);
    if (edge) edgeIds.push(edge.id);
    px += Math.hypot(b.x - a.x, b.y - a.y);
  }
  const km = Math.max(15, Math.round((px * 2.6) / 5) * 5);
  const hrs = km / 42;
  const h = Math.floor(hrs), m = Math.round((hrs - h) * 60);
  return { risk, km, eta: `${h}h ${m}m`, edgeIds };
}
function fitViewBox(cityKeys, padding = 65) {
  const pts = cityKeys.map((k) => CITIES[k]).filter(Boolean);
  if (pts.length === 0) return "100 100 500 420";
  const minX = Math.min(...pts.map((p) => p.x)) - padding;
  const maxX = Math.max(...pts.map((p) => p.x)) + padding;
  const minY = Math.min(...pts.map((p) => p.y)) - padding;
  const maxY = Math.max(...pts.map((p) => p.y)) + padding;
  const w = Math.max(maxX - minX, 240), h = Math.max(maxY - minY, 200);
  return `${minX} ${minY} ${w} ${h}`;
}
function cityKeyByName(name) { const e = Object.entries(CITIES).find(([, c]) => c.name === name); return e ? e[0] : null; }
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function curvedEdgePath(a, b, seed) {
  const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
  const dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len, ny = dx / len;
  const h = hashStr(seed);
  const bow = 9 + (h % 13);
  const sign = h % 2 === 0 ? 1 : -1;
  return `M ${a.x} ${a.y} Q ${mx + nx * bow * sign} ${my + ny * bow * sign} ${b.x} ${b.y}`;
}
function smoothPath(points, tension = 0.25) {
  if (points.length < 2) return "";
  if (points.length === 2) return curvedEdgePath(points[0], points[1], `${points[0].x},${points[0].y}-${points[1].x},${points[1].y}`);
  let d = `M ${points[0].x} ${points[0].y} `;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] || points[i], p1 = points[i], p2 = points[i + 1], p3 = points[i + 2] || p2;
    const cp1x = p1.x + (p2.x - p0.x) * tension, cp1y = p1.y + (p2.y - p0.y) * tension;
    const cp2x = p2.x - (p3.x - p1.x) * tension, cp2y = p2.y - (p3.y - p1.y) * tension;
    d += `C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y} `;
  }
  return d;
}

function whyBullets(info) {
  const bullets = [];
  bullets.push(info.road === "Good" ? "Road mostly clear" : info.road === "Fair" ? "Road passable with minor issues" : "Road condition needs caution");
  bullets.push(info.weather !== "Heavy Rain" ? "Low rainfall risk" : "Rainfall expected — reduced visibility");
  bullets.push((info.incidents === 0 || info.incidents === "None") ? "No major blockage" : "Some incidents reported nearby");
  return bullets;
}
const MARKER_ICON = { Landslide: "⛰️", Flood: "🌊", "Road Damage": "🚧", "Bridge Damage": "🚧", Traffic: "🚦", Accident: "🚨", "Road Blockage": "🚧", Other: "📸" };
function MarkerPopupCard({ popup, onClose, onAction }) {
  if (!popup) return null;
  const { kind, data } = popup;
  return (
    <div className="absolute left-3 top-16 z-10 w-64 bg-white rounded-xl border border-stone-200 shadow-lg p-3.5">
      <button onClick={onClose} className="absolute top-2 right-2 text-slate-300 hover:text-slate-500"><X size={14} /></button>
      {kind === "place" && (
        <>
          <p className="font-semibold text-slate-900 flex items-center gap-1.5">📍 {data.name}</p>
          <p className="text-xs text-slate-400 mt-0.5">NER logistics location</p>
          <div className="flex gap-1.5 mt-3">
            <SecondaryBtn className="flex-1 text-xs" onClick={() => onAction("setSource")}>Set as Source</SecondaryBtn>
            <SecondaryBtn className="flex-1 text-xs" onClick={() => onAction("setDest")}>Set as Destination</SecondaryBtn>
          </div>
        </>
      )}
      {kind === "vehicle" && (
        <>
          <p className="font-semibold text-slate-900">🚚 {data.id}</p>
          <div className="text-xs text-slate-500 mt-1.5 space-y-1">
            <p>Driver: <span className="text-slate-800 font-medium">{data.driver}</span></p>
            <p>Cargo: <span className="text-slate-800 font-medium">{data.cargo}</span></p>
            <p>Destination: <span className="text-slate-800 font-medium">{data.destination}</span></p>
            <p>ETA: <span className="text-slate-800 font-medium">{data.eta}</span></p>
            <p>Risk: <TierBadge tier={riskTier(data.risk)} /></p>
          </div>
          <PrimaryBtn className="w-full mt-3 text-xs" onClick={() => onAction("track")}>Track Vehicle</PrimaryBtn>
        </>
      )}
      {kind === "incident" && (
        <>
          <p className="font-semibold text-slate-900 uppercase">{MARKER_ICON[data.type] || "📸"} {data.type}</p>
          <p className="text-xs text-slate-500 mt-1">{data.location}</p>
          <div className="text-xs text-slate-500 mt-1.5 space-y-1">
            <p>Severity: <Badge tone={data.severity === "HIGH" ? "red" : "amber"}>{data.severity}</Badge></p>
            <p>Detected: <span className="text-slate-800 font-medium">{data.time}</span></p>
            <p>Source: <span className="text-slate-800 font-medium">{data.severity === "HIGH" ? "Field Report + IoT Sensor" : "Field Report"}</span></p>
            <p>Impact: <span className="text-slate-800 font-medium">{data.usedForRisk ? "Applied to route risk" : data.severity === "HIGH" ? "Possible delay +45 min" : "Possible delay +15 min"}</span></p>
          </div>
          <PrimaryBtn className="w-full mt-3 text-xs" onClick={() => onAction("impact")}>View Impact</PrimaryBtn>
        </>
      )}
      {kind === "iot" && (
        <>
          <p className="font-semibold text-slate-900 flex items-center gap-1.5">📡 {data.name}</p>
          <div className="text-xs text-slate-500 mt-1.5 space-y-1">
            <p>Rainfall: <span className="text-slate-800 font-medium">{data.rainfall}</span></p>
            <p>Water Level: <span className="text-slate-800 font-medium">{data.waterLevel}</span></p>
            <p>Soil Movement: <span className="text-slate-800 font-medium">{data.soil}</span></p>
            <p>Status: <TierBadge tier={data.status} /></p>
          </div>
          <p className="text-xs text-slate-400 mt-2 italic">Simulated live IoT reading</p>
        </>
      )}
      {kind === "sos" && (
        <>
          <p className="font-semibold text-slate-900">🚨 {data.id}</p>
          <div className="text-xs text-slate-500 mt-1.5 space-y-1">
            <p>{data.type}</p>
            <p>{data.location}</p>
            <p>Status: <StatusBadge status={data.status} /></p>
          </div>
          <PrimaryBtn className="w-full mt-3 text-xs bg-red-600 hover:bg-red-700" onClick={() => onAction("sos")}>View SOS</PrimaryBtn>
        </>
      )}
      {kind === "current" && (
        <>
          <p className="font-semibold text-slate-900 flex items-center gap-1.5">🔵 You are here</p>
          <p className="text-xs text-slate-400 mt-0.5">Simulated GPS location — near Guwahati</p>
          <p className="text-xs text-slate-500 mt-1.5">Nearby risk: <TierBadge tier="safe" /></p>
        </>
      )}
    </div>
  );
}

function NavigationModal({ open, onClose, info }) {
  const { t, lang } = useT();
  if (!open || !info) return null;
  const tier = riskTier(info.risk);
  const dest = info.via.split(" → ").slice(-1)[0];
  const voiceLine = info.weather === "Heavy Rain" ? t("voiceHeavyRain") : t("voiceRouteClear");
  return (
    <Modal open={open} onClose={onClose}>
      <div className="p-6">
        <p className="text-xs font-semibold tracking-wide text-teal-700 uppercase nr-mono mb-1">{t("navigationStarted")}</p>
        <h3 className="text-lg font-bold text-slate-900 nr-font mb-4">{info.name}</h3>
        <div className={`rounded-xl p-4 mb-4 border ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].border}`}>
          <p className="text-sm font-semibold text-slate-700">{t("continueToward")} {dest}</p>
          <p className="text-xs text-slate-500 mt-0.5">via {info.via}</p>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-stone-50 rounded-lg p-3"><p className="text-xs text-slate-400">{t("eta")}</p><p className="font-bold nr-mono text-slate-800">{info.eta}</p></div>
          <div className="bg-stone-50 rounded-lg p-3"><p className="text-xs text-slate-400">{t("riskColon")}</p><TierBadge tier={tier} /></div>
        </div>
        <button onClick={() => speak(voiceLine, lang)} className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg py-2.5 text-sm font-semibold mb-2"><Volume2 size={15} /> {t("playVoiceAlert")}</button>
        <p className="text-xs text-slate-400 text-center italic mb-4">"{voiceLine}"</p>
        <SecondaryBtn className="w-full" onClick={onClose}>{t("endNavigation")}</SecondaryBtn>
      </div>
    </Modal>
  );
}

function MapView({ routes, vehicles, incidents, sosList, onOpenRoute, onOpenVehicle, onOpenIncident, onOpenSOS, focusFilter, onClearFilter, simVehicleId, onStopSim, routeOptions, activeRouteId, onSetActiveRoute, onOpenRouteOption, focusLayer, spotlight, onUseForRouteRisk }) {
  const [layers, setLayers] = useState(() => {
    const base = { risk: true, vehicles: true, weather: false, sos: false, roadBlockages: false, fieldReports: true, iot: true };
    if (focusLayer && focusLayer in base) base[focusLayer] = true;
    if (focusLayer === "roadBlockages") base.risk = true;
    return base;
  });
  const [zoom, setZoom] = useState(1);
  const [hover, setHover] = useState(null);
  const [planFrom, setPlanFrom] = useState("Guwahati");
  const [planTo, setPlanTo] = useState("Aizawl");
  const [showPlan, setShowPlan] = useState(true);
  const [selectedGeneric, setSelectedGeneric] = useState("primary");
  const [layersOpen, setLayersOpen] = useState(false);
  const [popup, setPopup] = useState(null);
  const [showCurrentLoc, setShowCurrentLoc] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [legendOpen, setLegendOpen] = useState(false);
  const [legendFilter, setLegendFilter] = useState(null);
  const [spotlightActive, setSpotlightActive] = useState(false);
  const [spotlightBox, setSpotlightBox] = useState(null);
  const [riskAreasOpen, setRiskAreasOpen] = useState(false);

  const toggleLayer = (k) => setLayers((l) => ({ ...l, [k]: !l[k] }));
  const isFlagshipCorridor = planFrom === "Guwahati" && planTo === "Aizawl";
  const { adj, byPair } = useMemo(() => buildGraph(routes), [routes]);

  const openMarker = (kind, data) => setPopup({ kind, data });

  useEffect(() => {
    if (!spotlight) return;
    setLocalSpotlight(null);
    let keys = null;
    if (spotlight.kind === "vehicle") {
      const v = vehicles.find((x) => x.id === spotlight.id);
      if (v) {
        const r = routes.find((x) => x.id === v.routeId);
        if (r) keys = [r.from, r.to];
        setLayers((l) => ({ ...l, vehicles: true }));
        openMarker("vehicle", v);
      }
    } else if (spotlight.kind === "incident") {
      const inc = incidents.find((x) => x.id === spotlight.id);
      if (inc) {
        const r = routes.find((x) => x.id === inc.routeId);
        if (r) keys = [r.from, r.to];
        openMarker("incident", inc);
      }
    } else if (spotlight.kind === "sos") {
      const activeSos = sosList.filter((x) => x.status !== "RESOLVED");
      const idx = activeSos.findIndex((x) => x.id === spotlight.id);
      const s = sosList.find((x) => x.id === spotlight.id);
      if (s && idx >= 0) {
        const cityKeys = Object.keys(CITIES);
        const key = cityKeys[idx % cityKeys.length];
        keys = [key];
        setLayers((l) => ({ ...l, sos: true }));
        openMarker("sos", s);
      }
    } else if (spotlight.kind === "route") {
      const r = routes.find((x) => x.id === spotlight.id);
      if (r) {
        setPlanFrom(CITIES[r.from].name); setPlanTo(CITIES[r.to].name); setShowPlan(true);
        keys = [r.from, r.to];
      }
    }
    if (keys) setSpotlightBox(fitViewBox(keys, 95));
    setSpotlightActive(true);
    const tm = setTimeout(() => setSpotlightActive(false), 2700);
    return () => clearTimeout(tm);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spotlight]);

  const [localSpotlight, setLocalSpotlight] = useState(null);
  const effectiveSpotlight = localSpotlight || spotlight;
  const isSpotlit = (kind, id) => spotlightActive && effectiveSpotlight && effectiveSpotlight.kind === kind && effectiveSpotlight.id === id;
  const spotlightRoute = (routeId) => {
    const r = routes.find((x) => x.id === routeId);
    if (!r) return;
    setPlanFrom(CITIES[r.from].name); setPlanTo(CITIES[r.to].name); setShowPlan(true);
    if (r.from === "guwahati" && r.to === "aizawl" && onSetActiveRoute) onSetActiveRoute("B");
    setSpotlightBox(fitViewBox([r.from, r.to], 95));
    setLocalSpotlight({ kind: "route", id: routeId });
    setSpotlightActive(true);
    setTimeout(() => setSpotlightActive(false), 2700);
  };


  const fromKey = cityKeyByName(planFrom), toKey = cityKeyByName(planTo);
  const genericPrimary = useMemo(() => (!isFlagshipCorridor && fromKey && toKey) ? findPath(adj, fromKey, toKey) : null, [adj, fromKey, toKey, isFlagshipCorridor]);
  const genericPrimaryMetrics = useMemo(() => genericPrimary ? pathMetrics(genericPrimary, byPair) : null, [genericPrimary, byPair]);
  const genericAlt = useMemo(() => {
    if (!genericPrimary || !genericPrimaryMetrics || genericPrimary.length < 2) return null;
    const excludeId = genericPrimaryMetrics.edgeIds[0];
    const alt = findPath(adj, fromKey, toKey, excludeId);
    if (!alt || alt.join() === genericPrimary.join()) return null;
    return alt;
  }, [genericPrimary, genericPrimaryMetrics, adj, fromKey, toKey]);
  const genericAltMetrics = useMemo(() => genericAlt ? pathMetrics(genericAlt, byPair) : null, [genericAlt, byPair]);

  const hideBackground = showPlan && (isFlagshipCorridor || !!genericPrimary);
  const visibleRoutes = routes.filter((r) => {
    if (isFlagshipCorridor && r.id === "R-GHY-AIZ") return false;
    if (!focusFilter) return true;
    if (focusFilter === "safe") return riskTier(r.risk) === "safe";
    if (focusFilter === "atrisk") return riskTier(r.risk) === "moderate" || riskTier(r.risk) === "high";
    if (focusFilter === "blocked") return riskTier(r.risk) === "blocked";
    return true;
  });

  const ROUTE_PATHS = { A: ["guwahati", "kohima", "aizawl"], B: ["guwahati", "silchar", "aizawl"], C: ["guwahati", "shillong", "aizawl"] };
  const midOf = (ids) => { const pts = ids.map((k) => CITIES[k]); return pts[Math.floor(pts.length / 2)]; };

  let routeCityKeys = [];
  if (showPlan && isFlagshipCorridor) routeCityKeys = ["guwahati", "kohima", "aizawl", "silchar", "shillong"];
  else if (showPlan && genericPrimary) routeCityKeys = [...genericPrimary, ...(genericAlt || [])];
  const relevantKeys = new Set(routeCityKeys);
  if (fromKey) relevantKeys.add(fromKey);
  if (toKey) relevantKeys.add(toKey);
  const viewBox = spotlightActive && spotlightBox ? spotlightBox : (routeCityKeys.length === 0 ? "100 100 500 420" : fitViewBox(routeCityKeys));

  // Build a uniform list of route candidates: [{id, name, via, distance, eta, risk, weather, road, traffic, incidents, raw}]
  let candidates = [];
  if (isFlagshipCorridor && routeOptions) {
    candidates = routeOptions.map((r) => ({ id: r.id, name: r.name, via: r.via, distance: r.distance, eta: r.eta, risk: r.risk, weather: r.weather, road: r.road, traffic: r.traffic, incidents: r.incidents, raw: r }));
  } else if (genericPrimary && genericPrimaryMetrics) {
    const mk = (path, m, name, id) => { const tier = riskTier(m.risk); return { id, name, via: path.map((k) => CITIES[k].name).join(" → "), distance: `${m.km} km`, eta: m.eta, risk: m.risk, weather: m.risk >= 55 ? "Heavy Rain" : "Clear", road: tier === "safe" ? "Good" : tier === "moderate" ? "Fair" : "Poor", traffic: "Moderate", incidents: 0 }; };
    candidates.push(mk(genericPrimary, genericPrimaryMetrics, "Route 1", "PRIMARY"));
    if (genericAlt && genericAltMetrics) candidates.push(mk(genericAlt, genericAltMetrics, "Route 2", "ALT"));
  }
  const recommended = candidates.length ? [...candidates].sort((a, b) => a.risk - b.risk)[0] : null;
  const currentSelId = isFlagshipCorridor ? activeRouteId : (selectedGeneric === "alt" ? "ALT" : "PRIMARY");
  const selected = candidates.find((c) => c.id === currentSelId) || recommended;
  const alternates = candidates.filter((c) => recommended && c.id !== recommended.id);

  const selectRoute = (id) => { if (isFlagshipCorridor) onSetActiveRoute && onSetActiveRoute(id); else setSelectedGeneric(id === "ALT" ? "alt" : "primary"); };

  const handlePopupAction = (action) => {
    if (!popup) return;
    if (action === "setSource") { setPlanFrom(popup.data.name); setShowPlan(true); }
    if (action === "setDest") { setPlanTo(popup.data.name); setShowPlan(true); }
    if (action === "track") onOpenVehicle(popup.data);
    if (action === "impact") { viewHazardImpact(popup.data); return; }
    if (action === "sos") onOpenSOS(popup.data);
    setPopup(null);
  };

  const viewHazardImpact = (inc) => {
    const r = routes.find((x) => x.id === inc.routeId);
    if (r) setSpotlightBox(fitViewBox([r.from, r.to], 90));
    setLocalSpotlight({ kind: "incident", id: inc.id });
    setSpotlightActive(true);
    setTimeout(() => setSpotlightActive(false), 2700);
    const eligible = ["Landslide", "Flood", "Road Damage", "Bridge Damage"].includes(inc.type) && inc.severity === "HIGH" && !inc.usedForRisk;
    if (eligible && onUseForRouteRisk) onUseForRouteRisk(inc);
    setPopup(null);
  };

  const mapBg = "#eef2ec", terrainColor = "#c9ddc4", riverColor = "#9dc6dd", cityFill = "#475569", cityFillDim = "#b6c2ba", labelFill = "#334155", labelDim = "#a3ada6", casing = "#1e293b";
  const importantIncidents = incidents.filter((inc) => inc.severity === "HIGH");

  return (
    <div className={`${cardCls} overflow-hidden`}>
      <div className="p-3 border-b border-stone-200 flex flex-wrap items-end gap-2">
        <div className="flex items-center gap-1.5 text-sm">
          <div>
            <p className="text-xs font-semibold text-slate-400">FROM</p>
            <select value={planFrom} onChange={(e) => { setPlanFrom(e.target.value); setShowPlan(true); }} className="border border-stone-300 rounded-lg px-2 py-1.5 text-sm bg-white mt-0.5">
              {CITY_LIST.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <button onClick={() => { const f = planFrom; setPlanFrom(planTo); setPlanTo(f); }} className="p-1.5 mt-4 rounded-full border border-stone-200 text-slate-500 hover:bg-stone-50" title="Swap"><RefreshCw size={13} /></button>
          <div>
            <p className="text-xs font-semibold text-slate-400">TO</p>
            <select value={planTo} onChange={(e) => { setPlanTo(e.target.value); setShowPlan(true); }} className="border border-stone-300 rounded-lg px-2 py-1.5 text-sm bg-white mt-0.5">
              {CITY_LIST.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <PrimaryBtn onClick={() => setShowPlan(true)} icon={RouteIcon}>Get Route</PrimaryBtn>
        {showPlan && <GhostBtn onClick={() => setShowPlan(false)}>Show Full Map</GhostBtn>}
        {focusFilter && (
          <button onClick={onClearFilter} className="text-xs font-medium px-2.5 py-1.5 rounded-full border border-teal-300 bg-teal-50 text-teal-700 flex items-center gap-1">
            Filtered: {focusFilter === "safe" ? "Accessible" : focusFilter === "atrisk" ? "At-Risk" : "Blocked"} <X size={11} />
          </button>
        )}
      </div>
      <div className="px-3 py-2 border-b border-stone-100 flex flex-wrap gap-1.5">
        {[["risk", "Risk Levels"], ["weather", "Weather"], ["fieldReports", "Incidents"], ["iot", "IoT Sensors"], ["vehicles", "Vehicles"]].map(([k, label]) => (
          <button key={k} onClick={() => toggleLayer(k)}
            className={`text-xs font-medium px-3 py-1.5 rounded-full border transition-colors ${layers[k] ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-500 border-stone-200 hover:bg-stone-50"}`}>
            {label}
          </button>
        ))}
      </div>

      <div className="flex flex-col md:flex-row">
        <div className="relative overflow-hidden flex-1 min-w-0" style={{ background: mapBg, height: 480 }}>
          <MarkerPopupCard popup={popup} onClose={() => setPopup(null)} onAction={handlePopupAction} />

          <div className="absolute inset-0">
            <svg viewBox={viewBox} className="w-full h-full" style={{ transform: `scale(${zoom})`, transformOrigin: "center", transition: "transform 200ms, viewBox 250ms" }}>
              <rect x="-200" y="-200" width="1200" height="1000" fill={mapBg} />
              <g opacity={0.55}>
                <ellipse cx="540" cy="150" rx="150" ry="85" fill={terrainColor} />
                <ellipse cx="130" cy="360" rx="130" ry="95" fill={terrainColor} />
                <ellipse cx="600" cy="440" rx="145" ry="105" fill={terrainColor} />
                <ellipse cx="300" cy="470" rx="115" ry="75" fill={terrainColor} />
                <ellipse cx="230" cy="150" rx="90" ry="60" fill={terrainColor} />
              </g>
              <path d="M 40 230 Q 180 265 300 252 Q 410 240 480 275 Q 580 315 780 295" fill="none" stroke={riverColor} strokeWidth="9" strokeLinecap="round" opacity={0.6} />

              {STATE_REGIONS.map((s) => (
                <g key={s.name} opacity={0.85}>
                  <ellipse cx={s.cx} cy={s.cy} rx={s.rx} ry={s.ry} fill={s.color} fillOpacity={0.05} stroke={s.color} strokeWidth="1.3" strokeDasharray="4 3" />
                  <text x={s.cx + s.labelDx} y={s.cy + s.labelDy} fontSize="10.5" fontWeight="700" textAnchor="middle" fill={s.color} opacity={0.8} style={{ letterSpacing: "0.4px" }}>{s.name.toUpperCase()}</text>
                </g>
              ))}

              {!hideBackground && visibleRoutes.map((r) => {
                const a = CITIES[r.from], b = CITIES[r.to];
                const tier = layers.risk ? riskTier(r.risk) : "moderate";
                const color = layers.risk ? RISK_TIERS[tier].hex : "#94a3b8";
                const isIncidentFiltered = legendFilter && ["Landslide", "Flood", "blockedRoute"].includes(legendFilter);
                const matchesIncidentFilter = legendFilter === "blockedRoute" ? tier === "blocked" : incidents.some((inc) => inc.routeId === r.id && inc.type === legendFilter);
                const dimmedByLegend = legendFilter && (["safe", "moderate", "high", "blocked"].includes(legendFilter) ? tier !== legendFilter : (isIncidentFiltered && !matchesIncidentFilter));
                const baseOpacity = tier === "blocked" ? 0.85 : 0.7;
                return (
                  <g key={r.id} onClick={() => onOpenRoute(r)} onMouseEnter={() => setHover(r.id)} onMouseLeave={() => setHover(null)} style={{ cursor: "pointer" }}>
                    <title>{`${CITIES[r.from].name} → ${CITIES[r.to].name} · Risk ${r.risk}/100`}</title>
                    {isSpotlit("route", r.id) && <path d={curvedEdgePath(a, b, r.id)} fill="none" stroke={color} strokeWidth={14} strokeLinecap="round" className="nr-map-glow" />}
                    <path d={curvedEdgePath(a, b, r.id)} fill="none" stroke={color} strokeWidth={hover === r.id || isSpotlit("route", r.id) ? 6 : 3.5} strokeLinecap="round" opacity={dimmedByLegend ? 0.12 : baseOpacity} strokeDasharray={tier === "blocked" ? "2 6" : "none"} />
                    {layers.weather && r.risk >= 55 && (<text x={(a.x + b.x) / 2 + 12} y={(a.y + b.y) / 2 - 10} fontSize="12" textAnchor="middle">🌧️</text>)}
                    {layers.roadBlockages && tier === "blocked" && (<text x={(a.x + b.x) / 2 - 12} y={(a.y + b.y) / 2 + 8} fontSize="12" textAnchor="middle">🚧</text>)}
                  </g>
                );
              })}

              {showPlan && isFlagshipCorridor && routeOptions && Object.entries(ROUTE_PATHS).map(([id, ids]) => {
                const r = routeOptions.find((x) => x.id === id);
                if (!r) return null;
                const tier = riskTier(r.risk);
                const color = RISK_TIERS[tier].hex;
                const active = currentSelId === id;
                const pts = ids.map((k) => CITIES[k]);
                const d = smoothPath(pts);
                const m = midOf(ids);
                return (
                  <g key={id} onClick={() => selectRoute(id)} style={{ cursor: "pointer" }}>
                    {active && <path d={d} fill="none" stroke={casing} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />}
                    {active && spotlightActive && effectiveSpotlight?.kind === "route" && <path d={d} fill="none" stroke={color} strokeWidth={18} strokeLinecap="round" className="nr-map-glow" />}
                    <path d={d} fill="none" stroke={color} strokeWidth={active ? 6 : 4} strokeLinecap="round" strokeLinejoin="round" opacity={active ? 1 : 0.85} strokeDasharray={tier === "blocked" ? "2 7" : "none"} />
                    <circle cx={m.x} cy={m.y - (id === "A" ? 18 : id === "C" ? -18 : 0)} r={active ? 11 : 9} fill={color} stroke="white" strokeWidth="1.5" />
                    <text x={m.x} y={m.y - (id === "A" ? 18 : id === "C" ? -18 : 0) + 3} fontSize={active ? 11 : 10} textAnchor="middle" fill="white" fontWeight="700">{id}</text>
                  </g>
                );
              })}

              {showPlan && !isFlagshipCorridor && genericAlt && genericAltMetrics && (
                <path onClick={() => selectRoute("ALT")} style={{ cursor: "pointer" }} d={smoothPath(genericAlt.map((k) => CITIES[k]))} fill="none"
                  stroke={RISK_TIERS[riskTier(genericAltMetrics.risk)].hex} strokeWidth={currentSelId === "ALT" ? 6 : 4} strokeLinecap="round" strokeLinejoin="round" opacity={currentSelId === "ALT" ? 1 : 0.8} strokeDasharray="5 6" />
              )}
              {showPlan && !isFlagshipCorridor && genericPrimary && genericPrimaryMetrics && (
                <g onClick={() => selectRoute("PRIMARY")} style={{ cursor: "pointer" }}>
                  {currentSelId === "PRIMARY" && <path d={smoothPath(genericPrimary.map((k) => CITIES[k]))} fill="none" stroke={casing} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />}
                  {spotlightActive && effectiveSpotlight?.kind === "route" && <path d={smoothPath(genericPrimary.map((k) => CITIES[k]))} fill="none" stroke={RISK_TIERS[riskTier(genericPrimaryMetrics.risk)].hex} strokeWidth={16} strokeLinecap="round" className="nr-map-glow" />}
                  <path d={smoothPath(genericPrimary.map((k) => CITIES[k]))} fill="none" stroke={RISK_TIERS[riskTier(genericPrimaryMetrics.risk)].hex} strokeWidth={currentSelId === "PRIMARY" ? 6 : 4} strokeLinecap="round" strokeLinejoin="round" opacity={currentSelId === "PRIMARY" ? 1 : 0.85} />
                </g>
              )}

              {Object.entries(CITIES).map(([key, c]) => {
                const isSrc = showPlan && key === fromKey, isDst = showPlan && key === toKey;
                const isRelevant = !showPlan || relevantKeys.has(key);
                const showLabel = isSrc || isDst || isRelevant;
                return (
                  <g key={key} onClick={() => { setSpotlightBox(fitViewBox([key], 60)); setLocalSpotlight({ kind: "place", id: key }); setSpotlightActive(true); setTimeout(() => setSpotlightActive(false), 2200); openMarker("place", { key, name: c.name }); }} style={{ cursor: "pointer" }}>
                    <circle cx={c.x} cy={c.y} r={isSrc || isDst ? 8 : isRelevant ? 4.5 : 3} fill={isSrc ? "#059669" : isDst ? "#dc2626" : isRelevant ? cityFill : cityFillDim} stroke="white" strokeWidth={isRelevant || isSrc || isDst ? 2 : 1} />
                    {isSrc && <text x={c.x} y={c.y + 3.5} fontSize="9" textAnchor="middle">📍</text>}
                    {isDst && <text x={c.x} y={c.y + 3.5} fontSize="9" textAnchor="middle">🏁</text>}
                    {showLabel && (
                      <text x={c.x + (isSrc || isDst ? 12 : 8)} y={c.y + 4} fontSize={isSrc || isDst ? "12" : "10.5"} fill={isRelevant || isSrc || isDst ? labelFill : labelDim} fontWeight={isSrc || isDst ? "700" : "500"}>{c.name}</text>
                    )}
                  </g>
                );
              })}

              {zoom > 1.15 && MINOR_TOWNS.map((town) => (
                <g key={town.name}>
                  <circle cx={town.x} cy={town.y} r="2" fill={labelDim} stroke="white" strokeWidth="0.75" />
                  <text x={town.x + 6} y={town.y + 3} fontSize="8" fill={labelDim} fontWeight="500">{town.name}</text>
                </g>
              ))}

              {showCurrentLoc && (
                <g onClick={() => openMarker("current", {})} style={{ cursor: "pointer" }}>
                  <circle cx={CITIES.guwahati.x + 22} cy={CITIES.guwahati.y + 18} r="11" fill="#2563eb" opacity="0.22" />
                  <circle cx={CITIES.guwahati.x + 22} cy={CITIES.guwahati.y + 18} r="5" fill="#2563eb" stroke="white" strokeWidth="2" />
                </g>
              )}

              {layers.vehicles && vehicles.map((v) => {
                const r = routes.find((x) => x.id === v.routeId);
                if (!r) return null;
                const a = CITIES[r.from], b = CITIES[r.to];
                const x = a.x + (b.x - a.x) * v.pos, y = a.y + (b.y - a.y) * v.pos;
                return (
                  <g key={v.id} onClick={() => openMarker("vehicle", v)} style={{ cursor: "pointer" }}>
                    {isSpotlit("vehicle", v.id) && <circle cx={x} cy={y} r="9" fill="none" stroke="#0f766e" strokeWidth="3" className="nr-map-pulse" />}
                    <circle cx={x} cy={y} r="9" fill="#0f766e" opacity="0.18" />
                    <rect x={x - 6} y={y - 6} width="12" height="12" rx="3" fill={v.id === simVehicleId ? "#0f766e" : "#1e293b"} stroke="white" strokeWidth="1.5" />
                  </g>
                );
              })}

              {layers.fieldReports && importantIncidents.map((inc) => {
                const r = routes.find((x) => x.id === inc.routeId);
                if (!r) return null;
                const a = CITIES[r.from], b = CITIES[r.to];
                const x = a.x + (b.x - a.x) * 0.55, y = a.y + (b.y - a.y) * 0.55;
                const dimmed = ["Landslide", "Flood"].includes(legendFilter) && inc.type !== legendFilter;
                return (
                  <g key={inc.id} onClick={() => openMarker("incident", inc)} style={{ cursor: "pointer" }} opacity={dimmed ? 0.15 : 1}>
                    {isSpotlit("incident", inc.id) && <circle cx={x} cy={y - 2} r="9" fill="none" stroke="#dc2626" strokeWidth="3" className="nr-map-pulse" />}
                    <circle cx={x} cy={y - 2} r="9" fill="#dc2626" stroke="white" strokeWidth="1.5" />
                    <text x={x} y={y + 2.5} fontSize="10" textAnchor="middle">{MARKER_ICON[inc.type] || "📸"}</text>
                  </g>
                );
              })}

              {layers.iot && IOT_SENSORS.map((s) => {
                const r = routes.find((x) => x.id === s.routeId);
                if (!r) return null;
                const a = CITIES[r.from], b = CITIES[r.to];
                const x = a.x + (b.x - a.x) * 0.3, y = a.y + (b.y - a.y) * 0.3;
                return (
                  <g key={s.id} onClick={() => openMarker("iot", s)} style={{ cursor: "pointer" }} opacity={legendFilter === "iot" ? 1 : legendFilter ? 0.3 : 1}>
                    <circle cx={x} cy={y} r="8" fill="#7c3aed" stroke="white" strokeWidth="1.5" opacity={0.9} />
                    <text x={x} y={y + 3} fontSize="9" textAnchor="middle">📡</text>
                  </g>
                );
              })}

              {layers.sos && sosList.filter((s) => s.status !== "RESOLVED").map((s, i) => {
                const c = Object.values(CITIES)[i % Object.values(CITIES).length];
                return (
                  <g key={s.id} onClick={() => openMarker("sos", s)} style={{ cursor: "pointer" }}>
                    {isSpotlit("sos", s.id) && <circle cx={c.x + 14} cy={c.y - 14} r="10" fill="none" stroke="#dc2626" strokeWidth="3" className="nr-map-pulse" />}
                    <circle cx={c.x + 14} cy={c.y - 14} r="10" fill="#dc2626" className="nr-blink" />
                    <text x={c.x + 14} y={c.y - 10} fontSize="10" textAnchor="middle">🚨</text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Essential controls only */}
          <div className="absolute right-3 top-3 flex flex-col gap-1.5 z-10">
            <button onClick={() => setZoom((z) => Math.min(2, z + 0.2))} className="w-9 h-9 rounded-lg bg-white shadow border border-stone-200 flex items-center justify-center text-slate-600" title="Zoom in"><ZoomIn size={16} /></button>
            <button onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))} className="w-9 h-9 rounded-lg bg-white shadow border border-stone-200 flex items-center justify-center text-slate-600" title="Zoom out"><ZoomOut size={16} /></button>
            <button onClick={() => { setShowCurrentLoc(true); openMarker("current", {}); }} className="w-9 h-9 rounded-lg bg-white shadow border border-stone-200 flex items-center justify-center text-blue-600" title="My location"><Navigation size={16} /></button>
            <div className="relative">
              <button onClick={() => setLayersOpen((v) => !v)} className={`w-9 h-9 rounded-lg shadow border flex items-center justify-center ${layersOpen ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-600 border-stone-200"}`} title="Layers"><Layers size={16} /></button>
              {layersOpen && (
                <div className="absolute right-11 top-0 bg-white rounded-lg shadow-lg border border-stone-200 p-2 w-40">
                  {[["vehicles", "Vehicles"], ["weather", "Weather"], ["fieldReports", "Field Reports"], ["iot", "IoT Sensors"]].map(([k, label]) => (
                    <button key={k} onClick={() => toggleLayer(k)} className="w-full flex items-center justify-between px-2 py-1.5 rounded-md hover:bg-stone-50 text-xs">
                      <span className="text-slate-600">{label}</span>
                      <span className={`w-4 h-4 rounded border flex items-center justify-center ${layers[k] ? "bg-teal-700 border-teal-700" : "border-stone-300"}`}>{layers[k] && <Check size={11} className="text-white" />}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Collapsible interactive legend */}
          <div className="absolute left-3 bottom-3 z-10">
            <button onClick={() => setLegendOpen((v) => !v)} className={`w-9 h-9 rounded-lg shadow border flex items-center justify-center ${legendOpen ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-600 border-stone-200"}`} title="Legend"><Info size={16} /></button>
            {legendOpen && (
              <div className="absolute left-0 bottom-11 bg-white rounded-lg border border-stone-200 shadow-lg px-3 py-2.5 text-xs w-52">
                <p className="font-semibold text-slate-600 mb-1.5">RISK LEVEL</p>
                {[["safe", "🟢", "Low"], ["moderate", "🟡", "Moderate"], ["high", "🟠", "High"], ["blocked", "🔴", "Blocked / Very High"]].map(([tier, emoji, label]) => {
                  const count = routes.filter((r) => riskTier(r.risk) === tier).length;
                  const active = legendFilter === tier;
                  return (
                    <button key={tier} onClick={() => setLegendFilter(active ? null : tier)} className={`w-full flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-stone-50 ${active ? "bg-teal-50" : ""}`}>
                      <span>{emoji} {label}</span><span className="text-slate-400">{count}</span>
                    </button>
                  );
                })}
                <p className="font-semibold text-slate-600 mt-2 mb-1.5">INCIDENTS</p>
                {[["Landslide", "⛰️"], ["Flood", "🌊"], ["blockedRoute", "🚧 Road Block"]].map(([type, emoji]) => {
                  const active = legendFilter === type;
                  const count = type === "blockedRoute" ? routes.filter((r) => riskTier(r.risk) === "blocked").length : incidents.filter((i) => i.type === type).length;
                  return (
                    <button key={type} onClick={() => setLegendFilter(active ? null : type)} className={`w-full flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-stone-50 ${active ? "bg-teal-50" : ""}`}>
                      <span>{type === "blockedRoute" ? emoji : `${emoji} ${type}`}</span><span className="text-slate-400">{count}</span>
                    </button>
                  );
                })}
                <p className="font-semibold text-slate-600 mt-2 mb-1">ROUTES</p>
                <div className="space-y-0.5 text-slate-500">
                  <div className="flex items-center gap-1.5">🟢 Recommended Route</div>
                  <div className="flex items-center gap-1.5">🟡 At-Risk Route</div>
                  <div className="flex items-center gap-1.5">🔴 Blocked Route</div>
                </div>
                <p className="font-semibold text-slate-600 mt-2 mb-1">MARKERS</p>
                <button onClick={() => setLegendFilter(legendFilter === "iot" ? null : "iot")} className={`w-full flex items-center justify-between px-1.5 py-1 rounded-md hover:bg-stone-50 ${legendFilter === "iot" ? "bg-teal-50" : ""}`}>
                  <span>📡 IoT Sensor</span><span className="text-slate-400">{IOT_SENSORS.length}</span>
                </button>
                <div className="space-y-0.5 text-slate-500 mt-0.5">
                  <div className="flex items-center gap-1.5">🚚 Vehicle</div>
                  <div className="flex items-center gap-1.5">🌉 Bridge</div>
                  <div className="flex items-center gap-1.5" style={{ opacity: 0.85 }}>┅ State Boundary</div>
                </div>
                {legendFilter && <p className="text-teal-700 font-medium mt-2 pt-2 border-t border-stone-100">Showing only matching areas</p>}
              </div>
            )}
          </div>
          {simVehicleId && (
            <div className="absolute right-3 bottom-3 z-10">
              <SecondaryBtn onClick={onStopSim}>Stop Simulation</SecondaryBtn>
            </div>
          )}
        </div>

        {/* Route panel — instantly readable */}
        <div className="border-t md:border-t-0 md:border-l border-stone-200 md:w-80 shrink-0 bg-white flex flex-col max-h-96 md:max-h-none overflow-y-auto nr-scroll">
          {recommended ? (
            <>
              <div className="p-3.5 bg-teal-50 border-b border-teal-100">
                <p className="text-xs font-bold text-teal-800 flex items-center gap-1.5">🤖 NE-RAAH Recommends</p>
                <p className="text-sm text-teal-900 mt-1">"{recommended.name} is currently the safest option."</p>
              </div>

              {candidates.length > 1 && (
                <div className="p-3 border-b border-stone-100 flex gap-2 overflow-x-auto">
                  {candidates.map((c) => (
                    <button key={c.id} onClick={() => selectRoute(c.id)}
                      className={`shrink-0 text-left px-3 py-2 rounded-lg border text-xs transition-all ${currentSelId === c.id ? "ring-2 ring-teal-600 border-teal-600" : "border-stone-200 hover:bg-stone-50"}`}>
                      <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${RISK_TIERS[riskTier(c.risk)].dot}`} />
                        {c.name} {c.id === recommended.id && "⭐"}
                      </p>
                      <p className="text-slate-400 mt-0.5">{c.risk}/100</p>
                    </button>
                  ))}
                </div>
              )}

              {selected && (
                <div className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-slate-900 flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full ${RISK_TIERS[riskTier(selected.risk)].dot}`} />
                      {selected.id === recommended.id ? "RECOMMENDED ROUTE" : selected.name}
                    </p>
                    <TierBadge tier={riskTier(selected.risk)} />
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm border-t border-stone-100 pt-3">
                    <div><p className="text-xs text-slate-400">Distance</p><p className="font-semibold nr-mono text-slate-800">{selected.distance}</p></div>
                    <div><p className="text-xs text-slate-400">ETA</p><p className="font-semibold nr-mono text-slate-800">{selected.eta}</p></div>
                  </div>
                  {selected.id === recommended.id ? (
                    <div className="border-t border-stone-100 pt-3">
                      <p className="text-xs font-semibold text-slate-500 mb-1.5">Why?</p>
                      <ul className="space-y-1">
                        {whyBullets(selected).map((b, i) => (
                          <li key={i} className="text-xs text-emerald-700 flex items-center gap-1.5"><Check size={12} className="shrink-0" /> {b}</li>
                        ))}
                      </ul>
                    </div>
                  ) : (
                    <div className="border-t border-stone-100 pt-3 bg-amber-50 -mx-4 px-4 py-2.5">
                      <p className="text-xs text-amber-700 flex items-center gap-1.5"><TriangleAlert size={12} className="shrink-0" /> Carries higher risk than the recommended route.</p>
                    </div>
                  )}
                  <div className="flex flex-col gap-2 pt-1">
                    <PrimaryBtn onClick={() => setNavOpen(true)}>Start Navigation</PrimaryBtn>
                    <SecondaryBtn onClick={() => onOpenRouteOption && onOpenRouteOption(selected.raw || { ...selected, status: selected.id === recommended.id ? "RECOMMENDED" : "ALTERNATE", landslide: riskTier(selected.risk) === "high" ? "High" : "Low", flood: "Low" })}>View Why</SecondaryBtn>
                  </div>
                </div>
              )}

              <div className="p-4 border-t border-stone-100">
                <p className="text-xs font-semibold text-slate-500 mb-1.5">Weather Ahead</p>
                <div className="bg-stone-50 rounded-lg p-3 flex items-center gap-2.5">
                  <span className="text-xl">{selected?.weather === "Heavy Rain" ? "🌧️" : "☀️"}</span>
                  <div>
                    <p className="text-sm font-medium text-slate-700">{selected?.weather === "Heavy Rain" ? "Heavy Rain — Next 35 km" : "Clear conditions ahead"}</p>
                    <p className="text-xs text-slate-400">Risk: {riskTier(selected?.risk || 0) === "safe" ? "LOW" : riskTier(selected?.risk || 0) === "moderate" ? "MODERATE" : "HIGH"}</p>
                  </div>
                </div>
              </div>

              <div className="p-4 border-t border-stone-100">
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-xs font-semibold text-slate-500">Risk Areas</p>
                  <button onClick={() => setRiskAreasOpen((v) => !v)} className="text-xs text-teal-700 font-medium hover:underline">{riskAreasOpen ? "Show Less" : "View All"}</button>
                </div>
                <div className="space-y-1.5">
                  {[...routes].sort((a, b) => b.risk - a.risk).slice(0, riskAreasOpen ? routes.length : 4).map((r) => {
                    const tier = riskTier(r.risk);
                    const emoji = tier === "blocked" ? "🔴" : tier === "high" ? "🟠" : tier === "moderate" ? "🟡" : "🟢";
                    return (
                      <button key={r.id} onClick={() => spotlightRoute(r.id)} className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg border border-stone-100 hover:bg-stone-50 text-left">
                        <div className="min-w-0">
                          <p className="text-xs font-medium text-slate-800 truncate">{emoji} {r.label}</p>
                          <p className="text-xs text-slate-400">{ROUTE_STATE[r.id] || "NER"}</p>
                        </div>
                        <span className={`text-xs font-bold shrink-0 ml-2 ${RISK_TIERS[tier].text}`}>{r.risk}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-4 border-t border-stone-100">
                <p className="text-xs font-semibold text-slate-500 mb-1.5">Active Alerts on Route</p>
                {(() => {
                  const relevantIds = isFlagshipCorridor ? ["R-GHY-AIZ", "R-SIL-AIZ"] : (genericPrimaryMetrics ? genericPrimaryMetrics.edgeIds : []);
                  const relevant = incidents.filter((inc) => relevantIds.includes(inc.routeId));
                  if (relevant.length === 0) return <p className="text-xs text-slate-400">No active alerts on this route.</p>;
                  return (
                    <div className="space-y-1.5">
                      {relevant.map((inc) => (
                        <button key={inc.id} onClick={() => openMarker("incident", inc)} className="w-full flex items-start gap-2 px-2.5 py-2 rounded-lg border border-stone-100 hover:bg-stone-50 text-left">
                          <span className="text-sm mt-0.5">{MARKER_ICON[inc.type] || "📸"}</span>
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-slate-800">{inc.type}</p>
                            <p className="text-xs text-slate-400 truncate">{inc.location} · {inc.time}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  );
                })()}
              </div>

              <div className="p-4 border-t border-stone-100">
                <p className="text-xs font-semibold text-slate-500 mb-1.5">Live IoT Overview</p>
                <div className="grid grid-cols-3 gap-2">
                  {IOT_SENSORS.slice(0, 3).map((s) => (
                    <button key={s.id} onClick={() => openMarker("iot", s)} className="bg-stone-50 rounded-lg p-2 text-left hover:bg-stone-100">
                      <p className="text-xs text-slate-400">{s.name.split(" ")[0]}</p>
                      <p className="text-sm font-bold nr-mono text-slate-800">{s.rainfall !== "—" ? s.rainfall : s.waterLevel}</p>
                    </button>
                  ))}
                </div>
                <p className="text-xs text-slate-400 mt-1.5 italic">Simulated live sensor readings</p>
              </div>
            </>
          ) : (
            <div className="p-4"><EmptyState icon={RouteIcon} title="No route selected" sub="Choose a source and destination above to see route options." /></div>
          )}
        </div>
      </div>

      <div className="px-3 py-2 border-t border-stone-200 flex items-center justify-between text-xs text-slate-400">
        <span>Simulated GIS view — schematic road network for prototype purposes.</span>
        <UpdatedTag />
      </div>

      <NavigationModal open={navOpen} onClose={() => setNavOpen(false)} info={selected} />
    </div>
  );
}

/* ============================================================
   KPI CARDS + COMMAND CENTER (Authority Dashboard)
============================================================ */
const METRIC_TONES = {
  emerald: "text-emerald-700 bg-emerald-50", amber: "text-amber-700 bg-amber-50",
  red: "text-red-700 bg-red-50", slate: "text-slate-700 bg-slate-100", teal: "text-teal-700 bg-teal-50",
};
function MetricCard({ label, value, sub, breakdown, icon: Icon, tone, actionLabel = "View on Map", onClick }) {
  return (
    <button onClick={onClick} className={`${cardCls} p-4 text-left hover:shadow-md hover:-translate-y-0.5 transition-all flex flex-col`}>
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${METRIC_TONES[tone]}`}><Icon size={18} /></div>
      <p className="text-2xl font-bold text-slate-900 nr-mono leading-tight">{value}</p>
      <p className="text-xs font-semibold text-slate-700 mt-1">{label}</p>
      {sub && <p className="text-xs text-slate-500 mt-1.5">{sub}</p>}
      {breakdown && <p className="text-xs text-slate-400 mt-0.5">{breakdown}</p>}
      <span className="text-xs font-semibold text-teal-700 mt-3 pt-2.5 border-t border-stone-100 flex items-center gap-1">{actionLabel} <ChevronRight size={12} /></span>
    </button>
  );
}
function QuickAction({ label, icon: Icon, onClick }) {
  return (
    <button onClick={onClick} className={`${cardCls} p-3.5 flex items-center gap-3 text-left hover:shadow-md hover:border-teal-300 transition-all`}>
      <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0"><Icon size={17} /></div>
      <span className="text-sm font-semibold text-slate-800">{label}</span>
    </button>
  );
}

function CommandCenter({ role, user, kpis, onNav, onGoToMap, alerts, vehicles, shipments, onOpenAlert, onStartDemo, demoActive }) {
  const { t } = useT();
  const isAuthority = role === "authority";
  const accessPct = Math.round((kpis.accessible / kpis.totalCorridors) * 100);
  const healthLabel = kpis.logisticsHealth >= 80 ? "Good" : kpis.logisticsHealth >= 60 ? "Moderate" : kpis.logisticsHealth >= 40 ? "At Risk" : "Severe Disruption";
  const healthTone = kpis.logisticsHealth >= 80 ? "emerald" : kpis.logisticsHealth >= 60 ? "amber" : "red";

  const authorityMetrics = [
    { label: t("nerLogisticsHealth"), value: `${kpis.logisticsHealth}/100`, sub: healthLabel, breakdown: t("overallScoreDesc"), icon: Sparkles, tone: healthTone, actionLabel: t("viewOverview"), onClick: () => onGoToMap(null, null) },
    { label: t("accessibleCorridors"), value: `${kpis.accessible}/${kpis.totalCorridors}`, sub: `${accessPct}% Accessible`, icon: CheckCircle2, tone: "emerald", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("safe", null) },
    { label: t("atRiskCorridors"), value: kpis.atRisk, sub: `${kpis.atRiskHigh} High Risk`, breakdown: `${kpis.atRiskModerate} Moderate Risk`, icon: TriangleAlert, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("atrisk", null) },
    { label: t("blockedRoads"), value: kpis.blocked, sub: `${kpis.blockedLandslide} Landslide · ${kpis.blockedFlood} Flood`, icon: CircleAlert, tone: "red", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("blocked", "roadBlockages") },
    { label: t("criticalShipmentsTitle"), value: kpis.criticalShipments, sub: `${kpis.criticalShipmentsAtRisk} At Risk`, icon: Package, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "vehicles") },
    { label: t("activeVehiclesLabel"), value: kpis.activeVehicles, sub: `${kpis.vehiclesOnRoute} On Route · ${kpis.vehiclesDelayed} Delayed`, icon: Truck, tone: "teal", actionLabel: t("viewVehiclesAction"), onClick: () => onNav("vehicles") },
    { label: t("fieldReportsLabel"), value: kpis.fieldReports, sub: `${kpis.fieldReportsPending} Pending · ${kpis.fieldReportsVerified} Verified · ${kpis.fieldReportsResolved} Resolved`, icon: FileText, tone: "slate", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "fieldReports") },
    { label: t("activeSOSLabel"), value: kpis.activeSOS, sub: t("immediateAttention"), icon: Siren, tone: "red", actionLabel: t("viewSOSAction"), onClick: () => onNav("sos") },
    { label: t("weatherAlertsLabel"), value: kpis.weatherAlerts, sub: `${kpis.weatherSevere} Severe · ${kpis.weatherModerate} Moderate`, icon: CloudRain, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "weather") },
  ];
  const officerMetrics = [
    { label: t("accessibleCorridors"), value: `${kpis.accessible}/${kpis.totalCorridors}`, sub: `${accessPct}% Accessible`, breakdown: "↓ 3 corridors affected today", icon: CheckCircle2, tone: "emerald", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("safe", null) },
    { label: t("atRiskCorridors"), value: kpis.atRisk, sub: `${kpis.atRiskHigh} High Risk`, breakdown: `${kpis.atRiskModerate} Moderate Risk`, icon: TriangleAlert, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("atrisk", null) },
    { label: t("blockedCorridors"), value: kpis.blocked, sub: `${kpis.blockedLandslide} due to Landslide`, breakdown: `${kpis.blockedFlood} due to Flooding`, icon: CircleAlert, tone: "red", actionLabel: t("viewOnMap"), onClick: () => onGoToMap("blocked", "roadBlockages") },
    { label: t("activeFieldReportsLabel"), value: kpis.fieldReports, sub: `${kpis.fieldReportsPending} Pending Verification`, breakdown: `${kpis.fieldReportsVerified} Verified · ${kpis.fieldReportsResolved} Resolved`, icon: FileText, tone: "slate", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "fieldReports") },
    { label: t("weatherImpactedAreas"), value: kpis.weatherAlerts, sub: `${kpis.weatherSevere} High Risk`, breakdown: `${kpis.weatherModerate} Moderate Risk`, icon: CloudRain, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "weather") },
    { label: t("criticalShipmentsTitle"), value: kpis.criticalShipments, sub: `${kpis.criticalShipmentsAtRisk} Currently At Risk`, icon: Package, tone: "amber", actionLabel: t("viewOnMap"), onClick: () => onGoToMap(null, "vehicles") },
    { label: t("activeSOSLabel"), value: kpis.activeSOS, sub: t("immediateAttention"), icon: Siren, tone: "red", actionLabel: t("viewSOSAction"), onClick: () => onNav("sos") },
  ];
  const metrics = isAuthority ? authorityMetrics : officerMetrics;

  return (
    <div>
      <SectionHeader
        title={isAuthority ? t("commandCenterTitle") : `${t("welcomeBack")}, ${user.name.split(" ")[0]}`}
        sub={isAuthority ? t("commandCenterSub") : t("todayFocus")}
        right={isAuthority && !demoActive && <PrimaryBtn icon={PlayCircle} onClick={onStartDemo}>{t("startDemo")}</PrimaryBtn>}
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
        {metrics.map((m) => <MetricCard key={m.label} {...m} />)}
      </div>
      <div className="mb-6">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">{t("quickActions")}</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <QuickAction label={t("map")} icon={MapPinned} onClick={() => onNav("map")} />
          {isAuthority ? (
            <>
              <QuickAction label={t("vehicles")} icon={Truck} onClick={() => onNav("vehicles")} />
              <QuickAction label={t("shipments")} icon={Package} onClick={() => onNav("shipments")} />
              <QuickAction label={t("copilot")} icon={MessageSquare} onClick={() => onNav("copilot")} />
            </>
          ) : (
            <>
              <QuickAction label={t("reports")} icon={FileText} onClick={() => onNav("reports")} />
              <QuickAction label={t("weather")} icon={CloudRain} onClick={() => onNav("weather")} />
              <QuickAction label={t("sosCenter")} icon={Siren} onClick={() => onNav("sos")} />
            </>
          )}
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <div className={`${cardCls} p-4`}>
            <div className="flex items-center justify-between mb-3">
              <p className="font-semibold text-slate-800 text-sm">{t("recentAlerts")}</p>
              <GhostBtn onClick={() => onNav("alerts")}>{t("viewAll")} <ChevronRight size={14} /></GhostBtn>
            </div>
            <div className="divide-y divide-stone-100">
              {alerts.slice(0, 4).map((a) => <AlertRow key={a.id} a={a} onClick={() => onOpenAlert(a)} />)}
            </div>
          </div>
          {isAuthority && (
            <div className={`${cardCls} p-4`}>
              <p className="font-semibold text-slate-800 text-sm mb-3">{t("criticalShipmentsTitle")}</p>
              <div className="space-y-2">
                {shipments.filter((s) => s.priority === "CRITICAL").map((s) => (
                  <div key={s.id} className="flex items-center justify-between text-sm p-2.5 rounded-lg hover:bg-stone-50 cursor-pointer" onClick={() => onNav("shipments")}>
                    <div><p className="font-medium text-slate-800 nr-mono">{s.id}</p><p className="text-xs text-slate-400">{s.cargo} · {s.route}</p></div>
                    <StatusBadge status={s.status} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-3">Vehicles In Transit</p>
          <div className="space-y-2">
            {vehicles.slice(0, 5).map((v) => (
              <div key={v.id} className="flex items-center justify-between text-sm p-2 rounded-lg hover:bg-stone-50 cursor-pointer" onClick={() => onNav("vehicles")}>
                <div><p className="font-medium nr-mono text-slate-800">{v.id}</p><p className="text-xs text-slate-400">{v.destination}</p></div>
                <StatusBadge status={v.status} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AlertRow({ a, onClick }) {
  const iconTone = { critical: "🔴", warning: "🟠", info: "🔵" }[a.level] || "🟡";
  return (
    <button onClick={onClick} className="w-full flex items-start gap-3 py-2.5 text-left hover:bg-stone-50 -mx-1 px-1 rounded-lg">
      <span className="text-sm mt-0.5">{iconTone}</span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-800 truncate">{a.title}</p>
        <p className="text-xs text-slate-400 truncate">{a.detail}</p>
      </div>
      <span className="text-xs text-slate-400 shrink-0">{a.time}</span>
    </button>
  );
}

/* ============================================================
   ROUTE INTELLIGENCE
============================================================ */
function RouteIntelligence({ role, routeOptions, activeRouteId, onSetActive, onOpenExplain, driverView, incidentBanner }) {
  const { t } = useT();
  const [from, setFrom] = useState("Guwahati");
  const [to, setTo] = useState("Aizawl");
  const [commodity, setCommodity] = useState("Medical Supplies");
  const [priority, setPriority] = useState("Critical");
  const [analysed, setAnalysed] = useState(true);

  return (
    <div>
      <SectionHeader title={t("routeIntelTitle")} sub={t("routeIntelSub")} />
      {incidentBanner && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 text-sm flex items-center gap-2">
          <TriangleAlert size={16} /> {incidentBanner}
        </div>
      )}
      {!driverView && (
        <div className={`${cardCls} p-4 mb-5`}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="text-xs text-slate-500">From</label>
              <select value={from} onChange={(e) => setFrom(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
                {CITY_LIST.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500">To</label>
              <select value={to} onChange={(e) => setTo(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
                {CITY_LIST.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500">Commodity</label>
              <select value={commodity} onChange={(e) => setCommodity(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
                {COMMODITIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-slate-500">Priority</label>
              <select value={priority} onChange={(e) => setPriority(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
                <option>Critical</option><option>High</option><option>Standard</option>
              </select>
            </div>
          </div>
          <PrimaryBtn className="mt-3" icon={Sparkles} onClick={() => setAnalysed(true)}>Analyse Routes</PrimaryBtn>
        </div>
      )}
      {analysed && (
        <>
          <p className="text-sm text-slate-500 mb-3">{from} → {to} · {commodity} · <span className="font-medium">{priority} priority</span></p>
          <div className="grid md:grid-cols-3 gap-4">
            {routeOptions.map((r) => {
              const tier = riskTier(r.risk);
              const isActive = activeRouteId === r.id;
              return (
                <div key={r.id} className={`${cardCls} p-4 relative ${isActive ? "ring-2 ring-teal-600" : ""}`}>
                  {isActive && <span className="absolute -top-2 left-4 bg-teal-700 text-white text-xs font-bold px-2 py-0.5 rounded-full">CURRENT</span>}
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold text-slate-900">{r.name}</p>
                    <TierBadge tier={tier} />
                  </div>
                  <p className="text-xs text-slate-400 mb-3">{r.via}</p>
                  <div className="flex items-end gap-2 mb-3">
                    <p className="text-3xl font-bold nr-mono text-slate-900">{r.risk}</p>
                    <p className="text-xs text-slate-400 mb-1">/ 100 risk score</p>
                  </div>
                  <div className={`text-xs font-bold px-2 py-1 rounded-md inline-block mb-3 ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].text}`}>{r.status}</div>
                  <div className="grid grid-cols-2 gap-y-1.5 text-xs text-slate-500 border-t border-stone-100 pt-3">
                    <span>Distance</span><span className="text-right font-medium text-slate-700">{r.distance}</span>
                    <span>ETA</span><span className="text-right font-medium text-slate-700">{r.eta}</span>
                    <span>Weather Risk</span><span className="text-right font-medium text-slate-700">{r.weather}</span>
                    <span>Landslide Risk</span><span className="text-right font-medium text-slate-700">{r.landslide}</span>
                    <span>Flood Risk</span><span className="text-right font-medium text-slate-700">{r.flood}</span>
                    <span>Road Condition</span><span className="text-right font-medium text-slate-700">{r.road}</span>
                    <span>Traffic</span><span className="text-right font-medium text-slate-700">{r.traffic}</span>
                    <span>Recent Incidents</span><span className="text-right font-medium text-slate-700">{r.incidents}</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <SecondaryBtn className="flex-1" onClick={() => onOpenExplain(r)}>{t("viewWhy")}</SecondaryBtn>
                    {!isActive && <PrimaryBtn className="flex-1" onClick={() => onSetActive(r.id)}>{driverView ? t("reroute") : t("selectRoute")}</PrimaryBtn>}
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

function ExplainModal({ open, onClose, route }) {
  if (!open || !route) return null;
  const tier = riskTier(route.risk);
  return (
    <Modal open={open} onClose={onClose}>
      <div className="p-6">
        <p className="text-xs font-semibold tracking-wide text-teal-700 uppercase nr-mono mb-1">AI Route Decision</p>
        <h3 className="text-lg font-bold text-slate-900 nr-font mb-4">Why {route.name}?</h3>
        <div className="grid grid-cols-2 gap-y-2.5 text-sm mb-4">
          <span className="text-slate-500">Weather</span><span className="text-right font-medium">{route.weather}</span>
          <span className="text-slate-500">Landslide</span><span className="text-right font-medium">{route.landslide}</span>
          <span className="text-slate-500">Flood</span><span className="text-right font-medium">{route.flood}</span>
          <span className="text-slate-500">Road Condition</span><span className="text-right font-medium">{route.road}</span>
          <span className="text-slate-500">Traffic</span><span className="text-right font-medium">{route.traffic}</span>
          <span className="text-slate-500">Recent Incidents</span><span className="text-right font-medium">{route.incidents === 0 ? "None" : route.incidents}</span>
        </div>
        <div className={`rounded-lg p-3 border ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].border} flex items-center justify-between mb-3`}>
          <span className="text-sm font-semibold text-slate-700">Overall Risk</span>
          <span className="text-xl font-bold nr-mono">{route.risk} / 100</span>
        </div>
        <p className="text-sm text-slate-600 leading-relaxed">
          {route.status === "RECOMMENDED"
            ? `${route.name} is recommended because it carries a lower predicted disruption risk compared with the available alternatives.`
            : route.status === "AVOID"
            ? `${route.name} shows a substantially higher predicted disruption risk than the alternatives and should be avoided where possible.`
            : `${route.name} is a viable alternate with moderate predicted disruption risk.`}
        </p>
        <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-3"><Sparkles size={12} /> AI-assisted risk estimate — not a real-world validated prediction.</div>
      </div>
    </Modal>
  );
}

/* ============================================================
   VEHICLES
============================================================ */
function VehiclesPage({ vehicles, onOpen, simVehicleId, onSimulate }) {
  const { t } = useT();
  const [filter, setFilter] = useState("ALL");
  const statuses = ["ALL", "ON TIME", "DELAYED", "AT RISK", "STOPPED", "DELIVERED"];
  const filtered = filter === "ALL" ? vehicles : vehicles.filter((v) => v.status === filter);
  return (
    <div>
      <SectionHeader title={t("vehiclesTitle")} sub={t("vehiclesSub")} right={<UpdatedTag />} />
      <div className="flex gap-1.5 flex-wrap mb-4">
        {statuses.map((s) => (
          <button key={s} onClick={() => setFilter(s)} className={`text-xs font-medium px-3 py-1.5 rounded-full border ${filter === s ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-500 border-stone-200"}`}>{s === "ALL" ? t("allLabel") : t(STATUS_KEY[s] || s)}</button>
        ))}
      </div>
      {filtered.length === 0 ? <EmptyState icon={Truck} title={t("noActiveVehicles")} sub="Try a different status filter." /> : (
        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map((v) => (
            <button key={v.id} onClick={() => onOpen(v)} className={`${cardCls} p-4 text-left hover:shadow-md transition-shadow`}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-semibold nr-mono text-slate-900">{v.id}</p>
                  <p className="text-xs text-slate-400">{v.cargo}</p>
                </div>
                <StatusBadge status={v.status} />
              </div>
              <div className="flex items-center gap-1.5 text-sm text-slate-600 mb-2">
                <MapPin size={13} className="text-slate-400" /> {v.origin} <ArrowRight size={12} className="text-slate-300" /> {v.destination}
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs text-slate-500 border-t border-stone-100 pt-2.5">
                <div><p className="text-slate-400">Speed</p><p className="font-medium text-slate-700">{v.speed} km/h</p></div>
                <div><p className="text-slate-400">ETA</p><p className="font-medium text-slate-700">{v.eta}</p></div>
                <div><p className="text-slate-400">Risk</p><p className="font-medium text-slate-700">{v.risk}/100</p></div>
              </div>
              {simVehicleId === v.id && <p className="text-xs text-teal-700 font-medium mt-2 flex items-center gap-1"><Loader2 size={12} className="animate-spin" /> Simulating live movement…</p>}
            </button>
          ))}
        </div>
      )}
      <p className="text-xs text-slate-400 mt-4">Showing {filtered.length} of 243 tracked vehicles region-wide (prototype sample).</p>
    </div>
  );
}

/* ============================================================
   SHIPMENTS
============================================================ */
function ShipmentsPage({ shipments, onOpen }) {
  const { t } = useT();
  const [filter, setFilter] = useState("ALL");
  const statuses = ["ALL", "ON TIME", "DELAYED", "AT RISK", "CRITICAL", "DELIVERED", "PROTECTED / ON TRACK"];
  const filtered = filter === "ALL" ? shipments : shipments.filter((s) => s.status === filter);
  return (
    <div>
      <SectionHeader title={t("shipmentsTitle")} sub={t("shipmentsSub")} right={<UpdatedTag />} />
      <div className="flex gap-1.5 flex-wrap mb-4">
        {statuses.map((s) => (
          <button key={s} onClick={() => setFilter(s)} className={`text-xs font-medium px-3 py-1.5 rounded-full border ${filter === s ? "bg-teal-700 text-white border-teal-700" : "bg-white text-slate-500 border-stone-200"}`}>{s === "ALL" ? t("allLabel") : t(STATUS_KEY[s] || s)}</button>
        ))}
      </div>
      {filtered.length === 0 ? <EmptyState icon={Package} title={t("noShipmentsView")} /> : (
        <div className="grid md:grid-cols-2 gap-3">
          {filtered.map((s) => (
            <button key={s.id} onClick={() => onOpen(s)} className={`${cardCls} p-4 text-left hover:shadow-md transition-shadow`}>
              <div className="flex items-start justify-between mb-2">
                <div><p className="font-semibold nr-mono text-slate-900">{s.id}</p><p className="text-xs text-slate-400">{s.cargo}</p></div>
                <Badge tone={s.priority === "CRITICAL" ? "darkred" : "slate"}>{s.priority}</Badge>
              </div>
              <p className="text-sm text-slate-600 mb-2">{s.route} · via {s.vehicle}</p>
              {typeof s.criticality === "number" && (
                <p className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                  {criticalityTier(s.criticality).icon} Criticality {s.criticality}/100 — <span className="font-medium">{criticalityTier(s.criticality).label}</span>
                </p>
              )}
              <div className="flex items-center justify-between border-t border-stone-100 pt-2.5">
                <StatusBadge status={s.status} />
                <span className="text-xs text-slate-500">ETA {s.eta}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   ALERTS + NOTIFICATIONS
============================================================ */
function AlertsPage({ alerts, onOpen }) {
  const { t } = useT();
  const groups = { critical: alerts.filter((a) => a.level === "critical"), warning: alerts.filter((a) => a.level === "warning"), info: alerts.filter((a) => a.level === "info") };
  const labels = { critical: "Critical", warning: "Warning", info: "Information" };
  const icons = { critical: "🔴", warning: "🟠", info: "🔵" };
  return (
    <div>
      <SectionHeader title={t("alertsTitle")} sub={t("alertsSub")} />
      {alerts.length === 0 && <EmptyState icon={CheckCircle2} title={t("allCaughtUp")} />}
      {["critical", "warning", "info"].map((lvl) => groups[lvl].length > 0 && (
        <div key={lvl} className="mb-5">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">{icons[lvl]} {labels[lvl]}</p>
          <div className={`${cardCls} divide-y divide-stone-100`}>
            {groups[lvl].map((a) => (
              <button key={a.id} onClick={() => onOpen(a)} className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-stone-50">
                <div><p className="text-sm font-medium text-slate-800">{a.title}</p><p className="text-xs text-slate-400">{a.detail}</p></div>
                <div className="flex items-center gap-2 shrink-0"><span className="text-xs text-slate-400">{a.time}</span><ChevronRight size={15} className="text-slate-300" /></div>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function NotifPanel({ open, onClose, notifs, onMarkRead, onMarkAllRead, onOpenLink }) {
  const { t } = useT();
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40">
      <div className="absolute inset-0 bg-slate-900 opacity-30" onClick={onClose} />
      <div className="absolute right-0 top-0 md:top-16 md:right-6 bg-white w-full md:w-96 h-full md:h-auto md:max-h-96 md:rounded-2xl shadow-xl border border-stone-200 overflow-y-auto nr-scroll">
        <div className="flex items-center justify-between px-4 py-3 border-b border-stone-200 sticky top-0 bg-white">
          <p className="font-semibold text-slate-800">{t("notificationsTitle")}</p>
          <div className="flex items-center gap-2">
            <button onClick={onMarkAllRead} className="text-xs text-teal-700 font-medium hover:underline">{t("markAllRead")}</button>
            <button onClick={onClose} className="p-1 rounded-lg hover:bg-stone-100"><X size={16} /></button>
          </div>
        </div>
        {notifs.length === 0 ? <EmptyState icon={Bell} title={t("noNotifications")} /> : (
          <div className="divide-y divide-stone-100">
            {notifs.map((n) => (
              <button key={n.id} onClick={() => { onMarkRead(n.id); onOpenLink(n.link); }} className={`w-full flex items-start gap-2.5 px-4 py-3 text-left hover:bg-stone-50 ${!n.read ? "bg-teal-50" : ""}`}>
                {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0" />}
                <div className={!n.read ? "" : "pl-4"}>
                  <p className="text-sm font-medium text-slate-800">{n.title}</p>
                  <p className="text-xs text-slate-400">{n.detail}</p>
                  <p className="text-xs text-slate-300 mt-0.5">{n.time}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   SOS CENTER
============================================================ */
const SOS_STAGES = ["Activated", "Acknowledged", "Response Assigned", "Dispatched", "Resolved"];
function SOSCenter({ sosList, onOpen, role }) {
  const { t } = useT();
  const active = sosList.filter((s) => s.status !== "RESOLVED");
  const resolved = sosList.filter((s) => s.status === "RESOLVED");
  return (
    <div>
      <SectionHeader title={t("sosCenterTitle")} sub={t("sosCenterSub")} right={<UpdatedTag />} />
      {active.length === 0 ? <EmptyState icon={Shield} title={t("noActiveEmergencies")} sub={t("allCaughtUp")} /> : (
        <div className="grid md:grid-cols-2 gap-3 mb-6">
          {active.map((s) => (
            <button key={s.id} onClick={() => onOpen(s)} className={`${cardCls} p-4 text-left hover:shadow-md transition-shadow border-l-4 border-l-red-500`}>
              <div className="flex items-start justify-between mb-1.5">
                <div><p className="font-semibold nr-mono text-slate-900">{s.id}</p><p className="text-xs text-slate-400">{s.type}</p></div>
                <StatusBadge status={s.status} />
              </div>
              <p className="text-sm text-slate-600 mb-2">{s.location} · {s.vehicle}</p>
              <div className="flex flex-wrap gap-1">
                {SOS_STAGES.map((st) => (
                  <span key={st} className={`text-xs px-2 py-0.5 rounded-full border ${s.timeline.includes(st) ? "bg-teal-50 text-teal-700 border-teal-200" : "bg-stone-50 text-stone-300 border-stone-100"}`}>{st}</span>
                ))}
              </div>
            </button>
          ))}
        </div>
      )}
      {resolved.length > 0 && (
        <>
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Resolved</p>
          <div className={`${cardCls} divide-y divide-stone-100`}>
            {resolved.map((s) => (
              <button key={s.id} onClick={() => onOpen(s)} className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-stone-50">
                <div><p className="text-sm font-medium nr-mono text-slate-700">{s.id}</p><p className="text-xs text-slate-400">{s.type} · {s.location}</p></div>
                <StatusBadge status={s.status} />
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function SOSDetailBody({ sos, onAdvance, role }) {
  const { t } = useT();
  const idx = SOS_STAGES.findIndex((s) => s === (sos.timeline[sos.timeline.length - 1]));
  const nextStage = SOS_STAGES[idx + 1];
  const actionLabels = { Acknowledged: t("acknowledge"), "Response Assigned": t("assignResponse"), Dispatched: t("markDispatched"), Resolved: t("resolve") };
  return (
    <div className="space-y-4">
      <div>
        <p className="text-xs text-slate-400 mb-2">Response Timeline</p>
        <div className="space-y-2">
          {SOS_STAGES.map((st, i) => {
            const done = sos.timeline.includes(st);
            return (
              <div key={st} className="flex items-center gap-2.5">
                <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${done ? "bg-teal-600 text-white" : "bg-stone-100 text-stone-300"}`}>
                  {done ? <Check size={12} /> : <span className="text-xs">{i + 1}</span>}
                </div>
                <span className={`text-sm ${done ? "text-slate-800 font-medium" : "text-slate-400"}`}>{st}</span>
              </div>
            );
          })}
        </div>
      </div>
      {role !== "driver" && sos.status !== "RESOLVED" && nextStage && (
        <PrimaryBtn className="w-full" onClick={() => onAdvance(sos.id, nextStage)} icon={nextStage === "Resolved" ? CheckCircle2 : ArrowRight}>
          {actionLabels[nextStage]}
        </PrimaryBtn>
      )}
      {role !== "driver" && sos.status !== "RESOLVED" && (
        <SecondaryBtn className="w-full" icon={TriangleAlert}>{t("escalate")}</SecondaryBtn>
      )}
    </div>
  );
}

/* ============================================================
   FIELD REPORTS
============================================================ */
const VERIFY_TONE = { PENDING: "amber", VERIFIED: "teal", "HIGH CONFIDENCE": "emerald", RESOLVED: "slate" };
function GroundTruthNetworkPage({ incidents, pendingSyncCount, online, onSubmit, onUseForRouteRisk, activeRouteRisk }) {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  return (
    <div>
      <SectionHeader title={t("groundTruthTitle")} sub={t("groundTruthSub")} right={<PrimaryBtn icon={CameraIcon} onClick={() => setOpen(true)}>{t("newReport")}</PrimaryBtn>} />
      {!online && (
        <div className="bg-amber-50 border border-amber-200 text-amber-700 rounded-lg p-3 text-sm mb-4 flex items-center gap-2">
          <WifiOff size={16} /> Offline Mode — new reports will be saved locally and marked PENDING SYNC.
        </div>
      )}
      {pendingSyncCount > 0 && (
        <div className="bg-slate-50 border border-slate-200 text-slate-600 rounded-lg p-3 text-sm mb-4 flex items-center gap-2">
          <RefreshCw size={14} /> {pendingSyncCount} report{pendingSyncCount > 1 ? "s" : ""} pending synchronization.
        </div>
      )}
      {incidents.length === 0 ? <EmptyState icon={FileText} title={t("noFieldReports")} sub="Submit a report when you spot a hazard on the road." /> : (
        <div className="space-y-2.5">
          {incidents.map((r) => {
            const canUse = ["Landslide", "Flood", "Road Damage", "Bridge Damage"].includes(r.type) && r.severity === "HIGH" && !r.usedForRisk;
            return (
              <div key={r.id} className={`${cardCls} p-4`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <p className="font-semibold text-slate-900 uppercase text-sm">{r.type} REPORTED</p>
                      <Badge tone={r.severity === "HIGH" ? "red" : r.severity === "MODERATE" ? "amber" : "slate"}>{r.severity}</Badge>
                      <Badge tone={VERIFY_TONE[r.verification] || "slate"}>{r.verification || "PENDING"}</Badge>
                      {r.photo && <Badge tone="slate"><CameraIcon size={11} /> Photo</Badge>}
                    </div>
                    <p className="text-sm text-slate-600">{r.desc}</p>
                    <p className="text-xs text-slate-400 mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-0.5">
                      <span className="flex items-center gap-1"><MapPin size={11} /> {r.location}</span>
                      <span className="flex items-center gap-1"><Clock size={11} /> {r.time}</span>
                      <span>Reported by {r.reportedBy}</span>
                    </p>
                  </div>
                  <Badge tone={r.sync === "PENDING" ? "amber" : "emerald"}>{r.sync === "PENDING" ? "PENDING SYNC" : "SYNCED"}</Badge>
                </div>
                {(canUse || r.usedForRisk) && (
                  <div className="border-t border-stone-100 mt-3 pt-3">
                    {r.usedForRisk ? (
                      <p className="text-xs text-teal-700 font-medium flex items-center gap-1.5"><CheckCircle2 size={13} /> Used for route risk — route updated to {activeRouteRisk}/100.</p>
                    ) : (
                      <SecondaryBtn onClick={() => onUseForRouteRisk(r)} icon={TriangleAlert}>{t("useForRouteRisk")}</SecondaryBtn>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      <NewReportModal open={open} onClose={() => setOpen(false)} online={online} onSubmit={(rep) => { onSubmit(rep); setOpen(false); }} />
    </div>
  );
}

function NewReportModal({ open, onClose, online, onSubmit }) {
  const { t } = useT();
  const [type, setType] = useState("Landslide");
  const [desc, setDesc] = useState("");
  const [severity, setSeverity] = useState("MODERATE");
  const [photo, setPhoto] = useState(false);
  if (!open) return null;
  return (
    <Modal open={open} onClose={onClose} wide>
      <div className="p-6">
        <h3 className="text-lg font-semibold text-slate-900 nr-font mb-4">{t("fieldReportTitle")}</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-slate-500">Incident Type</label>
            <select value={type} onChange={(e) => setType(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
              {INCIDENT_TYPES.map((it) => <option key={it}>{it}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-500">Severity</label>
            <select value={severity} onChange={(e) => setSeverity(e.target.value)} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
              <option>LOW</option><option>MODERATE</option><option>HIGH</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="text-xs text-slate-500">Description</label>
            <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} placeholder="Describe what you observed…" className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm resize-none" />
          </div>
          <div>
            <label className="text-xs text-slate-500">GPS Location</label>
            <div className="mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm nr-mono text-slate-500 bg-stone-50 flex items-center gap-1.5"><MapPin size={13} /> 25.58° N, 91.89° E (auto-captured)</div>
          </div>
          <div>
            <label className="text-xs text-slate-500">Photo</label>
            <button onClick={() => setPhoto(true)} className={`mt-1 w-full border border-dashed rounded-lg px-2.5 py-2 text-sm flex items-center gap-1.5 justify-center ${photo ? "border-teal-300 text-teal-700 bg-teal-50" : "border-stone-300 text-slate-400"}`}>
              <CameraIcon size={14} /> {photo ? "Photo attached" : "Attach photo"}
            </button>
          </div>
        </div>
        {!online && <p className="text-xs text-amber-600 mt-3 flex items-center gap-1"><WifiOff size={12} /> You're offline — this report will sync automatically once connection is restored.</p>}
        <div className="flex justify-end gap-2 mt-6">
          <SecondaryBtn onClick={onClose}>{t("cancel")}</SecondaryBtn>
          <PrimaryBtn disabled={!desc.trim()} onClick={() => onSubmit({ type, description: desc || "No additional details provided.", severity, location: "Field-reported location", sync: online ? "SYNCED" : "PENDING", photo })}>{t("submitReport")}</PrimaryBtn>
        </div>
      </div>
    </Modal>
  );
}

/* ============================================================
   WEATHER & RISK
============================================================ */
function WeatherRiskPage({ onViewImpact }) {
  const { t } = useT();
  const items = [
    { icon: CloudRain, title: "Heavy Rain", detail: "4.2 km ahead on Guwahati → Aizawl corridor", risk: "high" },
    { icon: Droplets, title: "Flood Risk", detail: "Rising water near Silchar bridge approach", risk: "moderate" },
    { icon: Mountain, title: "Landslide Risk", detail: "Loose debris reported near Kohima Pass", risk: "high" },
    { icon: CircleDot, title: "Road Condition", detail: "Fair to poor across 3 monitored corridors", risk: "moderate" },
  ];
  return (
    <div>
      <SectionHeader title={t("weatherRiskTitle")} sub={t("weatherRiskSub")} />
      <div className="grid md:grid-cols-2 gap-3">
        {items.map((it, i) => (
          <div key={i} className={`${cardCls} p-4 flex items-start gap-3`}>
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${RISK_TIERS[it.risk].bg}`}><it.icon size={18} className={RISK_TIERS[it.risk].text} /></div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-slate-800">{it.title}</p>
                <TierBadge tier={it.risk} />
              </div>
              <p className="text-sm text-slate-500 mt-0.5">{it.detail}</p>
              <GhostBtn className="mt-1 -ml-3" onClick={onViewImpact}>View impact on map <ChevronRight size={13} /></GhostBtn>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-400"><Sparkles size={12} /> AI-assisted risk estimate based on simulated sensor and field-report data.</div>
    </div>
  );
}

/* ============================================================
   AI LOGISTICS COPILOT
============================================================ */
const SUGGESTED_QUESTIONS = [
  "What is happening right now?",
  "Which districts are at highest risk?",
  "Which shipments are delayed?",
  "Which medical shipments are at risk?",
  "What happened with the latest SOS?",
  "Which route is safest?",
  "What if this road is blocked?",
  "Which vehicles are affected?",
  "Show the biggest bottlenecks.",
];

function buildCopilotResponse(question, ctx) {
  const q = question.toLowerCase();
  if (q.includes("happening right now")) {
    return { title: "Current Situation", lines: [
      `${ctx.kpis.accessible} corridors accessible, ${ctx.kpis.atRisk} at risk, ${ctx.kpis.blocked} blocked.`,
      `${ctx.kpis.activeVehicles} vehicles in transit, ${ctx.kpis.criticalShipments} critical shipments moving.`,
      `${ctx.kpis.activeSOS} active SOS case${ctx.kpis.activeSOS === 1 ? "" : "s"} across the network.`,
    ]};
  }
  if (q.includes("highest risk")) {
    const top = [...MAP_ROUTES_BASE].sort((a, b) => b.risk - a.risk).slice(0, 3);
    return { title: "Highest-Risk Corridors", rows: top.map((r) => ({ label: `${CITIES[r.from].name} → ${CITIES[r.to].name}`, value: `${r.risk}/100`, tier: riskTier(r.risk) })) };
  }
  if (q.includes("delayed")) {
    const rows = ctx.shipments.filter((s) => s.status === "DELAYED").map((s) => ({ label: `${s.id} · ${s.cargo}`, value: s.eta, tier: "moderate" }));
    return { title: "Delayed Shipments", rows: rows.length ? rows : [{ label: "No delayed shipments right now", value: "" }] };
  }
  if (q.includes("medical shipments")) {
    const rows = ctx.shipments.filter((s) => s.cargo === "Medical Supplies" && (s.status === "AT RISK" || s.status === "CRITICAL")).map((s) => ({ label: `${s.id} · ${s.route}`, value: s.status, tier: "high" }));
    return { title: "Medical Shipments At Risk", rows: rows.length ? rows : [{ label: "No medical shipments currently at risk", value: "" }] };
  }
  if (q.includes("latest sos")) {
    const s = ctx.sosList[ctx.sosList.length - 1];
    return { title: `Latest SOS — ${s.id}`, sos: s };
  }
  if (q.includes("safest")) {
    const best = [...ctx.routeOptions].sort((a, b) => a.risk - b.risk)[0];
    return { title: "Safest Route", lines: [`${best.name} (${best.via}) has the lowest current risk score at ${best.risk}/100.`, `Recommended for critical and time-sensitive cargo.`] };
  }
  if (q.includes("what if") || q.includes("blocked")) {
    return { title: "What-If: Road Blocked", whatIf: true };
  }
  if (q.includes("vehicles are affected")) {
    const rows = ctx.vehicles.filter((v) => v.status === "AT RISK" || v.status === "DELAYED").map((v) => ({ label: `${v.id} · ${v.destination}`, value: v.status, tier: v.status === "AT RISK" ? "high" : "moderate" }));
    return { title: "Affected Vehicles", rows: rows.length ? rows : [{ label: "No vehicles currently affected", value: "" }] };
  }
  if (q.includes("bottleneck")) {
    const top = [...MAP_ROUTES_BASE].sort((a, b) => b.risk - a.risk).slice(0, 4);
    return { title: "Biggest Bottlenecks", rows: top.map((r) => ({ label: `${CITIES[r.from].name} → ${CITIES[r.to].name} (${r.label})`, value: `${r.risk}/100`, tier: riskTier(r.risk) })) };
  }
  return { title: "Here's what I found", lines: ["I can help with routes, vehicles, shipments, weather risk and SOS status. Try one of the suggested questions, or ask about a specific vehicle or district."] };
}

function CopilotPanel({ open, onClose, ctx, onDispatch, onViewMap, onReroute, mobile, messages, onAsk }) {
  const { t } = useT();
  const [input, setInput] = useState("");

  const ask = (question) => {
    onAsk(question);
    setInput("");
  };

  if (!open) return null;
  return (
    <div className={mobile ? "fixed inset-0 z-40" : "fixed inset-y-0 right-0 z-40 flex"}>
      {mobile && <div className="absolute inset-0 bg-slate-900 opacity-40" onClick={onClose} />}
      <div className={mobile ? "absolute bottom-0 inset-x-0 bg-white rounded-t-2xl h-4/5 flex flex-col" : "bg-white w-96 h-full border-l border-stone-200 shadow-xl flex flex-col"}>
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-stone-200">
          <div className="flex items-center gap-2"><MessageSquare size={17} className="text-teal-700" /><p className="font-semibold text-slate-800 text-sm">{t("copilot")}</p></div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-stone-100"><X size={17} /></button>
        </div>
        <div className="flex-1 overflow-y-auto nr-scroll p-4 space-y-3">
          {messages.map((m, i) => m.from === "user" ? (
            <div key={i} className="flex justify-end"><div className="bg-teal-700 text-white text-sm px-3 py-2 rounded-lg rounded-br-sm max-w-xs">{m.text}</div></div>
          ) : (
            <div key={i} className="bg-stone-50 border border-stone-200 rounded-lg p-3 text-sm">
              <p className="font-semibold text-slate-800 mb-1.5">{m.title}</p>
              {m.lines && m.lines.map((l, j) => <p key={j} className="text-slate-600 text-xs mb-1">{l}</p>)}
              {m.rows && (
                <div className="space-y-1 mt-1">
                  {m.rows.map((r, j) => (
                    <div key={j} className="flex items-center justify-between text-xs">
                      <span className="text-slate-600">{r.label}</span>
                      {r.tier ? <TierBadge tier={r.tier} /> : <span className="text-slate-400">{r.value}</span>}
                    </div>
                  ))}
                </div>
              )}
              {m.sos && (
                <div className="space-y-1.5 mt-1">
                  <div className="grid grid-cols-2 gap-1 text-xs">
                    <span className="text-slate-400">Type</span><span className="text-right font-medium">{m.sos.type}</span>
                    <span className="text-slate-400">Vehicle</span><span className="text-right font-medium nr-mono">{m.sos.vehicle}</span>
                    <span className="text-slate-400">Risk</span><span className="text-right font-medium">{m.sos.risk}/100</span>
                    <span className="text-slate-400">Weather</span><span className="text-right font-medium">{m.sos.weather}</span>
                    <span className="text-slate-400">Nearest Team</span><span className="text-right font-medium">6.4 km</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-600 mt-2">Recommended Actions</p>
                  <ol className="text-xs text-slate-500 list-decimal list-inside space-y-0.5">
                    <li>Dispatch nearest response team.</li><li>Mark corridor high risk.</li><li>Review affected medical shipment.</li>
                  </ol>
                  <div className="flex flex-col gap-1.5 mt-2">
                    <PrimaryBtn onClick={() => onDispatch(m.sos.id)}>{t("dispatchTeam")}</PrimaryBtn>
                    <SecondaryBtn onClick={onViewMap}>{t("viewOnMap")}</SecondaryBtn>
                    <SecondaryBtn onClick={onReroute}>{t("reroute")} Vehicles</SecondaryBtn>
                  </div>
                </div>
              )}
              {m.whatIf && (
                <div className="space-y-1.5 mt-1">
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-white rounded-lg border border-stone-200 p-2"><p className="text-lg font-bold nr-mono text-slate-800">27</p><p className="text-xs text-slate-400">vehicles affected</p></div>
                    <div className="bg-white rounded-lg border border-stone-200 p-2"><p className="text-lg font-bold nr-mono text-slate-800">14</p><p className="text-xs text-slate-400">shipments delayed</p></div>
                    <div className="bg-white rounded-lg border border-stone-200 p-2"><p className="text-lg font-bold nr-mono text-slate-800">3</p><p className="text-xs text-slate-400">critical medical</p></div>
                  </div>
                  <p className="text-xs text-slate-500">Estimated delay: <span className="font-semibold text-slate-700">4.2 hours</span></p>
                  <p className="text-xs text-slate-500">AI recommendation: reroute critical medical shipments via Route C immediately; hold standard cargo until the corridor clears.</p>
                  <SecondaryBtn className="mt-1" onClick={onViewMap}>{t("viewOnMap")}</SecondaryBtn>
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="p-3 border-t border-stone-200">
          <div className="flex flex-wrap gap-1.5 mb-2">
            {SUGGESTED_QUESTIONS.slice(0, 4).map((q) => (
              <button key={q} onClick={() => ask(q)} className="text-xs px-2.5 py-1.5 rounded-full border border-stone-200 text-slate-600 hover:bg-stone-50">{q}</button>
            ))}
          </div>
          <div className="flex items-center gap-2 bg-stone-100 rounded-lg px-3 py-2">
            <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && input.trim() && ask(input.trim())} placeholder="Ask the copilot…" className="bg-transparent text-sm outline-none flex-1" />
            <button onClick={() => input.trim() && ask(input.trim())} className="text-teal-700"><Send size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   VOICE ASSISTANT (simulated)
============================================================ */
const LOCALE_MAP = { en: "en-IN", hi: "hi-IN", bn: "bn-IN", pa: "pa-IN", as: "as-IN" };
const VOICE_COMMANDS_I18N = {
  en: [
    { q: "How far is my destination?", a: "Aizawl is 214 kilometers away. Estimated arrival 12:45 PM." },
    { q: "Is the road safe?", a: "Current route risk is 27 out of 100 — safe to proceed. Light rain expected ahead." },
    { q: "What's the weather ahead?", a: "Heavy rainfall expected 4.2 kilometers ahead. Please reduce speed near the crossing." },
    { q: "Find a safer route.", a: "Route C via Shillong Bypass has a lower risk score. Would you like to switch?" },
    { q: "Switch route.", a: "Switching to Route C. Updated ETA is 13 hours 30 minutes." },
    { q: "Repeat.", a: "Repeating last instruction: continue straight for 2.4 kilometers, then turn right." },
    { q: "Stop navigation.", a: "Navigation stopped. Tap the map to resume anytime." },
    { q: "Report an incident.", a: "Opening the field report form so you can log what you're seeing." },
    { q: "Call for help.", a: "For a real emergency, press and hold the SOS button for 2 seconds." },
  ],
  hi: [
    { q: "मेरा गंतव्य कितनी दूर है?", a: "आइज़ोल 214 किलोमीटर दूर है। अनुमानित आगमन दोपहर 12:45 बजे।" },
    { q: "क्या सड़क सुरक्षित है?", a: "वर्तमान रूट जोखिम 100 में से 27 है — आगे बढ़ना सुरक्षित है। आगे हल्की बारिश की संभावना है।" },
    { q: "आगे मौसम कैसा है?", a: "4.2 किलोमीटर आगे भारी बारिश की सूचना है। क्रॉसिंग के पास गति कम करें।" },
    { q: "एक सुरक्षित रूट खोजें।", a: "शिलॉन्ग बायपास वाले रूट C का जोखिम स्कोर कम है। क्या आप बदलना चाहेंगे?" },
    { q: "रूट बदलें।", a: "रूट C पर स्विच किया जा रहा है। अद्यतन अनुमानित समय 13 घंटे 30 मिनट है।" },
    { q: "दोहराएं।", a: "अंतिम निर्देश दोहरा रहे हैं: 2.4 किलोमीटर सीधे चलें, फिर दाएं मुड़ें।" },
    { q: "नेविगेशन रोकें।", a: "नेविगेशन रोक दिया गया है। फिर से शुरू करने के लिए मैप पर टैप करें।" },
    { q: "एक घटना रिपोर्ट करें।", a: "फील्ड रिपोर्ट फॉर्म खोला जा रहा है ताकि आप जो देख रहे हैं उसे दर्ज कर सकें।" },
    { q: "मदद के लिए कॉल करें।", a: "वास्तविक आपातकाल के लिए, SOS बटन को 2 सेकंड तक दबाए रखें।" },
  ],
  bn: [
    { q: "আমার গন্তব্য কত দূরে?", a: "আইজল ২১৪ কিলোমিটার দূরে। আনুমানিক পৌঁছানোর সময় দুপুর ১২:৪৫।" },
    { q: "রাস্তা কি নিরাপদ?", a: "বর্তমান রুট ঝুঁকি ১০০ এর মধ্যে ২৭ — এগিয়ে যাওয়া নিরাপদ। সামনে হালকা বৃষ্টির সম্ভাবনা।" },
    { q: "সামনে আবহাওয়া কেমন?", a: "৪.২ কিলোমিটার সামনে ভারী বৃষ্টির সম্ভাবনা। ক্রসিংয়ের কাছে গতি কমান।" },
    { q: "একটি নিরাপদ রুট খুঁজুন।", a: "শিলং বাইপাস হয়ে রুট C-এর ঝুঁকি স্কোর কম। আপনি কি পরিবর্তন করতে চান?" },
    { q: "রুট পরিবর্তন করুন।", a: "রুট C-তে পরিবর্তন করা হচ্ছে। নতুন প্রত্যাশিত সময় ১৩ ঘণ্টা ৩০ মিনিট।" },
    { q: "পুনরাবৃত্তি করুন।", a: "শেষ নির্দেশ পুনরাবৃত্তি করা হচ্ছে: ২.৪ কিলোমিটার সোজা যান, তারপর ডানে ঘুরুন।" },
    { q: "নেভিগেশন বন্ধ করুন।", a: "নেভিগেশন বন্ধ হয়েছে। আবার শুরু করতে মানচিত্রে ট্যাপ করুন।" },
    { q: "একটি ঘটনা রিপোর্ট করুন।", a: "ফিল্ড রিপোর্ট ফর্ম খোলা হচ্ছে যাতে আপনি যা দেখছেন তা লিপিবদ্ধ করতে পারেন।" },
    { q: "সাহায্যের জন্য কল করুন।", a: "প্রকৃত জরুরি অবস্থার জন্য, SOS বোতাম ২ সেকেন্ড ধরে চেপে রাখুন।" },
  ],
  pa: [
    { q: "ਮੇਰੀ ਮੰਜ਼ਿਲ ਕਿੰਨੀ ਦੂਰ ਹੈ?", a: "ਆਈਜ਼ੌਲ 214 ਕਿਲੋਮੀਟਰ ਦੂਰ ਹੈ। ਅਨੁਮਾਨਿਤ ਪਹੁੰਚ ਦੁਪਹਿਰ 12:45 ਵਜੇ।" },
    { q: "ਕੀ ਸੜਕ ਸੁਰੱਖਿਅਤ ਹੈ?", a: "ਮੌਜੂਦਾ ਰੂਟ ਖ਼ਤਰਾ 100 ਵਿੱਚੋਂ 27 ਹੈ — ਅੱਗੇ ਵਧਣਾ ਸੁਰੱਖਿਅਤ ਹੈ। ਅੱਗੇ ਹਲਕੀ ਬਾਰਿਸ਼ ਦੀ ਸੰਭਾਵਨਾ ਹੈ।" },
    { q: "ਅੱਗੇ ਮੌਸਮ ਕਿਹੋ ਜਿਹਾ ਹੈ?", a: "4.2 ਕਿਲੋਮੀਟਰ ਅੱਗੇ ਭਾਰੀ ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ ਹੈ। ਕਰਾਸਿੰਗ ਨੇੜੇ ਰਫ਼ਤਾਰ ਘਟਾਓ।" },
    { q: "ਇੱਕ ਸੁਰੱਖਿਅਤ ਰੂਟ ਲੱਭੋ।", a: "ਸ਼ਿਲਾਂਗ ਬਾਈਪਾਸ ਰਾਹੀਂ ਰੂਟ C ਦਾ ਖ਼ਤਰਾ ਸਕੋਰ ਘੱਟ ਹੈ। ਕੀ ਤੁਸੀਂ ਬਦਲਣਾ ਚਾਹੋਗੇ?" },
    { q: "ਰੂਟ ਬਦਲੋ।", a: "ਰੂਟ C 'ਤੇ ਬਦਲਿਆ ਜਾ ਰਿਹਾ ਹੈ। ਅੱਪਡੇਟ ਕੀਤਾ ਅਨੁਮਾਨਿਤ ਸਮਾਂ 13 ਘੰਟੇ 30 ਮਿੰਟ ਹੈ।" },
    { q: "ਦੁਹਰਾਓ।", a: "ਆਖਰੀ ਹਦਾਇਤ ਦੁਹਰਾ ਰਹੇ ਹਾਂ: 2.4 ਕਿਲੋਮੀਟਰ ਸਿੱਧਾ ਜਾਓ, ਫਿਰ ਸੱਜੇ ਮੁੜੋ।" },
    { q: "ਨੈਵੀਗੇਸ਼ਨ ਰੋਕੋ।", a: "ਨੈਵੀਗੇਸ਼ਨ ਰੋਕ ਦਿੱਤੀ ਗਈ ਹੈ। ਦੁਬਾਰਾ ਸ਼ੁਰੂ ਕਰਨ ਲਈ ਨਕਸ਼ੇ 'ਤੇ ਟੈਪ ਕਰੋ।" },
    { q: "ਇੱਕ ਘਟਨਾ ਦੀ ਰਿਪੋਰਟ ਕਰੋ।", a: "ਫੀਲਡ ਰਿਪੋਰਟ ਫਾਰਮ ਖੋਲ੍ਹਿਆ ਜਾ ਰਿਹਾ ਹੈ ਤਾਂ ਜੋ ਤੁਸੀਂ ਜੋ ਵੇਖ ਰਹੇ ਹੋ ਉਸਨੂੰ ਦਰਜ ਕਰ ਸਕੋ।" },
    { q: "ਮਦਦ ਲਈ ਕਾਲ ਕਰੋ।", a: "ਅਸਲ ਐਮਰਜੈਂਸੀ ਲਈ, SOS ਬਟਨ ਨੂੰ 2 ਸਕਿੰਟ ਲਈ ਦਬਾਈ ਰੱਖੋ।" },
  ],
  as: [
    { q: "মোৰ গন্তব্য কিমান দূৰত?", a: "আইজল 214 কিলোমিটাৰ দূৰত। আনুমানিক পৌঁহাৰ সময় দুপৰীয়া 12:45 বজা।" },
    { q: "পথছোৱা সুৰক্ষিত নেকি?", a: "বৰ্তমান ৰুট বিপদ 100ৰ ভিতৰত 27 — আগবাঢ়িব পাৰি। আগত সামান্য বৰষুণৰ সম্ভাৱনা।" },
    { q: "আগৰ বতৰ কেনেকুৱা?", a: "4.2 কিলোমিটাৰ আগত প্ৰবল বৰষুণৰ সম্ভাৱনা। ক্ৰছিংৰ ওচৰত গতি কমাওক।" },
    { q: "এটা সুৰক্ষিত ৰুট বিচাৰক।", a: "শ্বিলং বাইপাছৰ জৰিয়তে ৰুট Cৰ বিপদ স্ক'ৰ কম। আপুনি সলনি কৰিব বিচাৰেনে?" },
    { q: "ৰুট সলনি কৰক।", a: "ৰুট Cলৈ সলনি কৰা হৈছে। আপডেট কৰা আনুমানিক সময় 13 ঘণ্টা 30 মিনিট।" },
    { q: "পুনৰাবৃত্তি কৰক।", a: "শেষ নিৰ্দেশ পুনৰাবৃত্তি কৰি আছোঁ: 2.4 কিলোমিটাৰ পোনে যাওক, তাৰপিছত সোঁফালে মুৰ কৰক।" },
    { q: "নেভিগেচন বন্ধ কৰক।", a: "নেভিগেচন বন্ধ কৰা হৈছে। পুনৰ আৰম্ভ কৰিবলৈ মেপত টেপ কৰক।" },
    { q: "এটা ঘটনা প্ৰতিবেদন কৰক।", a: "ফীল্ড ৰিপৰ্ট ফৰ্ম খোলা হৈছে যাতে আপুনি যি দেখি আছে তাক লিপিবদ্ধ কৰিব পাৰে।" },
    { q: "সহায়ৰ বাবে কল কৰক।", a: "প্ৰকৃত জৰুৰীকালীন অৱস্থাৰ বাবে, SOS বুটামটো 2 ছেকেণ্ড হেঁচি ৰাখক।" },
  ],
};
function speak(text, lang) {
  try {
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1; u.lang = LOCALE_MAP[lang] || "en-IN";
      window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
    }
  } catch (e) { /* speech synthesis unavailable — safe to ignore */ }
}

function VoiceAssistantModal({ open, onClose, voiceEnabled }) {
  const { t, lang } = useT();
  const [phase, setPhase] = useState("idle"); // idle, listening, processing, response
  const [current, setCurrent] = useState(null);
  useEffect(() => { if (open) { setPhase("idle"); setCurrent(null); } }, [open]);
  const commands = VOICE_COMMANDS_I18N[lang] || VOICE_COMMANDS_I18N.en;

  const trigger = (cmd) => {
    setPhase("listening");
    setTimeout(() => {
      setPhase("processing");
      setTimeout(() => {
        setCurrent(cmd);
        setPhase("response");
        speak(cmd.a, lang);
      }, 900);
    }, 700);
  };

  if (!open) return null;
  return (
    <Modal open={open} onClose={onClose}>
      <div className="p-6 text-center">
        <p className="text-xs font-semibold tracking-wide text-teal-700 uppercase nr-mono mb-1">NE-RAAH Voice Assistant</p>
        {!voiceEnabled && <p className="text-xs text-amber-600 mb-2">Voice assistant is turned off in Settings — you can still preview it here.</p>}
        <div className="my-5 flex flex-col items-center">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${phase === "listening" ? "bg-teal-100" : phase === "processing" ? "bg-amber-100" : "bg-stone-100"}`}>
            {phase === "processing" ? <Loader2 size={30} className="text-amber-600 animate-spin" /> : <Mic size={30} className={phase === "listening" ? "text-teal-700" : "text-slate-400"} />}
          </div>
          <p className="text-sm font-semibold text-slate-600 mt-3 nr-mono">
            {phase === "idle" && "TAP A COMMAND TO SIMULATE"}
            {phase === "listening" && "LISTENING…"}
            {phase === "processing" && "PROCESSING…"}
            {phase === "response" && "RESPONSE"}
          </p>
        </div>
        {phase === "response" && current && (
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-3 text-sm text-slate-700 text-left mb-4">
            <p className="text-xs text-slate-400 mb-1">"{current.q}"</p>
            <p className="font-medium">{current.a}</p>
          </div>
        )}
        <div className="grid grid-cols-1 gap-1.5 max-h-48 overflow-y-auto nr-scroll text-left">
          {commands.map((c) => (
            <button key={c.q} onClick={() => trigger(c)} disabled={phase === "listening" || phase === "processing"}
              className="text-sm px-3 py-2 rounded-lg border border-stone-200 hover:bg-stone-50 text-slate-600 disabled:opacity-40">
              "{c.q}"
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-4">Simulated voice interaction for this prototype — tap a phrase above in place of speaking.</p>
      </div>
    </Modal>
  );
}

function VoiceWarningBanner({ text, onDismiss }) {
  if (!text) return null;
  return (
    <div className="bg-amber-50 border border-amber-300 text-amber-800 rounded-lg p-3 text-sm flex items-start gap-2 mb-4">
      <Volume2 size={16} className="shrink-0 mt-0.5" />
      <div className="flex-1"><p className="font-semibold">Voice Warning</p><p>{text}</p></div>
      <button onClick={onDismiss} className="text-amber-500"><X size={15} /></button>
    </div>
  );
}

/* ============================================================
   PROFILE
============================================================ */
function EditProfileModal({ open, onClose, user, onSave }) {
  const { t } = useT();
  const [form, setForm] = useState(user);
  useEffect(() => { setForm(user); }, [user, open]);
  if (!open) return null;
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const handlePhoto = () => {
    const palette = ["#0f766e", "#b45309", "#334155", "#7c3aed", "#0369a1"];
    const c = palette[Math.floor(Math.random() * palette.length)];
    const svg = `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'><rect width='120' height='120' fill='${c}'/><text x='50%' y='58%' font-size='44' fill='white' text-anchor='middle' font-family='sans-serif'>${(form.name || "U").split(" ").map((n) => n[0]).slice(0, 2).join("")}</text></svg>`)}`;
    setForm((f) => ({ ...f, photo: svg }));
  };
  return (
    <Modal open={open} onClose={onClose} wide>
      <div className="p-6">
        <h3 className="text-lg font-semibold text-slate-900 nr-font mb-4">{t("editProfile")}</h3>
        <div className="flex items-center gap-4 mb-5">
          <div className="w-16 h-16 rounded-full bg-teal-700 text-white flex items-center justify-center text-xl font-bold overflow-hidden shrink-0">
            {form.photo ? <img src={form.photo} className="w-full h-full object-cover" alt="" /> : (form.name || "").split(" ").map((n) => n[0]).slice(0, 2).join("")}
          </div>
          <SecondaryBtn icon={CameraIcon} onClick={handlePhoto}>Change Photo</SecondaryBtn>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div><label className="text-xs text-slate-500">{t("fullName")}</label><input value={form.name} onChange={set("name")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm" /></div>
          <div><label className="text-xs text-slate-500">{t("phone")}</label><input value={form.phone} onChange={set("phone")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm" /></div>
          <div><label className="text-xs text-slate-500">{t("email")}</label><input value={form.email} onChange={set("email")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm" /></div>
          <div><label className="text-xs text-slate-500">{t("organization")}</label><input value={form.org} onChange={set("org")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm" /></div>
          <div>
            <label className="text-xs text-slate-500">{t("location")}</label>
            <select value={form.district} onChange={set("district")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
              {CITY_LIST.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-slate-500">{t("preferredLanguage")}</label>
            <select value={form.language} onChange={set("language")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm bg-white">
              {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
            </select>
          </div>
          <div><label className="text-xs text-slate-500">{t("emergencyContact")}</label><input value={form.emergencyContact} onChange={set("emergencyContact")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm" /></div>
          <div><label className="text-xs text-slate-500">{t("vehicleIdLabel")}</label><input value={form.vehicleId} onChange={set("vehicleId")} className="w-full mt-1 border border-stone-300 rounded-lg px-2.5 py-2 text-sm nr-mono" /></div>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <SecondaryBtn onClick={onClose}>{t("cancel")}</SecondaryBtn>
          <PrimaryBtn onClick={() => onSave(form)}>{t("saveChanges")}</PrimaryBtn>
        </div>
      </div>
    </Modal>
  );
}

/* Full Profile page — shows every detail in one place, per the profile tab */
function ProfilePage({ user, onEdit, onNavSettings, onLogout }) {
  const { t } = useT();
  const fields = [
    [t("fullName"), user.name], [t("role"), user.role], [t("organization"), user.org], [t("employeeId"), user.employeeId],
    [t("phone"), user.phone], [t("email"), user.email], [t("location"), user.district],
    [t("preferredLanguage"), LANGS.find((l) => l.code === user.language)?.label || "English"],
    [t("emergencyContact"), user.emergencyContact], [t("vehicleIdLabel"), user.vehicleId || "—"],
    [t("accountStatus"), user.accountStatus], [t("lastLogin"), user.lastLogin],
  ];
  const quickLinks = [
    { label: t("changeLanguage"), icon: Globe, onClick: onNavSettings },
    { label: t("notificationSettings"), icon: Bell, onClick: onNavSettings },
    { label: t("offlineData"), icon: WifiOff, onClick: onNavSettings },
    { label: t("security"), icon: Shield, onClick: onNavSettings },
    { label: t("logout"), icon: LogOut, onClick: onLogout, danger: true },
  ];
  return (
    <div>
      <SectionHeader title={t("myProfileTitle")} sub="Everything about your NE-RAAH account, in one place." right={<PrimaryBtn icon={Edit3} onClick={onEdit}>{t("editProfile")}</PrimaryBtn>} />
      <div className={`${cardCls} p-5 mb-4 flex items-center gap-4`}>
        <div className="w-20 h-20 rounded-full bg-teal-700 text-white flex items-center justify-center text-2xl font-bold overflow-hidden shrink-0">
          {user.photo ? <img src={user.photo} className="w-full h-full object-cover" alt="" /> : user.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}
        </div>
        <div>
          <h3 className="text-xl font-bold text-slate-900 nr-font">{user.name}</h3>
          <p className="text-sm text-slate-500">{user.role} · {user.org}</p>
          <div className="mt-1.5"><Badge tone="emerald">{user.accountStatus}</Badge></div>
        </div>
      </div>
      <div className={`${cardCls} p-5 mb-4`}>
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3">{t("accountDetails")}</p>
        <div className="grid sm:grid-cols-2 gap-x-6 gap-y-4">
          {fields.map(([label, value]) => (
            <div key={label}><p className="text-xs text-slate-400">{label}</p><p className="text-sm font-medium text-slate-800 mt-0.5">{value}</p></div>
          ))}
        </div>
      </div>
      <div className={`${cardCls} divide-y divide-stone-100`}>
        {quickLinks.map((q) => (
          <button key={q.label} onClick={q.onClick} className={`w-full flex items-center justify-between px-4 py-3.5 text-left hover:bg-stone-50 ${q.danger ? "text-red-600" : "text-slate-700"}`}>
            <span className="flex items-center gap-2.5 text-sm font-medium"><q.icon size={16} /> {q.label}</span>
            <ChevronRight size={15} className="text-slate-300" />
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   SETTINGS
============================================================ */
function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)} className={`w-11 h-6 rounded-full flex items-center px-0.5 transition-colors shrink-0 ${on ? "bg-teal-700 justify-end" : "bg-stone-300 justify-start"}`}>
      <div className="w-5 h-5 bg-white rounded-full shadow" />
    </button>
  );
}
function SettingsRow({ label, sub, children }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-stone-100 last:border-0 gap-3">
      <div><p className="text-sm font-medium text-slate-800">{label}</p>{sub && <p className="text-xs text-slate-400">{sub}</p>}</div>
      {children}
    </div>
  );
}

function SettingsPage({ settings, onChange, lang, onLangChange }) {
  const { t } = useT();
  const s = (k) => (v) => onChange({ ...settings, [k]: v });
  return (
    <div>
      <SectionHeader title={t("settings")} sub="Keep this simple — every control here takes effect immediately." />
      <div className="space-y-5 max-w-2xl">
        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-1">{t("changeLanguage")}</p>
          <div className="flex flex-wrap gap-1.5 mb-2">
            {LANGS.map((l) => (
              <button key={l.code} onClick={() => onLangChange(l.code)} className={`text-sm px-3 py-1.5 rounded-full border ${lang === l.code ? "bg-teal-700 text-white border-teal-700" : "border-stone-200 text-slate-600"}`}>{l.label}</button>
            ))}
          </div>
          <p className="text-xs text-slate-400">More regional languages can be added.</p>
        </div>

        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-1">Voice Assistant</p>
          <SettingsRow label="Voice Assistant"><Toggle on={settings.voiceOn} onChange={s("voiceOn")} /></SettingsRow>
          <SettingsRow label="Voice Language" sub="Used for spoken navigation prompts">
            <select value={settings.voiceLang} onChange={(e) => s("voiceLang")(e.target.value)} className="border border-stone-300 rounded-lg px-2 py-1.5 text-sm bg-white">
              {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
            </select>
          </SettingsRow>
          <SettingsRow label="Voice Volume">
            <input type="range" min="0" max="100" value={settings.voiceVolume} onChange={(e) => s("voiceVolume")(Number(e.target.value))} className="w-28" />
          </SettingsRow>
          <SettingsRow label="Safety Alerts"><Toggle on={settings.safetyAlerts} onChange={s("safetyAlerts")} /></SettingsRow>
          <SettingsRow label="Weather Alerts"><Toggle on={settings.weatherAlertsVoice} onChange={s("weatherAlertsVoice")} /></SettingsRow>
          <SettingsRow label="Route Change Alerts"><Toggle on={settings.routeChangeAlerts} onChange={s("routeChangeAlerts")} /></SettingsRow>
        </div>

        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-1">Notifications</p>
          <SettingsRow label="Weather Alerts"><Toggle on={settings.notifWeather} onChange={s("notifWeather")} /></SettingsRow>
          <SettingsRow label="Route Alerts"><Toggle on={settings.notifRoute} onChange={s("notifRoute")} /></SettingsRow>
          <SettingsRow label="Shipment Alerts"><Toggle on={settings.notifShipment} onChange={s("notifShipment")} /></SettingsRow>
          <SettingsRow label="Emergency Alerts"><Toggle on={settings.notifEmergency} onChange={s("notifEmergency")} /></SettingsRow>
        </div>

        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-1">Offline Mode</p>
          <SettingsRow label="Allow offline access" sub="Cache routes, alerts and reports for low-connectivity areas"><Toggle on={settings.offlineAllowed} onChange={s("offlineAllowed")} /></SettingsRow>
        </div>

        <div className={`${cardCls} p-4`}>
          <p className="font-semibold text-slate-800 text-sm mb-1">Map Preferences</p>
          <SettingsRow label="Traffic Layer"><Toggle on={settings.layerTraffic} onChange={s("layerTraffic")} /></SettingsRow>
          <SettingsRow label="Weather Layer"><Toggle on={settings.layerWeather} onChange={s("layerWeather")} /></SettingsRow>
          <SettingsRow label="Risk Layer"><Toggle on={settings.layerRisk} onChange={s("layerRisk")} /></SettingsRow>
          <SettingsRow label="Vehicle Layer"><Toggle on={settings.layerVehicles} onChange={s("layerVehicles")} /></SettingsRow>
          <SettingsRow label="Incident Layer"><Toggle on={settings.layerIncidents} onChange={s("layerIncidents")} /></SettingsRow>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   LOGIN SCREEN
============================================================ */
function LoginScreen({ onLogin, lang, onLangChange }) {
  const [role, setRole] = useState("driver");
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const { t } = useT();
  const roleLabels = { driver: "Driver", officer: "Field Officer", authority: "Authority" };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 nr-font">
      <div className="w-full max-w-md">
        <div className="flex justify-end mb-3">
          <div className="flex flex-wrap gap-1 bg-slate-800 rounded-full p-1">
            {LANGS.map((l) => (
              <button key={l.code} onClick={() => onLangChange(l.code)} className={`text-xs px-2.5 py-1 rounded-full transition-colors ${lang === l.code ? "bg-teal-700 text-white" : "text-slate-400 hover:text-white"}`}>{l.label}</button>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-center mb-6 text-center">
          <div className="bg-white rounded-2xl p-3 mb-3"><Logo size={40} /></div>
          <h1 className="text-white text-2xl font-bold tracking-tight">NE-RAAH</h1>
          <p className="text-slate-400 text-sm mt-1">"Intelligent Routes. Safer Journeys. Connected NER."</p>
        </div>

        <button onClick={() => onLogin(role, DEMO_USERS[role].id)}
          className="w-full bg-teal-700 hover:bg-teal-600 active:bg-teal-800 text-white rounded-2xl p-4 shadow-xl mb-4 flex items-center justify-between gap-3 transition-colors group">
          <div className="text-left">
            <p className="font-bold text-sm flex items-center gap-1.5"><Sparkles size={15} /> {t("continueAsDemo")}</p>
            <p className="text-xs text-teal-100 mt-0.5">Launch the full simulated NER environment as {role === "driver" ? "a Driver" : role === "officer" ? "a Field Officer" : "an Authority"} — no password needed</p>
          </div>
          <ArrowRight size={20} className="shrink-0 group-hover:translate-x-1 transition-transform" />
        </button>

        <div className="bg-white rounded-2xl p-6 shadow-xl">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Login as</p>
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[["driver", "Driver", Truck], ["officer", "Field Officer", FileText], ["authority", "Authority", Shield]].map(([r, label, Icon]) => (
              <button key={r} onClick={() => setRole(r)} className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border text-xs font-medium transition-colors ${role === r ? "bg-teal-700 text-white border-teal-700" : "border-stone-200 text-slate-500 hover:bg-stone-50"}`}>
                <Icon size={17} /> {label}
              </button>
            ))}
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-500">User ID / Email</label>
              <input value={id} onChange={(e) => setId(e.target.value)} placeholder={DEMO_USERS[role].id} className="w-full mt-1 border border-stone-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-teal-600" />
            </div>
            <div>
              <label className="text-xs text-slate-500">Password</label>
              <input value={pw} onChange={(e) => setPw(e.target.value)} type="password" placeholder="••••••••" className="w-full mt-1 border border-stone-300 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-teal-600" />
            </div>
          </div>
          <PrimaryBtn className="w-full mt-4" onClick={() => onLogin(role, id || DEMO_USERS[role].id)}>{t("login")}</PrimaryBtn>
          <p className="text-xs text-slate-400 text-center mt-3">Try: <span className="nr-mono">driver@neraah.demo</span> or <span className="nr-mono">authority@neraah.demo</span></p>
        </div>
        <div className="mt-5 bg-slate-800 rounded-xl p-4">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">How NE-RAAH works</p>
          <div className="flex flex-wrap gap-x-1 gap-y-1.5 text-xs text-slate-300">
            {["Monitor", "Detect", "Predict", "Decide", "Navigate", "Respond", "Report"].map((w, i, arr) => (
              <span key={w} className="flex items-center gap-1">{w}{i < arr.length - 1 && <ArrowRight size={10} className="text-slate-500" />}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   DRIVER HOME (Driver Mode)
============================================================ */
function DriverHome({ vehicle, route, onVoice, onSOS, weatherAhead, onOpenRoutes }) {
  const { t } = useT();
  const tier = riskTier(route.risk);
  return (
    <div>
      <SectionHeader title={`Heading to ${vehicle.destination}`} sub={`Vehicle ${vehicle.id} · ${vehicle.cargo}`} />
      <div className={`${cardCls} p-5 mb-4`}>
        <div className="flex items-center justify-between mb-4">
          <div><p className="text-xs text-slate-400">{t("eta")}</p><p className="text-2xl font-bold nr-mono text-slate-900">{vehicle.eta}</p></div>
          <div className="text-right"><p className="text-xs text-slate-400">{t("distance")}</p><p className="text-2xl font-bold nr-mono text-slate-900">214 km</p></div>
        </div>
        <div className="bg-stone-50 rounded-lg p-3 flex items-center gap-3 mb-3">
          <Navigation size={22} className="text-teal-700 -rotate-45" />
          <div><p className="text-xs text-slate-400">Next Turn</p><p className="font-semibold text-slate-800">Right in 2.4 km</p></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className={`rounded-lg p-3 border ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].border}`}>
            <p className="text-xs text-slate-500 mb-1">{t("routes")}</p><TierBadge tier={tier} />
          </div>
          <div className="rounded-lg p-3 border border-amber-200 bg-amber-50">
            <p className="text-xs text-slate-500 mb-1">{t("weatherLabel")}</p>
            <p className="text-xs font-semibold text-amber-700 flex items-center gap-1"><CloudRain size={13} /> {weatherAhead}</p>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3 mb-4">
        <button onClick={onVoice} className={`${cardCls} p-4 flex flex-col items-center gap-1.5 text-teal-700`}><Mic size={22} /><span className="text-xs font-semibold">Voice</span></button>
        <button onClick={onOpenRoutes} className={`${cardCls} p-4 flex flex-col items-center gap-1.5 text-teal-700`}><RouteIcon size={22} /><span className="text-xs font-semibold">{t("routes")}</span></button>
        <div className={`${cardCls} p-4 flex flex-col items-center gap-1.5`}><SOSButton onActivate={onSOS} compact /></div>
      </div>
    </div>
  );
}

/* ============================================================
   DEMO GUIDE
============================================================ */
const DEMO_STEPS = [
  { title: "Scenario Start", desc: "Critical shipment MED-204 (Medical Supplies) departs Guwahati for Aizawl on Route B — risk 27, safe to go.", page: "routes" },
  { title: "Weather Intensifies", desc: "Heavy rainfall builds along the Aizawl corridor. A weather alert is raised.", page: "weather" },
  { title: "Field Report: Landslide", desc: "A field officer reports a landslide 3.2 km ahead on Route B. Route risk jumps from 27 to 72.", page: "reports" },
  { title: "Driver Voice Warning", desc: "The NE-RAAH voice assistant warns the driver and suggests Route C as a safer alternative.", page: "dashboard" },
  { title: "Reroute to Route C", desc: "The driver accepts the AI recommendation and switches to Route C. The map updates.", page: "routes" },
  { title: "SOS Activated", desc: "A secondary hazard triggers an SOS from the driver. The Command Center sees it instantly.", page: "sos" },
  { title: "Authority Opens Copilot", desc: "Authority asks the AI Logistics Copilot which critical shipments are affected.", page: "copilot" },
  { title: "Dispatch & Resolve", desc: "A response team is dispatched, the emergency is resolved and the shipment is marked protected.", page: "sos" },
];

function DemoGuide({ step, total, title, desc, onNext, onEnd }) {
  return (
    <div className="fixed bottom-20 md:bottom-6 left-4 right-4 md:left-6 md:right-auto md:w-96 z-30">
      <div className="bg-slate-900 text-white rounded-xl shadow-xl p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-teal-400 uppercase tracking-wide nr-mono">Demo · Step {step + 1} / {total}</span>
          <button onClick={onEnd} className="text-slate-400 hover:text-white"><X size={15} /></button>
        </div>
        <p className="font-semibold text-sm mb-1">{title}</p>
        <p className="text-xs text-slate-300 mb-3">{desc}</p>
        <div className="flex gap-2">
          <button onClick={onNext} className="flex-1 bg-teal-700 hover:bg-teal-600 text-white text-sm font-semibold px-3 py-2 rounded-lg flex items-center justify-center gap-1.5">
            {step + 1 === total ? "Finish Demo" : "Next Step"} <SkipForward size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   SOS DRAWER (dedicated — needs timeline + role actions)
============================================================ */
function SOSDrawer({ open, onClose, sos, role, onAdvance, onViewMap }) {
  const { t } = useT();
  if (!open || !sos) return null;
  const tier = riskTier(sos.risk);
  return (
    <div className="fixed inset-0 z-40 md:flex md:items-stretch md:justify-end">
      <div className="absolute inset-0 bg-slate-900 opacity-40" onClick={onClose} />
      <div className="relative bg-white w-full md:w-96 h-full ml-auto shadow-xl overflow-y-auto nr-scroll fixed bottom-0 md:static rounded-t-2xl md:rounded-none max-h-full">
        <div className="sticky top-0 bg-white border-b border-stone-200 px-5 py-4 flex items-start justify-between">
          <div>
            <p className="text-xs font-semibold tracking-wide text-red-600 uppercase nr-mono">SOS</p>
            <h3 className="text-lg font-semibold text-slate-900 mt-0.5 nr-font">{sos.id}</h3>
            <p className="text-sm text-slate-500 mt-0.5">{sos.type}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-stone-100 text-slate-400"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className={`rounded-lg p-3 border ${RISK_TIERS[tier].bg} ${RISK_TIERS[tier].border} flex items-center justify-between`}>
            <TierBadge tier={tier} /><StatusBadge status={sos.status} />
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            <div><p className="text-xs text-slate-400">Location</p><p className="font-medium text-slate-800">{sos.location}</p></div>
            <div><p className="text-xs text-slate-400">Vehicle</p><p className="font-medium text-slate-800 nr-mono">{sos.vehicle}</p></div>
            <div><p className="text-xs text-slate-400">Current Risk</p><p className="font-medium text-slate-800">{sos.risk}/100</p></div>
            <div><p className="text-xs text-slate-400">Weather</p><p className="font-medium text-slate-800">{sos.weather}</p></div>
            <div><p className="text-xs text-slate-400">Activated</p><p className="font-medium text-slate-800">{sos.time}</p></div>
          </div>
          <SOSDetailBody sos={sos} onAdvance={onAdvance} role={role} />
          {onViewMap && <SecondaryBtn className="w-full" icon={MapPinned} onClick={onViewMap}>{t("viewOnMap")}</SecondaryBtn>}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   APP ROOT
============================================================ */
const DEFAULT_SETTINGS = {
  voiceOn: true, voiceLang: "en", voiceVolume: 70, safetyAlerts: true, weatherAlertsVoice: true, routeChangeAlerts: true,
  notifWeather: true, notifRoute: true, notifShipment: true, notifEmergency: true,
  offlineAllowed: true,
  layerTraffic: false, layerWeather: true, layerRisk: true, layerVehicles: true, layerIncidents: true,
};
function uid(prefix) { return `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`; }
function tierToVehicleStatus(tier) {
  if (tier === "safe") return "ON TIME";
  if (tier === "moderate") return "ON TIME";
  if (tier === "high") return "AT RISK";
  return "STOPPED";
}

function App() {
  const [authed, setAuthed] = useState(false);
  const [role, setRole] = useState("driver");
  const [user, setUser] = useState(DEMO_USERS.driver);
  const [page, setPage] = useState("dashboard");
  const [lang, setLang] = useState("en");
  const [online, setOnline] = useState(true);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [toast, setToast] = useState(null);

  const [vehicles, setVehicles] = useState(VEHICLES_INIT.map((v) => ({ ...v })));
  const [shipments, setShipments] = useState(SHIPMENTS_INIT.map((s) => ({ ...s })));
  const [incidents, setIncidents] = useState(INCIDENTS_INIT.map((i) => ({ ...i })));
  const [alerts, setAlerts] = useState(ALERTS_INIT.map((a) => ({ ...a })));
  const [notifs, setNotifs] = useState(NOTIFS_INIT.map((n) => ({ ...n })));
  const [sosList, setSosList] = useState(SOS_INIT.map((s) => ({ ...s })));
  const [fieldReports, setFieldReports] = useState([]);
  const [mapRoutes, setMapRoutes] = useState(MAP_ROUTES_BASE.map((r) => ({ ...r })));
  const [routeOptions, setRouteOptions] = useState(ROUTE_OPTIONS.map((r) => ({ ...r })));
  const [activeRouteId, setActiveRouteId] = useState("B");
  const [kpis, setKpis] = useState({
    logisticsHealth: 72, totalCorridors: 31, accessible: 24, atRisk: 5, atRiskHigh: 2, atRiskModerate: 3,
    blocked: 2, blockedLandslide: 1, blockedFlood: 1, activeVehicles: 143, vehiclesOnRoute: 137, vehiclesDelayed: 6,
    criticalShipments: 8, criticalShipmentsAtRisk: 3, activeSOS: 3, fieldReports: 12, fieldReportsPending: 4,
    fieldReportsVerified: 6, fieldReportsResolved: 2, weatherAlerts: 6, weatherSevere: 2, weatherModerate: 4,
  });

  const [mapFilter, setMapFilter] = useState(null);
  const [mapFocusLayer, setMapFocusLayer] = useState(null);
  const [mapSpotlight, setMapSpotlight] = useState(null);
  const [drawer, setDrawer] = useState(null);
  const [sosDrawer, setSosDrawer] = useState(null);
  const [explainRoute, setExplainRoute] = useState(null);
  const [sosActivateOpen, setSosActivateOpen] = useState(false);
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [copilotMessages, setCopilotMessages] = useState([{ from: "bot", title: "AI Logistics Copilot", lines: ["Ask me about vehicles, shipments, routes, weather risk or SOS status."] }]);
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [logoutConfirm, setLogoutConfirm] = useState(false);
  const [simVehicleId, setSimVehicleId] = useState(null);
  const [routeIncidentBanner, setRouteIncidentBanner] = useState(null);
  const [voiceWarningText, setVoiceWarningText] = useState(null);
  const [demoActive, setDemoActive] = useState(false);
  const [demoStep, setDemoStep] = useState(0);

  const t = (key) => (T[lang] && T[lang][key]) || T.en[key] || key;

  useEffect(() => { if (!toast) return; const tm = setTimeout(() => setToast(null), 2600); return () => clearTimeout(tm); }, [toast]);

  useEffect(() => {
    if (online) {
      setFieldReports((rs) => {
        const pending = rs.filter((r) => r.sync === "PENDING");
        if (pending.length > 0) setToast(`Connection restored. ${pending.length} report${pending.length > 1 ? "s" : ""} synchronized successfully.`);
        return rs.map((r) => ({ ...r, sync: "SYNCED" }));
      });
    }
  }, [online]);

  useEffect(() => {
    if (!simVehicleId) return;
    const iv = setInterval(() => {
      setVehicles((vs) => vs.map((v) => v.id === simVehicleId ? { ...v, pos: Math.min(1, v.pos + 0.05), speed: 28 + Math.round(Math.random() * 22) } : v));
    }, 700);
    return () => clearInterval(iv);
  }, [simVehicleId]);

  useEffect(() => {
    if (!simVehicleId) return;
    const v = vehicles.find((x) => x.id === simVehicleId);
    if (v && v.pos >= 1) {
      setVehicles((vs) => vs.map((x) => x.id === simVehicleId ? { ...x, status: "DELIVERED", speed: 0, eta: "Arrived" } : x));
      setToast(`${simVehicleId} delivered.`);
      setSimVehicleId(null);
    }
  }, [vehicles, simVehicleId]);

  const hasActiveSOS = sosList.some((s) => s.status !== "RESOLVED" && s.vehicle === user.vehicleId);
  const unreadCount = notifs.filter((n) => !n.read).length;

  const login = (r, id) => {
    const base = DEMO_USERS[r];
    setRole(r); setUser({ ...base, id }); setAuthed(true); setPage("dashboard"); setLang(base.language || "en");
  };
  const doLogout = () => { setAuthed(false); setLogoutConfirm(false); setPage("dashboard"); setDemoActive(false); };

  const saveProfile = (form) => { setUser(form); setLang(form.language); setEditProfileOpen(false); setToast("Profile updated successfully."); };

  const addAlert = (level, title, detail, link) => setAlerts((a) => [{ id: uid("AL"), level, title, detail, time: "Just now", link }, ...a]);
  const addNotif = (title, detail, link) => setNotifs((n) => [{ id: uid("N"), title, detail, time: "Just now", read: false, link }, ...n]);

  const advanceSOS = (id, stage) => {
    setSosList((list) => list.map((s) => {
      if (s.id !== id) return s;
      const timeline = [...s.timeline, stage];
      const status = stage === "Resolved" ? "RESOLVED" : stage.toUpperCase();
      return { ...s, timeline, status };
    }));
    if (stage === "Resolved") setKpis((k) => ({ ...k, activeSOS: Math.max(0, k.activeSOS - 1) }));
    setToast(stage === "Resolved" ? "SOS marked resolved." : `SOS ${stage.toLowerCase()}.`);
  };

  const submitSOS = (category) => {
    const s = { id: uid("SOS"), type: category, vehicle: user.vehicleId || "—", location: `Near ${user.district}`, status: "ACTIVE", time: "Just now", risk: 55, weather: "Overcast", timeline: ["Activated"] };
    setSosList((list) => [...list, s]);
    setKpis((k) => ({ ...k, activeSOS: k.activeSOS + 1 }));
    addAlert("critical", "SOS Activated", `${category} — ${s.vehicle}`, { type: "sos", id: s.id });
    addNotif("SOS Activated", `${category} reported by ${user.name}`, { type: "sos", id: s.id });
    setSosActivateOpen(false);
    setToast("Command Center notified.");
  };

  const submitReport = (rep) => {
    const full = { id: uid("INC"), time: "Just now", ...rep };
    setFieldReports((rs) => [full, ...rs]);
    setIncidents((inc) => [{ id: full.id, type: full.type, location: full.location, severity: full.severity, reportedBy: `${user.role} · ${user.name}`, time: "Just now", status: "ACTIVE", desc: full.description, verification: "PENDING", sync: full.sync, photo: !!full.photo, usedForRisk: false }, ...inc]);
    addAlert(full.severity === "HIGH" ? "critical" : "warning", `${full.type} Reported`, full.location, { type: "incident", id: full.id });
    addNotif("Field report submitted", `${full.type} — ${full.location}`, { type: "incident", id: full.id });
    setToast(rep.sync === "PENDING" ? "Report saved offline — pending synchronization." : "Incident reported successfully.");
  };

  const useForRouteRisk = (incident) => {
    setIncidents((inc) => inc.map((i) => i.id === incident.id ? { ...i, usedForRisk: true, verification: "VERIFIED" } : i));
    setRouteOptions((ro) => ro.map((r) => r.id === "B" ? { ...r, risk: 72, status: "AVOID", landslide: "High" } : r));
    setMapRoutes((mr) => mr.map((r) => r.id === "R-GHY-AIZ" ? { ...r, risk: 72 } : r));
    if (activeRouteId === "B") setVehicles((vs) => vs.map((v) => v.id === "NER-MED-024" ? { ...v, risk: 72, status: "AT RISK" } : v));
    addAlert("critical", "Route Risk Updated", `${incident.type} confirmed — Route B risk increased to 72`, { type: "routes" });
    setToast("Route risk updated using field intelligence.");
  };

  /* Generic version for the map's "View Impact" — bumps whichever corridor the hazard actually sits on,
     so it stays correct for any route (not just the Guwahati-Aizawl flagship demo). */
  const bumpRouteRiskFromHazard = (incident) => {
    if (!incident.routeId) return;
    setIncidents((inc) => inc.map((i) => i.id === incident.id ? { ...i, usedForRisk: true, verification: "VERIFIED" } : i));
    let newRisk = null;
    setMapRoutes((mr) => mr.map((r) => {
      if (r.id !== incident.routeId) return r;
      newRisk = Math.min(100, r.risk + 30);
      return { ...r, risk: newRisk };
    }));
    if (incident.routeId === "R-GHY-AIZ" && activeRouteId === "B") {
      setRouteOptions((ro) => ro.map((r) => r.id === "B" ? { ...r, risk: Math.min(100, r.risk + 30), status: "AVOID" } : r));
    }
    addAlert("critical", "Route Risk Updated", `${incident.type} confirmed on ${ROUTE_STATE[incident.routeId] || "the corridor"} — risk increased`, { type: "routes" });
    setToast("Route risk updated based on hazard impact.");
  };

  /* ---- drawer openers ---- */
  const openVehicle = (v) => setDrawer({
    kicker: "VEHICLE", title: v.id, subtitle: `${v.origin} → ${v.destination}`, tier: riskTier(v.risk),
    fields: [
      { label: "Driver", value: v.driver }, { label: "Cargo", value: v.cargo }, { label: "Speed", value: `${v.speed} km/h` },
      { label: "ETA", value: v.eta }, { label: "Risk", value: `${v.risk}/100` }, { label: "Status", value: v.status },
    ],
    actions: [
      { label: "Track Vehicle", onClick: () => { setSimVehicleId(v.id); spotlightOnMap("vehicle", v.id); setDrawer(null); }, primary: true },
      { label: "View on Map", onClick: () => { spotlightOnMap("vehicle", v.id); setDrawer(null); } },
    ],
    note: "Position is simulated for this prototype — not a real GPS feed.",
  });

  const openShipment = (s) => setDrawer({
    kicker: "SHIPMENT", title: s.id, subtitle: s.route, tier: WORD_TIER[s.risk] || "moderate",
    fields: [
      { label: "Cargo", value: s.cargo }, { label: "Priority", value: s.priority }, { label: "Vehicle", value: s.vehicle },
      { label: "ETA", value: s.eta }, { label: "Risk", value: s.risk }, { label: "Status", value: s.status },
      { label: "Criticality Score", value: `${s.criticality}/100 · ${criticalityTier(s.criticality).label}`, full: true },
    ],
    note: s.criticalityReason,
    actions: [
      { label: "View on Map", onClick: () => { if (s.vehicle !== "—") spotlightOnMap("vehicle", s.vehicle); else goToMap(null, "vehicles"); setDrawer(null); }, primary: true },
      { label: "Reroute", onClick: () => { if (s.vehicle === "NER-MED-024") setActiveRoute("C"); setToast(`${s.id} rerouted via the lowest-risk available path.`); setDrawer(null); } },
      { label: "Contact Driver", onClick: () => { setToast(`Calling ${s.vehicle === "—" ? "driver" : s.vehicle + " driver"}…`); } },
    ],
  });

  const openIncident = (inc) => setDrawer({
    kicker: "INCIDENT", title: inc.type, subtitle: inc.location, tier: inc.severity === "HIGH" ? "high" : inc.severity === "MODERATE" ? "moderate" : "safe",
    fields: [
      { label: "Reported By", value: inc.reportedBy }, { label: "Time", value: inc.time }, { label: "Status", value: inc.status },
      { label: "Description", value: inc.desc, full: true },
    ],
    actions: [{ label: "View on Map", onClick: () => { spotlightOnMap("incident", inc.id); setDrawer(null); }, primary: true }],
  });

  const openRouteSegment = (r) => {
    const tier = riskTier(r.risk);
    setDrawer({
      kicker: "ROUTE SEGMENT", title: `${CITIES[r.from].name} → ${CITIES[r.to].name}`, subtitle: r.label, tier,
      fields: [
        { label: "Risk Score", value: `${r.risk}/100` }, { label: "Weather", value: r.risk > 55 ? "Heavy Rain" : "Clear" },
        { label: "Rainfall", value: r.risk > 55 ? "High" : "Low" }, { label: "Landslide Probability", value: tier === "high" || tier === "blocked" ? "High" : "Low" },
        { label: "Flood Probability", value: tier === "moderate" ? "Moderate" : "Low" }, { label: "Road Condition", value: tier === "safe" ? "Good" : tier === "moderate" ? "Fair" : "Poor" },
        { label: "Traffic", value: "Moderate" }, { label: "Recent Incidents", value: incidents.filter((i) => i.routeId === r.id).length },
      ],
      note: `${tier === "safe" ? "Safe to proceed." : tier === "blocked" ? "Corridor currently blocked — avoid." : "Proceed with caution."} AI-assisted risk estimate.`,
      actions: [],
    });
  };

  const handleOpenLink = (link) => {
    if (!link) return;
    if (link.type === "weather") setPage("weather");
    else if (link.type === "routes") setPage("routes");
    else if (link.type === "dashboard") setPage("dashboard");
    else if (link.type === "incident") { const i = incidents.find((x) => x.id === link.id); if (i) openIncident(i); }
    else if (link.type === "shipment") { const s = shipments.find((x) => x.id === link.id); if (s) openShipment(s); }
    else if (link.type === "vehicle") { const v = vehicles.find((x) => x.id === link.id); if (v) openVehicle(v); }
    else if (link.type === "sos") { const s = sosList.find((x) => x.id === link.id); if (s) setSosDrawer(s); }
    setNotifOpen(false);
  };

  const handleSearch = (query) => {
    const q = query.toLowerCase();
    const v = vehicles.find((x) => x.id.toLowerCase().includes(q) || x.destination.toLowerCase().includes(q));
    if (v) return openVehicle(v);
    const s = shipments.find((x) => x.id.toLowerCase().includes(q) || x.cargo.toLowerCase().includes(q));
    if (s) return openShipment(s);
    const inc = incidents.find((x) => x.type.toLowerCase().includes(q) || x.location.toLowerCase().includes(q));
    if (inc) return openIncident(inc);
    const so = sosList.find((x) => x.id.toLowerCase().includes(q) || x.type.toLowerCase().includes(q));
    if (so) return setSosDrawer(so);
    const r = mapRoutes.find((x) => CITIES[x.from].name.toLowerCase().includes(q) || CITIES[x.to].name.toLowerCase().includes(q));
    if (r) { setPage("map"); return openRouteSegment(r); }
    setToast(`No results found for "${query}".`);
  };

  const setActiveRoute = (id) => {
    setActiveRouteId(id);
    const r = routeOptions.find((x) => x.id === id);
    const tier = riskTier(r.risk);
    setVehicles((vs) => vs.map((v) => v.id === "NER-MED-024" ? { ...v, risk: r.risk, status: tierToVehicleStatus(tier) } : v));
    setToast(`Switched to ${r.name}.`);
  };

  const goToMap = (filter, layer) => {
    setMapFilter(filter || null);
    setMapFocusLayer(layer || null);
    setPage("map");
  };
  const spotlightOnMap = (kind, id) => {
    setMapSpotlight({ kind, id, ts: Date.now() });
    setPage("map");
  };
  const navigate = (id) => {
    if (id === "map") { setMapFilter(null); setMapFocusLayer(null); }
    setPage(id);
  };

  const copilotCtx = { kpis, shipments, vehicles, sosList, routeOptions };
  const askCopilot = (question) => {
    setCopilotMessages((m) => [...m, { from: "user", text: question }]);
    setTimeout(() => setCopilotMessages((m) => [...m, { from: "bot", ...buildCopilotResponse(question, copilotCtx) }]), 300);
  };

  /* ---- demo scenario ---- */
  const runDemoStep = (idx) => {
    if (idx === 0) {
      setActiveRouteId("B");
      setRouteOptions(ROUTE_OPTIONS.map((r) => ({ ...r })));
      setMapRoutes(MAP_ROUTES_BASE.map((r) => ({ ...r })));
      setVehicles((vs) => vs.map((v) => v.id === "NER-MED-024" ? { ...v, risk: 27, status: "ON TIME" } : v));
      setRouteIncidentBanner(null); setVoiceWarningText(null);
      setPage("routes");
    } else if (idx === 1) {
      setPage("weather");
      setToast("Heavy rainfall intensifying along the Aizawl corridor.");
    } else if (idx === 2) {
      setPage("reports");
      const newInc = { id: uid("INC"), type: "Landslide", location: "NH-306, 3.2 km ahead on Route B", severity: "HIGH", reportedBy: "Field Officer · D. Lalrinliana", time: "Just now", status: "ACTIVE", desc: "Debris blocking one lane after heavy overnight rainfall.", routeId: "R-GHY-AIZ" };
      setIncidents((inc) => [newInc, ...inc]);
      setRouteOptions((ro) => ro.map((r) => r.id === "B" ? { ...r, risk: 72, status: "AVOID", landslide: "High", incidents: 1 } : r));
      setMapRoutes((mr) => mr.map((r) => r.id === "R-GHY-AIZ" ? { ...r, risk: 72 } : r));
      setVehicles((vs) => vs.map((v) => v.id === "NER-MED-024" ? { ...v, risk: 72, status: "AT RISK" } : v));
      setKpis((k) => ({ ...k, atRisk: k.atRisk + 1, accessible: k.accessible - 1 }));
      addAlert("critical", "Landslide Reported", "3.2 km ahead on Route B — Guwahati → Aizawl corridor", { type: "incident", id: newInc.id });
      addNotif("Landslide reported", "Route B risk increased to 72", { type: "incident", id: newInc.id });
      setRouteIncidentBanner("Route B risk increased to 72 after a landslide report 3.2 km ahead.");
    } else if (idx === 3) {
      setPage("dashboard");
      setVoiceWarningText(t("voiceLandslideWarning"));
      speak(t("voiceLandslideWarning"), lang);
    } else if (idx === 4) {
      setPage("routes");
      setActiveRouteId("C");
      setVehicles((vs) => vs.map((v) => v.id === "NER-MED-024" ? { ...v, risk: 53, status: "ON TIME" } : v));
      setVoiceWarningText(null);
      setToast("Rerouted to Route C.");
    } else if (idx === 5) {
      setPage("sos");
      const s = { id: "SOS-1048", type: "Medical Emergency", vehicle: "NER-MED-024", location: "Alternate route near Aizawl corridor", status: "ACTIVE", time: "Just now", risk: 78, weather: "Heavy Rain", timeline: ["Activated"] };
      setSosList((list) => [...list, s]);
      setKpis((k) => ({ ...k, activeSOS: k.activeSOS + 1 }));
      addAlert("critical", "SOS Activated", "Medical Emergency — NER-MED-024", { type: "sos", id: "SOS-1048" });
      addNotif("SOS Activated", "Medical Emergency reported by driver R. Lalrinliana", { type: "sos", id: "SOS-1048" });
    } else if (idx === 6) {
      setPage("copilot");
      setTimeout(() => askCopilot("Which medical shipments are at risk?"), 400);
    } else if (idx === 7) {
      setPage("sos");
      setSosList((list) => list.map((s) => s.id === "SOS-1048" ? { ...s, status: "RESOLVED", timeline: ["Activated", "Acknowledged", "Response Assigned", "Dispatched", "Resolved"] } : s));
      setShipments((ss) => ss.map((s) => s.id === "MED-204" ? { ...s, status: "PROTECTED / ON TRACK" } : s));
      setKpis((k) => ({ ...k, activeSOS: Math.max(0, k.activeSOS - 1), atRisk: Math.max(0, k.atRisk - 1), accessible: k.accessible + 1 }));
      setToast("Emergency resolved. MED-204 is protected and on track.");
    }
  };
  const startDemo = () => { setDemoActive(true); setDemoStep(0); runDemoStep(0); };
  const nextDemoStep = () => {
    if (demoStep + 1 >= DEMO_STEPS.length) { setDemoActive(false); setToast("Demo complete."); return; }
    const n = demoStep + 1; setDemoStep(n); runDemoStep(n);
  };

  if (!authed) return (<LangContext.Provider value={{ lang, t }}><div className="nr-font"><FontStyles /><LoginScreen onLogin={login} lang={lang} onLangChange={setLang} /></div></LangContext.Provider>);

  const driverVehicle = vehicles.find((v) => v.id === user.vehicleId) || vehicles[0];
  const driverRoute = routeOptions.find((r) => r.id === activeRouteId) || routeOptions[1];

  const renderPage = () => {
    if (page === "dashboard") {
      if (role === "driver") return <>{voiceWarningText && <VoiceWarningBanner text={voiceWarningText} onDismiss={() => setVoiceWarningText(null)} />}<DriverHome vehicle={driverVehicle} route={driverRoute} onVoice={() => setVoiceOpen(true)} onSOS={() => setSosActivateOpen(true)} weatherAhead="Heavy Rain in 5 km" onOpenRoutes={() => setPage("routes")} /></>;
      return <CommandCenter role={role} user={user} kpis={kpis} onNav={navigate} onGoToMap={goToMap} alerts={alerts} vehicles={vehicles} shipments={shipments} onOpenAlert={(a) => handleOpenLink(a.link)} onStartDemo={startDemo} demoActive={demoActive} />;
    }
    if (page === "map") return <MapView routes={mapRoutes} vehicles={vehicles} incidents={incidents} sosList={sosList} onOpenRoute={openRouteSegment} onOpenVehicle={openVehicle} onOpenIncident={openIncident} onOpenSOS={setSosDrawer} focusFilter={mapFilter} onClearFilter={() => setMapFilter(null)} simVehicleId={simVehicleId} onStopSim={() => setSimVehicleId(null)} routeOptions={routeOptions} activeRouteId={activeRouteId} onSetActiveRoute={setActiveRoute} onOpenRouteOption={setExplainRoute} focusLayer={mapFocusLayer} spotlight={mapSpotlight} onUseForRouteRisk={bumpRouteRiskFromHazard} />;
    if (page === "routes") return <>{voiceWarningText && role === "driver" && <VoiceWarningBanner text={voiceWarningText} onDismiss={() => setVoiceWarningText(null)} />}<RouteIntelligence role={role} routeOptions={routeOptions} activeRouteId={activeRouteId} onSetActive={setActiveRoute} onOpenExplain={setExplainRoute} driverView={role === "driver"} incidentBanner={routeIncidentBanner} /></>;
    if (page === "vehicles") return <VehiclesPage vehicles={vehicles} onOpen={openVehicle} simVehicleId={simVehicleId} />;
    if (page === "shipments") return <ShipmentsPage shipments={shipments} onOpen={openShipment} />;
    if (page === "alerts") return <AlertsPage alerts={alerts} onOpen={(a) => handleOpenLink(a.link)} />;
    if (page === "sos") return <SOSCenter sosList={sosList} onOpen={setSosDrawer} role={role} />;
    if (page === "reports") return <GroundTruthNetworkPage incidents={incidents} pendingSyncCount={fieldReports.filter((r) => r.sync === "PENDING").length} online={online} onSubmit={submitReport} onUseForRouteRisk={useForRouteRisk} activeRouteRisk={routeOptions.find((r) => r.id === "B")?.risk ?? 27} />;
    if (page === "weather") return <WeatherRiskPage onViewImpact={() => goToMap(null, "weather")} />;
    if (page === "settings") return <SettingsPage settings={settings} onChange={setSettings} lang={lang} onLangChange={setLang} />;
    if (page === "profile") return <ProfilePage user={user} onEdit={() => setEditProfileOpen(true)} onNavSettings={() => setPage("settings")} onLogout={() => setLogoutConfirm(true)} />;
    if (page === "copilot") return <CommandCenter role={role} user={user} kpis={kpis} onNav={navigate} onGoToMap={goToMap} alerts={alerts} vehicles={vehicles} shipments={shipments} onOpenAlert={(a) => handleOpenLink(a.link)} onStartDemo={startDemo} demoActive={demoActive} />;
    return null;
  };

  return (
    <LangContext.Provider value={{ lang, t }}>
    <div className="nr-font min-h-screen bg-stone-50 flex">
      <FontStyles />
      <Sidebar role={role} current={page} onNavigate={navigate} onLogout={() => setLogoutConfirm(true)} />
      <div className="flex-1 min-w-0 flex flex-col">
        <TopBar t={t} online={online} onToggleOnline={() => setOnline((o) => !o)} notifCount={unreadCount} onOpenNotifs={() => setNotifOpen(true)} onOpenProfile={() => setPage("profile")} user={user} onSearch={handleSearch} onOpenMenu={() => setMoreOpen(true)} lang={lang} onLangChange={setLang} hasActiveSOS={hasActiveSOS} />
        {!online && (
          <div className="bg-amber-500 text-white text-xs font-medium text-center py-1.5 flex items-center justify-center gap-1.5"><WifiOff size={13} /> {t("offlineBanner")}</div>
        )}
        <div className="flex-1 p-4 md:p-6 pb-24 md:pb-8 max-w-6xl w-full mx-auto">
          {renderPage()}
        </div>
      </div>

      {role === "authority" && page === "copilot" && (
        <div className="hidden md:flex">
          <CopilotPanel open={true} onClose={() => setPage("dashboard")} ctx={copilotCtx} messages={copilotMessages} onAsk={askCopilot}
            onDispatch={(id) => advanceSOS(id, "Dispatched")} onViewMap={() => goToMap(null, "sos")} onReroute={() => setToast("Critical shipments rerouted via Route C.")} />
        </div>
      )}
      {role === "authority" && page === "copilot" && (
        <div className="md:hidden">
          <CopilotPanel open={true} onClose={() => setPage("dashboard")} ctx={copilotCtx} messages={copilotMessages} onAsk={askCopilot} mobile
            onDispatch={(id) => advanceSOS(id, "Dispatched")} onViewMap={() => goToMap(null, "sos")} onReroute={() => setToast("Critical shipments rerouted via Route C.")} />
        </div>
      )}
      {role === "authority" && page !== "copilot" && (
        <button onClick={() => setPage("copilot")} className="hidden md:flex fixed bottom-24 right-6 z-20 items-center gap-2 bg-slate-900 text-white px-4 py-3 rounded-full shadow-lg text-sm font-semibold hover:bg-slate-800">
          <MessageSquare size={16} /> Ask Logistics Copilot
        </button>
      )}

      <MobileNav role={role} current={page} onNavigate={navigate} onMore={() => setMoreOpen(true)} onActivateSOS={() => setSosActivateOpen(true)} />
      <MoreSheet open={moreOpen} onClose={() => setMoreOpen(false)} role={role} onNavigate={navigate} onLogout={() => { setMoreOpen(false); setLogoutConfirm(true); }} />
      <SOSFloating onActivate={() => setSosActivateOpen(true)} hasActiveSOS={hasActiveSOS} />

      <DetailDrawer open={!!drawer} onClose={() => setDrawer(null)} {...(drawer || {})} />
      <SOSDrawer open={!!sosDrawer} onClose={() => setSosDrawer(null)} sos={sosDrawer} role={role} onAdvance={(id, stage) => { advanceSOS(id, stage); setSosDrawer((d) => d ? { ...d, timeline: [...d.timeline, stage], status: stage === "Resolved" ? "RESOLVED" : stage.toUpperCase() } : d); }} onViewMap={() => { spotlightOnMap("sos", sosDrawer?.id); setSosDrawer(null); }} />
      <ExplainModal open={!!explainRoute} onClose={() => setExplainRoute(null)} route={explainRoute} />
      <SOSActivateModal open={sosActivateOpen} onClose={() => setSosActivateOpen(false)} onSubmit={submitSOS} user={user} currentRisk={driverRoute?.risk || 27} weather="Heavy Rain" online={online} />
      <EditProfileModal open={editProfileOpen} onClose={() => setEditProfileOpen(false)} user={user} onSave={saveProfile} />

      <NotifPanel open={notifOpen} onClose={() => setNotifOpen(false)} notifs={notifs} onMarkRead={(id) => setNotifs((ns) => ns.map((n) => n.id === id ? { ...n, read: true } : n))} onMarkAllRead={() => setNotifs((ns) => ns.map((n) => ({ ...n, read: true })))} onOpenLink={handleOpenLink} />
      <VoiceAssistantModal open={voiceOpen} onClose={() => setVoiceOpen(false)} voiceEnabled={settings.voiceOn} />
      <ConfirmModal open={logoutConfirm} title={t("logoutConfirmTitle")} body={t("logoutConfirmBody")} confirmLabel={t("logout")} danger onConfirm={doLogout} onCancel={() => setLogoutConfirm(false)} />

      {demoActive && (
        <DemoGuide step={demoStep} total={DEMO_STEPS.length} title={DEMO_STEPS[demoStep].title} desc={DEMO_STEPS[demoStep].desc} onNext={nextDemoStep} onEnd={() => setDemoActive(false)} />
      )}
      <Toast toast={toast} />
    </div>
    </LangContext.Provider>
  );
}

export default App;
