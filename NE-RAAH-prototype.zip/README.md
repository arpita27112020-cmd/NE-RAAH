# NE-RAAH
### Intelligent Routes. Safer Journeys. Connected NER.

AI-based Smart Logistics and Accessibility Intelligence Platform prototype for the
North Eastern Region of India — built for SIH 2026, Problem Statement 26002.

## What's in this package

- `NE-RAAH.jsx` — the complete single-file React application.

## What it includes

- Role-based login (Driver / Field Officer / Authority) with a working demo mode
- Authority Command Center & Field Officer dashboard with live-connected metrics
- Interactive live map: route planning between any two NER cities, AI-recommended
  routes with risk scoring, state boundaries, incident/vehicle/SOS markers, and a
  "spotlight" system that zooms and highlights whatever you click from elsewhere
  in the app
- AI Route Intelligence with explainable risk reasoning
- Ground Truth Network (field reports feeding back into route risk)
- Vehicle tracking, shipment monitoring, SOS emergency workflow
- AI Logistics Copilot, Driver Mode with turn-by-turn navigation and voice alerts
- Offline mode simulation
- Full multilingual support (English, Hindi, Assamese, Bengali, Punjabi) —
  applied across the entire interface, including voice responses
- A guided end-to-end demo scenario (Dashboard → Map → Route risk change →
  Reroute → SOS → Resolution)

## How to view it

This is a self-contained React component (uses `lucide-react` for icons and
Tailwind CSS utility classes for styling). The easiest way to view it:

1. Open it in **Claude.ai** — paste the file into a new chat and ask Claude to
   render it as an artifact, or
2. Drop it into any React sandbox that supports Tailwind CSS + `lucide-react`
   (e.g., CodeSandbox, StackBlitz): create a new React project, add the
   `lucide-react` dependency, and replace `App.jsx` with this file.

All data in the prototype (routes, vehicles, shipments, weather, risk scores)
is realistic simulated demo data, clearly built so real APIs (Maps, weather,
GPS, government monitoring systems) could be connected later.
